cg-stub-db 1
in 59
class act 52 public,super java/lang/Object java/util/concurrent/ThreadFactory -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/lang/String;)V - -
 method public newThread (Ljava/lang/Runnable;)Ljava/lang/Thread; - -
in 131
class acu 52 public,super,abstract java/lang/Object - <K:Ljava/lang/Object;T::Lacx<TK;TT;>;R:Ljava/lang/Object;>Ljava/lang/Object;
 inner acu$a acu a public,final
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final a Ljava/util/concurrent/ExecutorService; -
 method public <init> (Ljava/lang/String;ILacx;Ljava/util/function/Supplier;Ljava/util/function/Supplier;)V (Ljava/lang/String;ITT;Ljava/util/function/Supplier<Ljava/util/Map<TT;Ljava/util/concurrent/CompletableFuture<TR;>;>;>;Ljava/util/function/Supplier<Ljava/util/Map<TT;Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>;>;>;)V -
 method public a (Ljava/lang/Object;)Ljava/util/concurrent/CompletableFuture; (TK;)Ljava/util/concurrent/CompletableFuture<TR;>; -
 method public a ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<TR;>; -
 method protected b (Ljava/lang/Object;)Lacu$a; (TK;)Lacu<TK;TT;TR;>.acu$a; -
 method protected,abstract a (Ljava/lang/Object;Z)Lacu$a; (TK;Z)Lacu<TK;TT;TR;>.acu$a; -
 method public b ()V - java/lang/InterruptedException
 method protected,abstract a (Ljava/lang/Object;Lacx;Ljava/util/Map;)Ljava/lang/Object; (TK;TT;Ljava/util/Map<TK;TR;>;)TR; -
 method public b (Ljava/lang/Object;Z)Ljava/lang/Object; (TK;Z)TR; -
 method public c ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<TR;>; -
 method protected,abstract b (Ljava/lang/Object;Lacu$a;)V (TK;Lacu<TK;TT;TR;>.acu$a;)V -
 method protected,abstract a (Ljava/lang/Object;Lacu$a;)Lacu$a; (TK;Lacu<TK;TT;TR;>.acu$a;)Lacu<TK;TT;TR;>.acu$a; -
in 135
class acu 52 public,super,abstract java/lang/Object - <K:Ljava/lang/Object;T::Lacx<TK;TT;>;R:Ljava/lang/Object;>Ljava/lang/Object;
 inner acu$a acu a public,final
 inner java/util/concurrent/ForkJoinPool$ForkJoinWorkerThreadFactory java/util/concurrent/ForkJoinPool ForkJoinWorkerThreadFactory public,static,interface,abstract
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final a Ljava/util/concurrent/ExecutorService; -
 method public <init> (Ljava/lang/String;ILacx;Ljava/util/function/Supplier;Ljava/util/function/Supplier;)V (Ljava/lang/String;ITT;Ljava/util/function/Supplier<Ljava/util/Map<TT;Ljava/util/concurrent/CompletableFuture<TR;>;>;>;Ljava/util/function/Supplier<Ljava/util/Map<TT;Ljava/util/concurrent/CompletableFuture<Ljava/lang/Void;>;>;>;)V -
 method public a (Ljava/lang/Object;)Ljava/util/concurrent/CompletableFuture; (TK;)Ljava/util/concurrent/CompletableFuture<TR;>; -
 method public a ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<TR;>; -
 method protected b (Ljava/lang/Object;)Lacu$a; (TK;)Lacu<TK;TT;TR;>.a; -
 method protected,abstract a (Ljava/lang/Object;Z)Lacu$a; (TK;Z)Lacu<TK;TT;TR;>.a; -
 method public b ()V - java/lang/InterruptedException
 method protected,abstract a (Ljava/lang/Object;Lacx;Ljava/util/Map;)Ljava/lang/Object; (TK;TT;Ljava/util/Map<TK;TR;>;)TR; -
 method public b (Ljava/lang/Object;Z)Ljava/lang/Object; (TK;Z)TR; -
 method public c ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<TR;>; -
 method protected,abstract b (Ljava/lang/Object;Lacu$a;)V (TK;Lacu<TK;TT;TR;>.a;)V -
 method protected,abstract a (Ljava/lang/Object;Lacu$a;)Lacu$a; (TK;Lacu<TK;TT;TR;>.a;)Lacu<TK;TT;TR;>.a; -
in 59
class acu$a 52 public,final,super java/lang/Object - -
 inner acu$a acu a public,final
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lacu;Ljava/lang/Object;Ljava/lang/Object;Lacx;)V (TK;TR;TT;)V -
 method public a ()Ljava/lang/Object; ()TR; -
in 59
class acv 52 public,interface,abstract java/lang/Object - -
 method public,abstract a (Ljava/lang/Runnable;)Lcom/google/common/util/concurrent/ListenableFuture; (Ljava/lang/Runnable;)Lcom/google/common/util/concurrent/ListenableFuture<Ljava/lang/Object;>; -
 method public,abstract av ()Z - -
in 59
class acw 52 public,super java/lang/Object - <K:Ljava/lang/Object;T::Lacx<TK;TT;>;R:Ljava/lang/Object;>Ljava/lang/Object;
 method public <init> (Lacu;)V (Lacu<TK;TT;TR;>;)V -
 method public a ()V - java/lang/InterruptedException
 method public b ()V - -
 method public a (Ljava/lang/Object;)Ljava/util/concurrent/CompletableFuture; (TK;)Ljava/util/concurrent/CompletableFuture<TR;>; -
 method public c ()Ljava/util/concurrent/CompletableFuture; ()Ljava/util/concurrent/CompletableFuture<TR;>; -
in 59
class acx 52 public,interface,abstract java/lang/Object - <K:Ljava/lang/Object;T::Lacx<TK;TT;>;>Ljava/lang/Object;
 method public,abstract a ()Lacx; ()TT; -
 method public,abstract a (Ljava/lang/Object;Ljava/util/function/BiConsumer;)V (TK;Ljava/util/function/BiConsumer<TK;TT;>;)V -
in 59
class acz 52 public,super java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/io/File;)V - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;)Ljava/util/List; (Lnet/minecraft/world/level/dimension/DimensionType;)Ljava/util/List<Lnet/minecraft/world/level/ChunkPos;>; -
in 59
class adl 52 public,interface,abstract java/lang/Object net/minecraft/world/Nameable -
 method public,abstract a (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/inventory/AbstractContainerMenu; - -
 method public,abstract l ()Ljava/lang/String; - -
in 59
class adq 52 public,interface,abstract java/lang/Object net/minecraft/world/Container,adl -
 method public,abstract V_ ()Z - -
 method public,abstract a (Lnet/minecraft/world/LockCode;)V - -
 method public,abstract j ()Lnet/minecraft/world/LockCode; - -
in 59
class ads 52 public,interface,abstract java/lang/Object - -
 method public,abstract Q_ ()Lnet/minecraft/resources/ResourceLocation; - -
in 59
class aef 52 public,super net/minecraft/world/item/alchemy/Potion - -
 method public <init> (ZI)V - -
 method public removeAttributeModifiers (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/ai/attributes/BaseAttributeMap;I)V - -
 method public addAttributeModifiers (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/ai/attributes/BaseAttributeMap;I)V - -
in 59
class aeh 52 public,super net/minecraft/world/item/alchemy/Potion - -
 method public <init> (ZI)V - -
 method public removeAttributeModifiers (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/ai/attributes/BaseAttributeMap;I)V - -
in 59
class aei 52 public,super net/minecraft/world/item/alchemy/Potion - -
 method public <init> (ZI)V - -
 method public isInstantenous ()Z - -
 method public isDurationEffectTick (II)Z - -
in 59
class aeq 52 public,interface,abstract java/lang/Object - -
in 59
class aey 52 public,super,abstract net/minecraft/world/entity/Mob - -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method public causeFallDamage (FF)V - -
 method protected checkFallDamage (DZLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)V - -
 method public a (FFF)V - -
 method public onLadder ()Z - -
in 59
class afj 52 public,interface,abstract java/lang/Object - -
in 131
class afl 52 public,super,abstract net/minecraft/world/entity/animal/Animal net/minecraft/world/entity/TamableAnimal -
 field protected,static,final DATA_FLAGS_ID Lnet/minecraft/network/syncher/EntityDataAccessor; Lnet/minecraft/network/syncher/EntityDataAccessor<Ljava/lang/Byte;>;
 field protected,static,final DATA_OWNERUUID_ID Lnet/minecraft/network/syncher/EntityDataAccessor; Lnet/minecraft/network/syncher/EntityDataAccessor<Ljava/util/Optional<Ljava/util/UUID;>;>;
 field protected sitGoal Lnet/minecraft/world/entity/ai/goal/SitGoal; -
 method public handleEntityEvent (B)V - -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method protected defineSynchedData ()V - -
 method public b (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public readAdditionalSaveData (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public canBeLeashed (Lnet/minecraft/world/entity/player/Player;)Z - -
 method protected spawnTamingParticles (Z)V - -
 method public isTame ()Z - -
 method public setTame (Z)V - -
 method protected reassessTameGoals ()V - -
 method public isSitting ()Z - -
 method public setSitting (Z)V - -
 method public getOwnerUUID ()Ljava/util/UUID; - -
 method public setOwnerUUID (Ljava/util/UUID;)V - -
 method public tame (Lnet/minecraft/world/entity/player/Player;)V - -
 method public getOwner ()Lnet/minecraft/world/entity/LivingEntity; - -
 method public isOwnedBy (Lnet/minecraft/world/entity/LivingEntity;)Z - -
 method public getSitGoal ()Lnet/minecraft/world/entity/ai/goal/SitGoal; - -
 method public wantsToAttack (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/LivingEntity;)Z - -
 method public getTeam ()Lnet/minecraft/world/scores/Team; - -
 method public isAlliedTo (Lnet/minecraft/world/entity/Entity;)Z - -
 method public die (Lnet/minecraft/world/damagesource/DamageSource;)V - -
in 135
class afl 52 public,super,abstract net/minecraft/world/entity/animal/Animal net/minecraft/world/entity/TamableAnimal -
 field protected,static,final DATA_FLAGS_ID Lnet/minecraft/network/syncher/EntityDataAccessor; Lnet/minecraft/network/syncher/EntityDataAccessor<Ljava/lang/Byte;>;
 field protected,static,final DATA_OWNERUUID_ID Lnet/minecraft/network/syncher/EntityDataAccessor; Lnet/minecraft/network/syncher/EntityDataAccessor<Ljava/util/Optional<Ljava/util/UUID;>;>;
 field protected sitGoal Lnet/minecraft/world/entity/ai/goal/SitGoal; -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method protected defineSynchedData ()V - -
 method public b (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public readAdditionalSaveData (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public canBeLeashed (Lnet/minecraft/world/entity/player/Player;)Z - -
 method protected spawnTamingParticles (Z)V - -
 method public handleEntityEvent (B)V - -
 method public isTame ()Z - -
 method public setTame (Z)V - -
 method protected reassessTameGoals ()V - -
 method public isSitting ()Z - -
 method public setSitting (Z)V - -
 method public getOwnerUUID ()Ljava/util/UUID; - -
 method public setOwnerUUID (Ljava/util/UUID;)V - -
 method public tame (Lnet/minecraft/world/entity/player/Player;)V - -
 method public getOwner ()Lnet/minecraft/world/entity/LivingEntity; - -
 method public isOwnedBy (Lnet/minecraft/world/entity/LivingEntity;)Z - -
 method public getSitGoal ()Lnet/minecraft/world/entity/ai/goal/SitGoal; - -
 method public wantsToAttack (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/LivingEntity;)Z - -
 method public getTeam ()Lnet/minecraft/world/scores/Team; - -
 method public isAlliedTo (Lnet/minecraft/world/entity/Entity;)Z - -
 method public die (Lnet/minecraft/world/damagesource/DamageSource;)V - -
in 59
class afy 52 public,super net/minecraft/world/entity/ai/control/MoveControl - -
 inner net/minecraft/world/entity/ai/control/MoveControl$Operation net/minecraft/world/entity/ai/control/MoveControl Operation public,static,final,enum
 method public <init> (Lnet/minecraft/world/entity/Mob;)V - -
 method public tick ()V - -
in 59
class agq 52 public,super net/minecraft/world/entity/ai/goal/FollowOwnerGoal - -
 method public <init> (Lafl;DFF)V - -
 method protected a (IIIII)Z - -
in 59
class agt 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract canUse ()Z - -
 method public canContinueToUse ()Z - -
 method public f ()Z - -
 method public start ()V - -
 method public stop ()V - -
 method public tick ()V - -
 method public a (I)V - -
 method public h ()I - -
in 59
class agv 52 public,super net/minecraft/world/entity/ai/goal/MoveToBlockGoal - -
 method public <init> (Lnet/minecraft/world/entity/npc/Villager;D)V - -
 method public canUse ()Z - -
 method public canContinueToUse ()Z - -
 method public tick ()V - -
 method protected isValidTarget (Layc;Lnet/minecraft/core/BlockPos;)Z - -
in 59
class agw 52 public,super net/minecraft/world/entity/ai/goal/LookAtPlayerGoal - -
 method public <init> (Lnet/minecraft/world/entity/Mob;Ljava/lang/Class;FF)V (Lnet/minecraft/world/entity/Mob;Ljava/lang/Class<+Lnet/minecraft/world/entity/Entity;>;FF)V -
in 59
class ahd 52 public,super agt - -
 method public <init> (Lnet/minecraft/world/entity/npc/Villager;)V - -
 method public canUse ()Z - -
 method public start ()V - -
 method public stop ()V - -
 method public canContinueToUse ()Z - -
 method public tick ()V - -
in 59
class ahf 52 public,super agt - -
 inner net/minecraft/world/level/biome/Biome$Precipitation net/minecraft/world/level/biome/Biome Precipitation public,static,final,enum
 method public <init> (Lnet/minecraft/world/entity/PathfinderMob;)V - -
 method public canUse ()Z - -
 method public canContinueToUse ()Z - -
 method public start ()V - -
 method public stop ()V - -
in 59
class ahl 52 public,super net/minecraft/world/entity/ai/goal/MoveToBlockGoal - -
 method public <init> (Lnet/minecraft/world/entity/animal/Ocelot;D)V - -
 method public canUse ()Z - -
 method public start ()V - -
 method public stop ()V - -
 method public tick ()V - -
 method protected isValidTarget (Layc;Lnet/minecraft/core/BlockPos;)Z - -
in 59
class ahp 52 public,super agt - -
 method public <init> (Lnet/minecraft/world/entity/npc/Villager;D)V - -
 method public canUse ()Z - -
 method public canContinueToUse ()Z - -
 method public start ()V - -
 method public stop ()V - -
 method public tick ()V - -
in 59
class ahs 52 public,super net/minecraft/world/entity/ai/goal/RandomStrollGoal - -
 method public <init> (Lnet/minecraft/world/entity/PathfinderMob;DI)V - -
 method protected getPosition ()Lnet/minecraft/world/phys/Vec3; - -
in 59
class ahw 52 public,super agt - -
 method public <init> (Lnet/minecraft/world/entity/PathfinderMob;)V - -
 method public canUse ()Z - -
 method public canContinueToUse ()Z - -
 method public start ()V - -
 method public stop ()V - -
 method public tick ()V - -
in 59
class aib 52 public,super agt - -
 method public <init> (Lnet/minecraft/world/entity/npc/Villager;)V - -
 method public canUse ()Z - -
 method public canContinueToUse ()Z - -
 method public start ()V - -
 method public stop ()V - -
 method public tick ()V - -
in 59
class aif 52 public,super agw - -
 method public <init> (Lnet/minecraft/world/entity/npc/Villager;)V - -
 method public start ()V - -
 method public tick ()V - -
in 59
class aim 52 public,super agt - -
 inner net/minecraft/world/entity/ai/goal/target/NearestAttackableTargetGoal$a net/minecraft/world/entity/ai/goal/target/NearestAttackableTargetGoal a public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/entity/Mob;Ljava/lang/Class;)V (Lnet/minecraft/world/entity/Mob;Ljava/lang/Class<+Lnet/minecraft/world/entity/LivingEntity;>;)V -
 method public canUse ()Z - -
 method public canContinueToUse ()Z - -
 method public start ()V - -
 method public stop ()V - -
 method protected g ()D - -
in 59
class ain 52 public,super agt - -
 inner net/minecraft/world/entity/ai/goal/target/NearestAttackableTargetGoal$a net/minecraft/world/entity/ai/goal/target/NearestAttackableTargetGoal a public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/entity/Mob;)V - -
 method public canUse ()Z - -
 method public canContinueToUse ()Z - -
 method public start ()V - -
 method public stop ()V - -
 method protected g ()D - -
in 59
class aix 52 public,super java/lang/Object ayb -
 method public <init> ()V - -
 method public blockChanged (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;I)V - -
 method protected a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/core/BlockPos;)V - -
 method public setBlocksDirty (IIIIII)V - -
 method public a (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;DDDFF)V - -
 method public addParticle (Lnet/minecraft/core/particles/ParticleOptions;ZDDDDDD)V - -
 method public addParticle (Lnet/minecraft/core/particles/ParticleOptions;ZZDDDDDD)V - -
 method public a (Lnet/minecraft/world/entity/Entity;)V - -
 method public b (Lnet/minecraft/world/entity/Entity;)V - -
 method public playStreamingMusic (Lnet/minecraft/sounds/SoundEvent;Lnet/minecraft/core/BlockPos;)V - -
 method public globalLevelEvent (ILnet/minecraft/core/BlockPos;I)V - -
 method public levelEvent (Lnet/minecraft/world/entity/player/Player;ILnet/minecraft/core/BlockPos;I)V - -
 method public destroyBlockProgress (ILnet/minecraft/core/BlockPos;I)V - -
in 59
class ajf 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/core/BlockPos;III)V - -
 method public <init> (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;I)V - -
 method public b (III)I - -
 method public a (Lnet/minecraft/core/BlockPos;)I - -
 method public b (Lnet/minecraft/core/BlockPos;)I - -
 method public c (Lnet/minecraft/core/BlockPos;)Z - -
 method public a ()V - -
 method public b ()V - -
 method public c ()I - -
 method public d ()Lnet/minecraft/core/BlockPos; - -
 method public e ()Lnet/minecraft/core/BlockPos; - -
 method public f ()I - -
 method public g ()I - -
 method public h ()I - -
 method public a (I)V - -
 method public i ()Z - -
 method public a (Z)V - -
 method public j ()Lnet/minecraft/core/Direction; - -
in 131
class ajg 52 public,super java/lang/Object - -
 inner ajg$a ajg a -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public a (Lnet/minecraft/world/level/Level;)V - -
 method public a (I)V - -
 method public a ()Lnet/minecraft/core/BlockPos; - -
 method public b ()I - -
 method public c ()I - -
 method public d ()I - -
 method public e ()I - -
 method public a (Lnet/minecraft/core/BlockPos;)Z - -
 method public f ()Ljava/util/List; ()Ljava/util/List<Lajf;>; -
 method public b (Lnet/minecraft/core/BlockPos;)Lajf; - -
 method public c (Lnet/minecraft/core/BlockPos;)Lajf; - -
 method public e (Lnet/minecraft/core/BlockPos;)Lajf; - -
 method public a (Lajf;)V - -
 method public g ()Z - -
 method public a (Lnet/minecraft/world/entity/LivingEntity;)V - -
 method public b (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public c (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/player/Player; - -
 method public a (Ljava/lang/String;)I - -
 method public a (Ljava/lang/String;I)I - -
 method public d (Ljava/lang/String;)Z - -
 method public a (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public b (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public h ()V - -
 method public i ()Z - -
 method public b (I)V - -
in 135
class ajg 52 public,super net/minecraftforge/common/capabilities/CapabilityProvider net/minecraftforge/common/extensions/IForgeVillage Lnet/minecraftforge/common/capabilities/CapabilityProvider<Lajg;>;Lnet/minecraftforge/common/extensions/IForgeVillage;
 inner ajg$a ajg a -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public a (Lnet/minecraft/world/level/Level;)V - -
 method public a (I)V - -
 method public a ()Lnet/minecraft/core/BlockPos; - -
 method public b ()I - -
 method public c ()I - -
 method public d ()I - -
 method public e ()I - -
 method public a (Lnet/minecraft/core/BlockPos;)Z - -
 method public f ()Ljava/util/List; ()Ljava/util/List<Lajf;>; -
 method public b (Lnet/minecraft/core/BlockPos;)Lajf; - -
 method public c (Lnet/minecraft/core/BlockPos;)Lajf; - -
 method public e (Lnet/minecraft/core/BlockPos;)Lajf; - -
 method public a (Lajf;)V - -
 method public g ()Z - -
 method public a (Lnet/minecraft/world/entity/LivingEntity;)V - -
 method public b (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/LivingEntity; - -
 method public c (Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/player/Player; - -
 method public,deprecated a (Ljava/lang/String;)I - -
 method public getPlayerReputation (Ljava/util/UUID;)I - -
 method public,deprecated a (Ljava/lang/String;I)I - -
 method public modifyPlayerReputation (Ljava/util/UUID;I)I - -
 method public d (Ljava/lang/String;)Z - -
 method public isPlayerReputationTooLow (Ljava/util/UUID;)Z - -
 method public a (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public b (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public h ()V - -
 method public i ()Z - -
 method public b (I)V - -
in 59
class ajg$a 52 super java/lang/Object - -
 inner ajg$a ajg a -
 field public a Lnet/minecraft/world/entity/LivingEntity; -
 field public b I -
in 59
class aji 52 public,super net/minecraft/world/level/saveddata/SavedData - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public a (Lnet/minecraft/world/level/Level;)V - -
 method public a (Lnet/minecraft/core/BlockPos;)V - -
 method public a ()V - -
 method public b ()Ljava/util/List; ()Ljava/util/List<Lajg;>; -
 method public a (Lnet/minecraft/core/BlockPos;I)Lajg; - -
 method public load (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public save (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public,static a (Lnet/minecraft/world/level/dimension/Dimension;)Ljava/lang/String; - -
in 59
class ajk 52 public,super,abstract net/minecraft/world/entity/Mob aeq -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method public canBeLeashed (Lnet/minecraft/world/entity/player/Player;)Z - -
in 59
class ajo 52 public,super,abstract net/minecraft/world/entity/PathfinderMob aeq -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method public causeFallDamage (FF)V - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method public getAmbientSoundInterval ()I - -
 method public H ()Z - -
in 59
class ajs 52 public,super net/minecraft/world/entity/animal/AbstractSchoolingFish - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected getBucketItemStack ()Lnet/minecraft/world/item/ItemStack; - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getFlopSound ()Lnet/minecraft/sounds/SoundEvent; - -
in 59
class ajt 52 public,super net/minecraft/world/entity/animal/Animal - -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected registerGoals ()V - -
 method protected registerAttributes ()V - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method protected getSoundVolume ()F - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method public mobInteract (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Z - -
 method public getBreedOffspring (Lnet/minecraft/world/entity/AgableMob;)Lajt; - -
 method public getEyeHeight ()F - -
in 131
class ajx 52 public,super ajt - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public mobInteract (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Z - -
 method public getBreedOffspring (Lnet/minecraft/world/entity/AgableMob;)Lajx; - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
in 135
class ajx 52 public,super ajt net/minecraftforge/common/IShearable -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public mobInteract (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Z - -
 method public getBreedOffspring (Lnet/minecraft/world/entity/AgableMob;)Lajx; - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method public isShearable (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/LevelReader;Lnet/minecraft/core/BlockPos;)Z - -
 method public onSheared (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;I)Ljava/util/List; (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;I)Ljava/util/List<Lnet/minecraft/world/item/ItemStack;>; -
in 59
class ake 52 public,super net/minecraft/world/entity/animal/AbstractSchoolingFish - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public getMaxSchoolSize ()I - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getBucketItemStack ()Lnet/minecraft/world/item/ItemStack; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getFlopSound ()Lnet/minecraft/sounds/SoundEvent; - -
in 59
class akl 52 public,super,abstract net/minecraft/world/entity/PathfinderMob aeq -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method public canBreatheUnderwater ()Z - -
 method public getMobType ()Lnet/minecraft/world/entity/MobType; - -
 method public checkSpawnObstruction (Layc;)Z - -
 method public getAmbientSoundInterval ()I - -
 method public H ()Z - -
 method protected getExperienceReward (Lnet/minecraft/world/entity/player/Player;)I - -
 method protected handleAirSupply (I)V - -
 method public baseTick ()V - -
 method public isPushedByWater ()Z - -
 method public canBeLeashed (Lnet/minecraft/world/entity/player/Player;)Z - -
in 59
class akp 52 public,super net/minecraft/world/entity/animal/horse/AbstractChestedHorse - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method public canMate (Lnet/minecraft/world/entity/animal/Animal;)Z - -
 method public getBreedOffspring (Lnet/minecraft/world/entity/AgableMob;)Lnet/minecraft/world/entity/AgableMob; - -
in 131
class akr 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lakr;>;
 field public,static,final,enum NONE Lakr; -
 field public,static,final,enum IRON Lakr; -
 field public,static,final,enum GOLD Lakr; -
 field public,static,final,enum DIAMOND Lakr; -
 method public b ()Ljava/lang/String; - -
 method public d ()Ljava/lang/String; - -
 method public,static values ()[Lakr; - -
 method public,static valueOf (Ljava/lang/String;)Lakr; - -
 method public a ()I - -
 method public c ()I - -
 method public,static a (I)Lakr; - -
 method public,static a (Lnet/minecraft/world/item/ItemStack;)Lakr; - -
 method public,static a (Lnet/minecraft/world/item/Item;)Lakr; - -
 method public,static b (Lnet/minecraft/world/item/Item;)Z - -
in 135
class akr 52 public,final,super,enum java/lang/Enum net/minecraftforge/common/IExtensibleEnum Ljava/lang/Enum<Lakr;>;Lnet/minecraftforge/common/IExtensibleEnum;
 field public,static,final,enum NONE Lakr; -
 field public,static,final,enum IRON Lakr; -
 field public,static,final,enum GOLD Lakr; -
 field public,static,final,enum DIAMOND Lakr; -
 method public,static values ()[Lakr; - -
 method public,static valueOf (Ljava/lang/String;)Lakr; - -
 method public,static create (Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Lnet/minecraft/world/item/Item;)Lakr; - -
 method public a ()I - -
 method public b ()Ljava/lang/String; - -
 method public c ()I - -
 method public d ()Ljava/lang/String; - -
 method public,static,deprecated a (I)Lakr; - -
 method public,static a (Lnet/minecraft/world/item/ItemStack;)Lakr; - -
 method public,static,deprecated a (Lnet/minecraft/world/item/Item;)Lakr; - -
 method public,static,deprecated b (Lnet/minecraft/world/item/Item;)Z - -
 method public,static isHorseArmor (Lnet/minecraft/world/item/ItemStack;)Z - -
in 59
class akt 52 public,super net/minecraft/world/entity/animal/horse/AbstractChestedHorse - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected playChestEquipsSound ()V - -
in 59
class akw 52 public,super net/minecraft/world/entity/animal/horse/AbstractHorse - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected registerAttributes ()V - -
 method public getMobType ()Lnet/minecraft/world/entity/MobType; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method public getBreedOffspring (Lnet/minecraft/world/entity/AgableMob;)Lnet/minecraft/world/entity/AgableMob; - -
 method public mobInteract (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Z - -
 method protected addBehaviourGoals ()V - -
in 59
class ala 52 public,interface,abstract java/lang/Object - -
 method public,abstract J_ ()Lnet/minecraft/world/level/Level; - -
 method public,abstract a (Lalb;Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
 method public,abstract getType ()Lnet/minecraft/world/entity/EntityType; ()Lnet/minecraft/world/entity/EntityType<*>; -
in 59
class alb 52 public,super net/minecraft/world/entity/Entity - -
 field public,final a Lala; -
 field public,final b Ljava/lang/String; -
 method public <init> (Lala;Ljava/lang/String;FF)V - -
 method protected defineSynchedData ()V - -
 method protected readAdditionalSaveData (Lnet/minecraft/nbt/CompoundTag;)V - -
 method protected b (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public isPickable ()Z - -
 method public hurt (Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
 method public is (Lnet/minecraft/world/entity/Entity;)Z - -
in 59
class alg 52 public,super,abstract net/minecraft/world/entity/boss/enderdragon/phases/AbstractDragonPhaseInstance - -
 method public <init> (Lnet/minecraft/world/entity/boss/enderdragon/EnderDragon;)V - -
 method public isSitting ()Z - -
 method public a (Lalb;Lnet/minecraft/world/damagesource/DamageSource;F)F - -
in 131
class amc 52 public,super net/minecraft/world/entity/decoration/HangingEntity - -
 method public shouldRenderAtSqrDistance (D)Z - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)V - -
 method public setPos (DDD)V - -
 method protected recalculateBoundingBox ()V - -
 method public setDirection (Lnet/minecraft/core/Direction;)V - -
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public getEyeHeight ()F - -
 method public dropItem (Lnet/minecraft/world/entity/Entity;)V - -
 method public b (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public readAdditionalSaveData (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public interact (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Z - -
 method public survives ()Z - -
 method public,static a (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)Lamc; - -
 method public,static b (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)Lamc; - -
 method public playPlacementSound ()V - -
in 135
class amc 52 public,super net/minecraft/world/entity/decoration/HangingEntity - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)V - -
 method public setPos (DDD)V - -
 method protected recalculateBoundingBox ()V - -
 method public setDirection (Lnet/minecraft/core/Direction;)V - -
 method public getWidth ()I - -
 method public getHeight ()I - -
 method public getEyeHeight ()F - -
 method public shouldRenderAtSqrDistance (D)Z - -
 method public dropItem (Lnet/minecraft/world/entity/Entity;)V - -
 method public b (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public readAdditionalSaveData (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public interact (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Z - -
 method public survives ()Z - -
 method public,static a (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)Lamc; - -
 method public,static b (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)Lamc; - -
 method public playPlacementSound ()V - -
in 59
class ami 52 public,super,abstract net/minecraft/world/entity/Entity - -
 method public <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
in 131
class amp 52 public,super,abstract ang - -
 inner net/minecraft/world/entity/monster/AbstractIllager$IllagerArmPose amp IllagerArmPose public,static,final,enum
 field protected,static,final a Lnet/minecraft/network/syncher/EntityDataAccessor; Lnet/minecraft/network/syncher/EntityDataAccessor<Ljava/lang/Byte;>;
 method protected a (I)Z - -
 method public getArmPose ()Lnet/minecraft/world/entity/monster/AbstractIllager$IllagerArmPose; - -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method protected defineSynchedData ()V - -
 method protected a (IZ)V - -
 method public getMobType ()Lnet/minecraft/world/entity/MobType; - -
in 135
class amp 52 public,super,abstract ang - -
 inner net/minecraft/world/entity/monster/AbstractIllager$IllagerArmPose amp IllagerArmPose public,static,final,enum
 field protected,static,final a Lnet/minecraft/network/syncher/EntityDataAccessor; Lnet/minecraft/network/syncher/EntityDataAccessor<Ljava/lang/Byte;>;
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method protected defineSynchedData ()V - -
 method protected a (I)Z - -
 method protected a (IZ)V - -
 method public getMobType ()Lnet/minecraft/world/entity/MobType; - -
 method public getArmPose ()Lnet/minecraft/world/entity/monster/AbstractIllager$IllagerArmPose; - -
in 59
class ams 52 public,super net/minecraft/world/entity/monster/Spider - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected registerAttributes ()V - -
 method public doHurtTarget (Lnet/minecraft/world/entity/Entity;)Z - -
 method public a (Lnet/minecraft/world/DifficultyInstance;Lafj;Lnet/minecraft/nbt/CompoundTag;)Lafj; - -
 method public getEyeHeight ()F - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
in 59
class anb 52 public,super ang - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public getEyeHeight ()F - -
 method protected registerAttributes ()V - -
 method public getWalkTargetValue (Lnet/minecraft/core/BlockPos;Layc;)F - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
in 59
class and 52 public,super net/minecraft/world/entity/monster/Zombie - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Z)Z - -
 method protected isSunSensitive ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method public doHurtTarget (Lnet/minecraft/world/entity/Entity;)Z - -
 method protected convertsInWater ()Z - -
 method protected doUnderWaterConversion ()V - -
 method protected getSkull ()Lnet/minecraft/world/item/ItemStack; - -
in 131
class anf 52 public,super net/minecraft/world/entity/monster/Slime - -
 method public getLightColor ()I - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected registerAttributes ()V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Z)Z - -
 method public checkSpawnObstruction (Layc;)Z - -
 method protected setSize (IZ)V - -
 method public getBrightness ()F - -
 method protected getParticleType ()Lnet/minecraft/core/particles/ParticleOptions; - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method public isOnFire ()Z - -
 method protected getJumpDelay ()I - -
 method protected decreaseSquish ()V - -
 method protected jumpFromGround ()V - -
 method protected jumpInLiquid (Lnet/minecraft/tags/Tag;)V (Lnet/minecraft/tags/Tag<Lnet/minecraft/world/level/material/Fluid;>;)V -
 method public causeFallDamage (FF)V - -
 method protected isDealsDamage ()Z - -
 method protected getAttackDamage ()I - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getSquishSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getJumpSound ()Lnet/minecraft/sounds/SoundEvent; - -
in 135
class anf 52 public,super net/minecraft/world/entity/monster/Slime - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected registerAttributes ()V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Z)Z - -
 method public checkSpawnObstruction (Layc;)Z - -
 method protected setSize (IZ)V - -
 method public getLightColor ()I - -
 method public getBrightness ()F - -
 method protected getParticleType ()Lnet/minecraft/core/particles/ParticleOptions; - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method public isOnFire ()Z - -
 method protected getJumpDelay ()I - -
 method protected decreaseSquish ()V - -
 method protected jumpFromGround ()V - -
 method protected jumpInLiquid (Lnet/minecraft/tags/Tag;)V (Lnet/minecraft/tags/Tag<Lnet/minecraft/world/level/material/Fluid;>;)V -
 method public causeFallDamage (FF)V - -
 method protected isDealsDamage ()Z - -
 method protected getAttackDamage ()I - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getSquishSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getJumpSound ()Lnet/minecraft/sounds/SoundEvent; - -
in 59
class ang 52 public,super,abstract net/minecraft/world/entity/PathfinderMob net/minecraft/world/entity/monster/Enemy -
 method protected <init> (Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/level/Level;)V (Lnet/minecraft/world/entity/EntityType<*>;Lnet/minecraft/world/level/Level;)V -
 method public getSoundSource ()Lnet/minecraft/sounds/SoundSource; - -
 method public aiStep ()V - -
 method public tick ()V - -
 method protected getSwimSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getSwimSplashSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method public hurt (Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getFallDamageSound (I)Lnet/minecraft/sounds/SoundEvent; - -
 method public getWalkTargetValue (Lnet/minecraft/core/BlockPos;Layc;)F - -
 method protected K_ ()Z - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Z)Z - -
 method protected registerAttributes ()V - -
 method protected shouldDropExperience ()Z - -
 method public isPreventingPlayerRest (Lnet/minecraft/world/entity/player/Player;)Z - -
in 131
class anm 52 public,super ang - -
 inner net/minecraft/world/entity/monster/Silverfish$SilverfishMergeWithStoneGoal anm SilverfishMergeWithStoneGoal static
 inner net/minecraft/world/entity/monster/Silverfish$SilverfishWakeUpFriendsGoal anm SilverfishWakeUpFriendsGoal static
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected registerGoals ()V - -
 method public getRidingHeight ()D - -
 method public getEyeHeight ()F - -
 method protected registerAttributes ()V - -
 method protected makeStepSound ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public hurt (Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method public tick ()V - -
 method public setYBodyRot (F)V - -
 method public getWalkTargetValue (Lnet/minecraft/core/BlockPos;Layc;)F - -
 method protected K_ ()Z - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Z)Z - -
 method public getMobType ()Lnet/minecraft/world/entity/MobType; - -
in 135
class anm 52 public,super ang - -
 inner net/minecraft/world/entity/monster/Silverfish$SilverfishWakeUpFriendsGoal anm SilverfishWakeUpFriendsGoal static
 inner net/minecraft/world/entity/monster/Silverfish$SilverfishMergeWithStoneGoal anm SilverfishMergeWithStoneGoal static
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected registerGoals ()V - -
 method public getRidingHeight ()D - -
 method public getEyeHeight ()F - -
 method protected registerAttributes ()V - -
 method protected makeStepSound ()Z - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected playStepSound (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public hurt (Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method public tick ()V - -
 method public setYBodyRot (F)V - -
 method public getWalkTargetValue (Lnet/minecraft/core/BlockPos;Layc;)F - -
 method protected K_ ()Z - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Z)Z - -
 method public getMobType ()Lnet/minecraft/world/entity/MobType; - -
in 131
class ann 52 public,super net/minecraft/world/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method public die (Lnet/minecraft/world/damagesource/DamageSource;)V - -
 method protected a (F)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
in 135
class ann 52 public,super net/minecraft/world/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method public die (Lnet/minecraft/world/damagesource/DamageSource;)V - -
 method protected a (F)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
in 131
class anr 52 public,super net/minecraft/world/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Z)Z - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected a (F)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
in 135
class anr 52 public,super net/minecraft/world/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Z)Z - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected a (F)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
in 131
class anv 52 public,super net/minecraft/world/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method public die (Lnet/minecraft/world/damagesource/DamageSource;)V - -
 method protected populateDefaultEquipmentSlots (Lnet/minecraft/world/DifficultyInstance;)V - -
 method protected populateDefaultEquipmentEnchantments (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public a (Lnet/minecraft/world/DifficultyInstance;Lafj;Lnet/minecraft/nbt/CompoundTag;)Lafj; - -
 method public getEyeHeight ()F - -
 method public doHurtTarget (Lnet/minecraft/world/entity/Entity;)Z - -
 method protected a (F)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
in 135
class anv 52 public,super net/minecraft/world/entity/monster/AbstractSkeleton - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method protected getDefaultLootTable ()Lnet/minecraft/resources/ResourceLocation; - -
 method protected getAmbientSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getHurtSound (Lnet/minecraft/world/damagesource/DamageSource;)Lnet/minecraft/sounds/SoundEvent; - -
 method protected getDeathSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method protected getStepSound ()Lnet/minecraft/sounds/SoundEvent; - -
 method public die (Lnet/minecraft/world/damagesource/DamageSource;)V - -
 method protected populateDefaultEquipmentSlots (Lnet/minecraft/world/DifficultyInstance;)V - -
 method protected populateDefaultEquipmentEnchantments (Lnet/minecraft/world/DifficultyInstance;)V - -
 method public a (Lnet/minecraft/world/DifficultyInstance;Lafj;Lnet/minecraft/nbt/CompoundTag;)Lafj; - -
 method public getEyeHeight ()F - -
 method public doHurtTarget (Lnet/minecraft/world/entity/Entity;)Z - -
 method protected a (F)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
in 59
class aoa 52 public,interface,abstract java/lang/Object aeq -
in 131
class aon 52 public,super net/minecraft/world/entity/projectile/AbstractHurtingProjectile - -
 method public <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;DDD)V - -
 method protected onHit (Lnet/minecraft/world/phys/HitResult;)V - -
 method public isPickable ()Z - -
 method public hurt (Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
 method protected getTrailParticle ()Lnet/minecraft/core/particles/ParticleOptions; - -
 method protected shouldBurn ()Z - -
in 135
class aon 52 public,super net/minecraft/world/entity/projectile/AbstractHurtingProjectile - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;DDD)V - -
 method protected onHit (Lnet/minecraft/world/phys/HitResult;)V - -
 method public isPickable ()Z - -
 method public hurt (Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
 method protected getTrailParticle ()Lnet/minecraft/core/particles/ParticleOptions; - -
 method protected shouldBurn ()Z - -
in 59
class aow 52 public,super net/minecraft/world/entity/projectile/AbstractHurtingProjectile - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;DDD)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method protected onHit (Lnet/minecraft/world/phys/HitResult;)V - -
 method public isPickable ()Z - -
 method public hurt (Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
in 131
class aox 52 public,super net/minecraft/world/entity/projectile/ThrowableProjectile - -
 method public handleEntityEvent (B)V - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method protected onHit (Lnet/minecraft/world/phys/HitResult;)V - -
in 135
class aox 52 public,super net/minecraft/world/entity/projectile/ThrowableProjectile - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method public handleEntityEvent (B)V - -
 method protected onHit (Lnet/minecraft/world/phys/HitResult;)V - -
in 131
class apa 52 public,super net/minecraft/world/entity/projectile/ThrowableProjectile - -
 method public handleEntityEvent (B)V - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method protected onHit (Lnet/minecraft/world/phys/HitResult;)V - -
in 135
class apa 52 public,super net/minecraft/world/entity/projectile/ThrowableProjectile - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method public handleEntityEvent (B)V - -
 method protected onHit (Lnet/minecraft/world/phys/HitResult;)V - -
in 59
class apc 52 public,super net/minecraft/world/entity/projectile/ThrowableProjectile - -
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method protected getGravity ()F - -
 method protected onHit (Lnet/minecraft/world/phys/HitResult;)V - -
in 59
class apk 52 public,super net/minecraft/world/entity/vehicle/AbstractMinecart - -
 inner net/minecraft/world/entity/vehicle/AbstractMinecart$Type net/minecraft/world/entity/vehicle/AbstractMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method public interact (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Z - -
 method public activateMinecart (IIIZ)V - -
 method public getMinecartType ()Lnet/minecraft/world/entity/vehicle/AbstractMinecart$Type; - -
in 59
class apl 52 public,super net/minecraft/world/entity/vehicle/AbstractMinecartContainer - -
 inner net/minecraft/world/entity/vehicle/AbstractMinecart$Type net/minecraft/world/entity/vehicle/AbstractMinecart Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/level/Level;)V - -
 method public <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method public destroy (Lnet/minecraft/world/damagesource/DamageSource;)V - -
 method public getContainerSize ()I - -
 method public getMinecartType ()Lnet/minecraft/world/entity/vehicle/AbstractMinecart$Type; - -
 method public getDefaultDisplayBlockState ()Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getDefaultDisplayOffset ()I - -
 method public l ()Ljava/lang/String; - -
 method public a (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/inventory/AbstractContainerMenu; - -
in 59
class aqb 52 public,interface,abstract java/lang/Object - -
 method public,abstract refreshContainer (Lnet/minecraft/world/inventory/AbstractContainerMenu;Lnet/minecraft/core/NonNullList;)V (Lnet/minecraft/world/inventory/AbstractContainerMenu;Lnet/minecraft/core/NonNullList<Lnet/minecraft/world/item/ItemStack;>;)V -
 method public,abstract slotChanged (Lnet/minecraft/world/inventory/AbstractContainerMenu;ILnet/minecraft/world/item/ItemStack;)V - -
 method public,abstract setContainerData (Lnet/minecraft/world/inventory/AbstractContainerMenu;II)V - -
 method public,abstract a (Lnet/minecraft/world/inventory/AbstractContainerMenu;Lnet/minecraft/world/Container;)V - -
in 131
class aqh 52 public,super aqr - -
 method public getSize ()I - -
 method public setData (II)V - -
 method public <init> (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/Container;)V - -
 method public addSlotListener (Laqb;)V - -
 method public fillCraftSlotsStackedContents (Lnet/minecraft/world/entity/player/StackedContents;)V - -
 method public clearCraftingContent ()V - -
 method public recipeMatches (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public getResultSlotIndex ()I - -
 method public getGridWidth ()I - -
 method public getGridHeight ()I - -
 method public broadcastChanges ()V - -
 method public stillValid (Lnet/minecraft/world/entity/player/Player;)Z - -
 method public quickMoveStack (Lnet/minecraft/world/entity/player/Player;I)Lnet/minecraft/world/item/ItemStack; - -
in 135
class aqh 52 public,super aqr - -
 method public <init> (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/Container;)V - -
 method public addSlotListener (Laqb;)V - -
 method public fillCraftSlotsStackedContents (Lnet/minecraft/world/entity/player/StackedContents;)V - -
 method public clearCraftingContent ()V - -
 method public recipeMatches (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public getResultSlotIndex ()I - -
 method public getGridWidth ()I - -
 method public getGridHeight ()I - -
 method public getSize ()I - -
 method public broadcastChanges ()V - -
 method public setData (II)V - -
 method public stillValid (Lnet/minecraft/world/entity/player/Player;)Z - -
 method public quickMoveStack (Lnet/minecraft/world/entity/player/Player;I)Lnet/minecraft/world/item/ItemStack; - -
in 59
class aqk 52 public,super net/minecraft/world/SimpleContainer - -
 method public <init> (Lnet/minecraft/network/chat/Component;I)V - -
in 131
class aqr 52 public,super,abstract net/minecraft/world/inventory/AbstractContainerMenu - -
 method public,abstract getSize ()I - -
 method public <init> ()V - -
 method public,abstract fillCraftSlotsStackedContents (Lnet/minecraft/world/entity/player/StackedContents;)V - -
 method public,abstract clearCraftingContent ()V - -
 method public,abstract recipeMatches (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public,abstract getResultSlotIndex ()I - -
 method public,abstract getGridWidth ()I - -
 method public,abstract getGridHeight ()I - -
in 135
class aqr 52 public,super,abstract net/minecraft/world/inventory/AbstractContainerMenu - -
 method public <init> ()V - -
 method public,abstract fillCraftSlotsStackedContents (Lnet/minecraft/world/entity/player/StackedContents;)V - -
 method public,abstract clearCraftingContent ()V - -
 method public,abstract recipeMatches (Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public,abstract getResultSlotIndex ()I - -
 method public,abstract getGridWidth ()I - -
 method public,abstract getGridHeight ()I - -
 method public,abstract getSize ()I - -
in 59
class aqw 52 public,super net/minecraft/world/inventory/Slot - -
 method public <init> (Lnet/minecraft/world/Container;III)V - -
 method public mayPlace (Lnet/minecraft/world/item/ItemStack;)Z - -
in 131
class arf 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public createArrow (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
in 135
class arf 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public createArrow (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
 method public isInfinite (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/player/Player;)Z - -
in 59
class ari 52 public,super net/minecraft/world/item/BlockItem - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method protected placeBlock (Lnet/minecraft/world/item/BlockPlaceContext;Lnet/minecraft/world/level/block/state/BlockState;)Z - -
in 59
class arn 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public isEnchantable (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public getEnchantmentValue ()I - -
in 59
class arq 52 public,super asv - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (ILnet/minecraft/world/item/Item$Properties;)V - -
 method public finishUsingItem (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack; - -
in 59
class ars 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 59
class art 52 public,super asv - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (IFLnet/minecraft/world/item/Item$Properties;)V - -
 method public finishUsingItem (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack; - -
in 59
class aru 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
in 59
class arv 52 public,super net/minecraft/world/item/DyeItem - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/DyeColor;Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
in 59
class arw 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
in 59
class arx 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public isComplex ()Z - -
 method public getUpdatePacket (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;)Liv; (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;)Liv<*>; -
in 59
class asb 52 public,super net/minecraft/world/item/BlockItem - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method protected placeBlock (Lnet/minecraft/world/item/BlockPlaceContext;Lnet/minecraft/world/level/block/state/BlockState;)Z - -
in 59
class asf 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 59
class ash 52 public,super arx - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 131
class asj 52 public,super asv - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public <init> (IFZLnet/minecraft/world/item/Item$Properties;)V - -
 method protected a (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;)V - -
in 135
class asj 52 public,super asv - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (IFZLnet/minecraft/world/item/Item$Properties;)V - -
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
 method protected a (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;)V - -
in 131
class ask 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
in 135
class ask 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
in 59
class asl 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 inner net/minecraft/world/level/block/state/pattern/BlockPattern$BlockPatternMatch net/minecraft/world/level/block/state/pattern/BlockPattern BlockPatternMatch public,static
 inner net/minecraft/world/phys/HitResult$Type net/minecraft/world/phys/HitResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 59
class asm 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 131
class asn 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 135
class asn 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 59
class aso 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
in 131
class asp 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/FireworkRocketItem$Shape asp Shape public,static,final,enum
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public appendHoverText (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List<Lnet/minecraft/network/chat/Component;>;Lnet/minecraft/world/item/TooltipFlag;)V -
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 135
class asp 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/FireworkRocketItem$Shape asp Shape public,static,final,enum
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
 method public appendHoverText (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List<Lnet/minecraft/network/chat/Component;>;Lnet/minecraft/world/item/TooltipFlag;)V -
in 59
class ass 52 public,super asv - -
 inner ass$a ass a public,static,final,enum
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lass$a;ZLnet/minecraft/world/item/Item$Properties;)V - -
 method public e (Lnet/minecraft/world/item/ItemStack;)I - -
 method public f (Lnet/minecraft/world/item/ItemStack;)F - -
 method protected a (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;)V - -
in 59
class ass$a 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lass$a;>;
 inner ass$a ass a public,static,final,enum
 field public,static,final,enum a Lass$a; -
 field public,static,final,enum b Lass$a; -
 field public,static,final,enum c Lass$a; -
 field public,static,final,enum d Lass$a; -
 method public,static values ()[Lass$a; - -
 method public,static valueOf (Ljava/lang/String;)Lass$a; - -
 method public a ()I - -
 method public b ()F - -
 method public c ()I - -
 method public d ()F - -
 method public e ()Z - -
 method public,static a (Lnet/minecraft/world/item/ItemStack;)Lass$a; - -
in 59
class asu 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 inner net/minecraft/core/Direction$Plane net/minecraft/core/Direction Plane public,static,final,enum
 inner net/minecraft/world/level/block/NetherPortalBlock$PortalShape net/minecraft/world/level/block/NetherPortalBlock PortalShape public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method public,static a (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;)Z - -
in 59
class asv 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (IFZLnet/minecraft/world/item/Item$Properties;)V - -
 method public finishUsingItem (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack; - -
 method protected a (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;)V - -
 method public getUseDuration (Lnet/minecraft/world/item/ItemStack;)I - -
 method public getUseAnimation (Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/UseAnim; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
 method public e (Lnet/minecraft/world/item/ItemStack;)I - -
 method public f (Lnet/minecraft/world/item/ItemStack;)F - -
 method public d ()Z - -
 method public a (Lnet/minecraft/world/effect/MobEffectInstance;F)Lasv; - -
 method public e ()Lasv; - -
 method public f ()Lasv; - -
in 59
class asw 52 public,super net/minecraft/world/item/BlockItem - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method protected getPlacementState (Lnet/minecraft/world/item/BlockPlaceContext;)Lnet/minecraft/world/level/block/state/BlockState; - -
in 59
class asx 52 public,super asv - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (IFZLnet/minecraft/world/item/Item$Properties;)V - -
 method protected a (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;)V - -
in 59
class asy 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method public <init> (Ljava/lang/Class;Lnet/minecraft/world/item/Item$Properties;)V (Ljava/lang/Class<+Lnet/minecraft/world/entity/decoration/HangingEntity;>;Lnet/minecraft/world/item/Item$Properties;)V -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method protected mayPlace (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/Direction;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;)Z - -
in 59
class atc 52 public,super asy - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method protected mayPlace (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/Direction;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;)Z - -
in 131
class ati 52 public,super atp - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public appendHoverText (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List<Lnet/minecraft/network/chat/Component;>;Lnet/minecraft/world/item/TooltipFlag;)V -
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 135
class ati 52 public,super atp - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public appendHoverText (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List<Lnet/minecraft/network/chat/Component;>;Lnet/minecraft/world/item/TooltipFlag;)V -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 131
class atk 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public finishUsingItem (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack; - -
 method public getUseDuration (Lnet/minecraft/world/item/ItemStack;)I - -
 method public getUseAnimation (Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/UseAnim; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 135
class atk 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public finishUsingItem (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack; - -
 method public getUseDuration (Lnet/minecraft/world/item/ItemStack;)I - -
 method public getUseAnimation (Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/UseAnim; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
 method public initCapabilities (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraftforge/common/capabilities/ICapabilityProvider; - -
in 59
class atm 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public interactEnemy (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/InteractionHand;)Z - -
in 59
class ato 52 public,super net/minecraft/world/item/StandingAndWallBlockItem - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method public getName (Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/network/chat/Component; - -
 method public verifyTagAfterLoad (Lnet/minecraft/nbt/CompoundTag;)Z - -
in 131
class atp 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public getDefaultInstance ()Lnet/minecraft/world/item/ItemStack; - -
 method public appendHoverText (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List<Lnet/minecraft/network/chat/Component;>;Lnet/minecraft/world/item/TooltipFlag;)V -
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public finishUsingItem (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack; - -
 method public getUseDuration (Lnet/minecraft/world/item/ItemStack;)I - -
 method public getUseAnimation (Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/UseAnim; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
 method public getDescriptionId (Lnet/minecraft/world/item/ItemStack;)Ljava/lang/String; - -
 method public fillItemCategory (Lnet/minecraft/world/item/CreativeModeTab;Lnet/minecraft/core/NonNullList;)V (Lnet/minecraft/world/item/CreativeModeTab;Lnet/minecraft/core/NonNullList<Lnet/minecraft/world/item/ItemStack;>;)V -
in 135
class atp 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public getDefaultInstance ()Lnet/minecraft/world/item/ItemStack; - -
 method public finishUsingItem (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack; - -
 method public getUseDuration (Lnet/minecraft/world/item/ItemStack;)I - -
 method public getUseAnimation (Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/UseAnim; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
 method public getDescriptionId (Lnet/minecraft/world/item/ItemStack;)Ljava/lang/String; - -
 method public appendHoverText (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List<Lnet/minecraft/network/chat/Component;>;Lnet/minecraft/world/item/TooltipFlag;)V -
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public fillItemCategory (Lnet/minecraft/world/item/CreativeModeTab;Lnet/minecraft/core/NonNullList;)V (Lnet/minecraft/world/item/CreativeModeTab;Lnet/minecraft/core/NonNullList<Lnet/minecraft/world/item/ItemStack;>;)V -
in 59
class ats 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public interactEnemy (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/InteractionHand;)Z - -
in 131
class att 52 public,super asv - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (IFLnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
in 135
class att 52 public,super asv net/minecraftforge/common/IPlantable -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (IFLnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method public getPlantType (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Lnet/minecraftforge/common/EnumPlantType; - -
 method public getPlant (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
in 131
class atu 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
in 135
class atu 52 public,super net/minecraft/world/item/Item net/minecraftforge/common/IPlantable -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method public getPlantType (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Lnet/minecraftforge/common/EnumPlantType; - -
 method public getPlant (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
in 131
class atw 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public mineBlock (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/LivingEntity;)Z - -
 method public canDestroySpecial (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getDestroySpeed (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/block/state/BlockState;)F - -
in 135
class atw 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public mineBlock (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/LivingEntity;)Z - -
 method public canDestroySpecial (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getDestroySpeed (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/block/state/BlockState;)F - -
 method public interactEnemy (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/InteractionHand;)Z - -
 method public onBlockStartBreak (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;)Z - -
in 59
class atz 52 public,super net/minecraft/world/item/StandingAndWallBlockItem - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method protected updateCustomBlockEntityTag (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/block/state/BlockState;)Z - -
in 131
class aua 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
in 135
class aua 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public isFoil (Lnet/minecraft/world/item/ItemStack;)Z - -
in 59
class aub 52 public,super net/minecraft/world/item/Item - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 59
class aud 52 public,super arf - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public createArrow (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
in 59
class aue 52 public,super atp - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 59
class aug 52 public,super net/minecraft/world/item/BlockItem - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public getDescriptionId ()Ljava/lang/String; - -
in 131
class aul 52 public,super arf - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public getDefaultInstance ()Lnet/minecraft/world/item/ItemStack; - -
 method public appendHoverText (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List<Lnet/minecraft/network/chat/Component;>;Lnet/minecraft/world/item/TooltipFlag;)V -
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public createArrow (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
 method public fillItemCategory (Lnet/minecraft/world/item/CreativeModeTab;Lnet/minecraft/core/NonNullList;)V (Lnet/minecraft/world/item/CreativeModeTab;Lnet/minecraft/core/NonNullList<Lnet/minecraft/world/item/ItemStack;>;)V -
 method public getDescriptionId (Lnet/minecraft/world/item/ItemStack;)Ljava/lang/String; - -
in 135
class aul 52 public,super arf - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 method public <init> (Lnet/minecraft/world/item/Item$Properties;)V - -
 method public getDefaultInstance ()Lnet/minecraft/world/item/ItemStack; - -
 method public createArrow (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/entity/projectile/AbstractArrow; - -
 method public fillItemCategory (Lnet/minecraft/world/item/CreativeModeTab;Lnet/minecraft/core/NonNullList;)V (Lnet/minecraft/world/item/CreativeModeTab;Lnet/minecraft/core/NonNullList<Lnet/minecraft/world/item/ItemStack;>;)V -
 method public appendHoverText (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List;Lnet/minecraft/world/item/TooltipFlag;)V (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Ljava/util/List<Lnet/minecraft/network/chat/Component;>;Lnet/minecraft/world/item/TooltipFlag;)V -
 method public getDescriptionId (Lnet/minecraft/world/item/ItemStack;)Ljava/lang/String; - -
in 59
class auq 52 public,super net/minecraft/world/item/BlockItem - -
 inner net/minecraft/world/item/Item$Properties net/minecraft/world/item/Item Properties public,static
 inner net/minecraft/world/phys/HitResult$Type net/minecraft/world/phys/HitResult Type public,static,final,enum
 method public <init> (Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/item/Item$Properties;)V - -
 method public useOn (Lnet/minecraft/world/item/UseOnContext;)Lnet/minecraft/world/InteractionResult; - -
 method public use (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder; (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/InteractionResultHolder<Lnet/minecraft/world/item/ItemStack;>; -
in 131
class aut 52 public,super java/lang/Object - -
 method public,static byName (Ljava/lang/String;)Laut; - -
 method public,varargs <init> ([Lnet/minecraft/world/effect/MobEffectInstance;)V - -
 method public,varargs <init> (Ljava/lang/String;[Lnet/minecraft/world/effect/MobEffectInstance;)V - -
 method public getName (Ljava/lang/String;)Ljava/lang/String; - -
 method public getEffects ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/world/effect/MobEffectInstance;>; -
 method public,static b ()V - -
 method protected,static a (Ljava/lang/String;Laut;)V - -
 method public hasInstantEffects ()Z - -
in 135
class aut 52 public,super net/minecraftforge/registries/ForgeRegistryEntry - Lnet/minecraftforge/registries/ForgeRegistryEntry<Laut;>;
 method public,static byName (Ljava/lang/String;)Laut; - -
 method public,varargs <init> ([Lnet/minecraft/world/effect/MobEffectInstance;)V - -
 method public,varargs <init> (Ljava/lang/String;[Lnet/minecraft/world/effect/MobEffectInstance;)V - -
 method public getName (Ljava/lang/String;)Ljava/lang/String; - -
 method public getEffects ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/world/effect/MobEffectInstance;>; -
 method public,static b ()V - -
 method protected,static a (Ljava/lang/String;Laut;)V - -
 method public hasInstantEffects ()Z - -
in 131
class auz 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public canCraftInDimensions (II)Z - -
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 135
class auz 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner net/minecraftforge/common/Tags$Items net/minecraftforge/common/Tags Items public,static
 inner avn$a avn a public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public canCraftInDimensions (II)Z - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 131
class ava 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public canCraftInDimensions (II)Z - -
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 135
class ava 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public canCraftInDimensions (II)Z - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 131
class avc 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public canCraftInDimensions (II)Z - -
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/world/Container;)Lnet/minecraft/core/NonNullList; (Lnet/minecraft/world/Container;)Lnet/minecraft/core/NonNullList<Lnet/minecraft/world/item/ItemStack;>; -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 135
class avc 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public getRemainingItems (Lnet/minecraft/world/Container;)Lnet/minecraft/core/NonNullList; (Lnet/minecraft/world/Container;)Lnet/minecraft/core/NonNullList<Lnet/minecraft/world/item/ItemStack;>; -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
 method public canCraftInDimensions (II)Z - -
in 131
class avi 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public canCraftInDimensions (II)Z - -
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 135
class avi 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public canCraftInDimensions (II)Z - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 131
class avn 52 public,super java/lang/Object - -
 inner avn$a avn a public,static,final
 inner net/minecraft/world/item/crafting/ShapedRecipe$Serializer net/minecraft/world/item/crafting/ShapedRecipe Serializer public,static
 inner net/minecraft/world/item/crafting/ShapelessRecipe$Serializer net/minecraft/world/item/crafting/ShapelessRecipe Serializer public,static
 inner net/minecraft/world/item/crafting/SmeltingRecipe$a net/minecraft/world/item/crafting/SmeltingRecipe a public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final a Lnet/minecraft/world/item/crafting/RecipeSerializer; Lnet/minecraft/world/item/crafting/RecipeSerializer<Lnet/minecraft/world/item/crafting/ShapedRecipe;>;
 field public,static,final b Lnet/minecraft/world/item/crafting/RecipeSerializer; Lnet/minecraft/world/item/crafting/RecipeSerializer<Lnet/minecraft/world/item/crafting/ShapelessRecipe;>;
 field public,static,final c Lavn$a; Lavn$a<Lauz;>;
 field public,static,final d Lavn$a; Lavn$a<Lavc;>;
 field public,static,final e Lavn$a; Lavn$a<Lavi;>;
 field public,static,final f Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/MapExtendingRecipe;>;
 field public,static,final g Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/FireworkRocketRecipe;>;
 field public,static,final h Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/FireworkStarRecipe;>;
 field public,static,final i Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/FireworkStarFadeRecipe;>;
 field public,static,final j Lavn$a; Lavn$a<Lavo;>;
 field public,static,final k Lavn$a; Lavn$a<Lavu;>;
 field public,static,final l Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/BannerDuplicateRecipe;>;
 field public,static,final m Lavn$a; Lavn$a<Lava;>;
 field public,static,final n Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/ShieldDecorationRecipe;>;
 field public,static,final o Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/ShulkerBoxColoring;>;
 field public,static,final p Lnet/minecraft/world/item/crafting/RecipeSerializer; Lnet/minecraft/world/item/crafting/RecipeSerializer<Lnet/minecraft/world/item/crafting/SmeltingRecipe;>;
 method public,static a (Lnet/minecraft/world/item/crafting/RecipeSerializer;)Lnet/minecraft/world/item/crafting/RecipeSerializer; <S::Lnet/minecraft/world/item/crafting/RecipeSerializer<TT;>;T::Lnet/minecraft/world/item/crafting/Recipe;>(TS;)TS; -
 method public,static a (Lnet/minecraft/resources/ResourceLocation;Lcom/google/gson/JsonObject;)Lnet/minecraft/world/item/crafting/Recipe; - -
 method public,static a (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/world/item/crafting/Recipe; - -
 method public,static a (Lnet/minecraft/world/item/crafting/Recipe;Lnet/minecraft/network/FriendlyByteBuf;)V <T::Lnet/minecraft/world/item/crafting/Recipe;>(TT;Lnet/minecraft/network/FriendlyByteBuf;)V -
in 135
class avn 52 public,super java/lang/Object - -
 inner avn$a avn a public,static,final
 inner net/minecraft/world/item/crafting/ShapedRecipe$Serializer net/minecraft/world/item/crafting/ShapedRecipe Serializer public,static
 inner net/minecraft/world/item/crafting/ShapelessRecipe$Serializer net/minecraft/world/item/crafting/ShapelessRecipe Serializer public,static
 inner net/minecraft/world/item/crafting/SmeltingRecipe$a net/minecraft/world/item/crafting/SmeltingRecipe a public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final a Lnet/minecraft/world/item/crafting/RecipeSerializer; Lnet/minecraft/world/item/crafting/RecipeSerializer<Lnet/minecraft/world/item/crafting/ShapedRecipe;>;
 field public,static,final b Lnet/minecraft/world/item/crafting/RecipeSerializer; Lnet/minecraft/world/item/crafting/RecipeSerializer<Lnet/minecraft/world/item/crafting/ShapelessRecipe;>;
 field public,static,final c Lavn$a; Lavn$a<Lauz;>;
 field public,static,final d Lavn$a; Lavn$a<Lavc;>;
 field public,static,final e Lavn$a; Lavn$a<Lavi;>;
 field public,static,final f Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/MapExtendingRecipe;>;
 field public,static,final g Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/FireworkRocketRecipe;>;
 field public,static,final h Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/FireworkStarRecipe;>;
 field public,static,final i Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/FireworkStarFadeRecipe;>;
 field public,static,final j Lavn$a; Lavn$a<Lavo;>;
 field public,static,final k Lavn$a; Lavn$a<Lavu;>;
 field public,static,final l Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/BannerDuplicateRecipe;>;
 field public,static,final m Lavn$a; Lavn$a<Lava;>;
 field public,static,final n Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/ShieldDecorationRecipe;>;
 field public,static,final o Lavn$a; Lavn$a<Lnet/minecraft/world/item/crafting/ShulkerBoxColoring;>;
 field public,static,final p Lnet/minecraft/world/item/crafting/RecipeSerializer; Lnet/minecraft/world/item/crafting/RecipeSerializer<Lnet/minecraft/world/item/crafting/SmeltingRecipe;>;
 method public <init> ()V - -
 method public,static a (Lnet/minecraft/world/item/crafting/RecipeSerializer;)Lnet/minecraft/world/item/crafting/RecipeSerializer; <S::Lnet/minecraft/world/item/crafting/RecipeSerializer<TT;>;T::Lnet/minecraft/world/item/crafting/Recipe;>(TS;)TS; -
 method public,static a (Lnet/minecraft/resources/ResourceLocation;Lcom/google/gson/JsonObject;)Lnet/minecraft/world/item/crafting/Recipe; - -
 method public,static a (Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/world/item/crafting/Recipe; - -
 method public,static a (Lnet/minecraft/world/item/crafting/Recipe;Lnet/minecraft/network/FriendlyByteBuf;)V <T::Lnet/minecraft/world/item/crafting/Recipe;>(TT;Lnet/minecraft/network/FriendlyByteBuf;)V -
in 131
class avn$a 52 public,final,super java/lang/Object net/minecraft/world/item/crafting/RecipeSerializer <T::Lnet/minecraft/world/item/crafting/Recipe;>Ljava/lang/Object;Lnet/minecraft/world/item/crafting/RecipeSerializer<TT;>;
 inner avn$a avn a public,static,final
 method public <init> (Ljava/lang/String;Ljava/util/function/Function;)V (Ljava/lang/String;Ljava/util/function/Function<Lnet/minecraft/resources/ResourceLocation;TT;>;)V -
 method public fromJson (Lnet/minecraft/resources/ResourceLocation;Lcom/google/gson/JsonObject;)Lnet/minecraft/world/item/crafting/Recipe; (Lnet/minecraft/resources/ResourceLocation;Lcom/google/gson/JsonObject;)TT; -
 method public fromNetwork (Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/world/item/crafting/Recipe; (Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/network/FriendlyByteBuf;)TT; -
 method public toNetwork (Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/network/FriendlyByteBuf;TT;)V -
 method public a ()Ljava/lang/String; - -
in 135
class avn$a 52 public,final,super java/lang/Object net/minecraft/world/item/crafting/RecipeSerializer <T::Lnet/minecraft/world/item/crafting/Recipe;>Ljava/lang/Object;Lnet/minecraft/world/item/crafting/RecipeSerializer<TT;>;
 inner avn$a avn a public,static,final
 method public <init> (Ljava/lang/String;Ljava/util/function/Function;)V (Ljava/lang/String;Ljava/util/function/Function<Lnet/minecraft/resources/ResourceLocation;TT;>;)V -
 method public fromJson (Lnet/minecraft/resources/ResourceLocation;Lcom/google/gson/JsonObject;)Lnet/minecraft/world/item/crafting/Recipe; (Lnet/minecraft/resources/ResourceLocation;Lcom/google/gson/JsonObject;)TT; -
 method public fromNetwork (Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/world/item/crafting/Recipe; (Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/network/FriendlyByteBuf;)TT; -
 method public toNetwork (Lnet/minecraft/network/FriendlyByteBuf;Lnet/minecraft/world/item/crafting/Recipe;)V (Lnet/minecraft/network/FriendlyByteBuf;TT;)V -
 method public getName ()Lnet/minecraft/resources/ResourceLocation; - -
in 131
class avo 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public canCraftInDimensions (II)Z - -
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 135
class avo 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public canCraftInDimensions (II)Z - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 131
class avu 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public canCraftInDimensions (II)Z - -
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 135
class avu 52 public,super net/minecraft/world/item/crafting/CustomRecipe - -
 inner avn$a avn a public,static,final
 method public <init> (Lnet/minecraft/resources/ResourceLocation;)V - -
 method public matches (Lnet/minecraft/world/Container;Lnet/minecraft/world/level/Level;)Z - -
 method public assemble (Lnet/minecraft/world/Container;)Lnet/minecraft/world/item/ItemStack; - -
 method public canCraftInDimensions (II)Z - -
 method public getSerializer ()Lnet/minecraft/world/item/crafting/RecipeSerializer; ()Lnet/minecraft/world/item/crafting/RecipeSerializer<*>; -
in 59
class avw 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
in 59
class avx 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
in 59
class avy 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public checkCompatibility (Lnet/minecraft/world/item/enchantment/Enchantment;)Z - -
in 59
class avz 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
in 59
class awa 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public isTreasureOnly ()Z - -
 method public isCurse ()Z - -
in 59
class awd 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public canEnchant (Lnet/minecraft/world/item/ItemStack;)Z - -
in 59
class awj 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
in 59
class awk 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;Lnet/minecraft/world/item/enchantment/EnchantmentCategory;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
in 59
class awm 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
in 59
class awn 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;Lnet/minecraft/world/item/enchantment/EnchantmentCategory;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public checkCompatibility (Lnet/minecraft/world/item/enchantment/Enchantment;)Z - -
in 59
class awo 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public isTreasureOnly ()Z - -
 method public getMaxLevel ()I - -
in 59
class awp 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
in 59
class awt 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public checkCompatibility (Lnet/minecraft/world/item/enchantment/Enchantment;)Z - -
in 59
class awu 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public getDamageBonus (ILnet/minecraft/world/entity/MobType;)F - -
in 59
class awv 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public checkCompatibility (Lnet/minecraft/world/item/enchantment/Enchantment;)Z - -
in 59
class aww 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public checkCompatibility (Lnet/minecraft/world/item/enchantment/Enchantment;)Z - -
in 59
class awx 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public checkCompatibility (Lnet/minecraft/world/item/enchantment/Enchantment;)Z - -
in 59
class awy 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public isTreasureOnly ()Z - -
 method public isCurse ()Z - -
in 59
class awz 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
 method public checkCompatibility (Lnet/minecraft/world/item/enchantment/Enchantment;)Z - -
in 59
class axa 52 public,super net/minecraft/world/item/enchantment/Enchantment - -
 inner net/minecraft/world/item/enchantment/Enchantment$Rarity net/minecraft/world/item/enchantment/Enchantment Rarity public,static,final,enum
 method public,varargs <init> (Lnet/minecraft/world/item/enchantment/Enchantment$Rarity;[Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method public getMinCost (I)I - -
 method public b (I)I - -
 method public getMaxLevel ()I - -
in 131
class axd 52 public,interface,abstract java/lang/Object - -
 method public,abstract a (Laxf;)V - -
 method public,abstract setTradingPlayer (Lnet/minecraft/world/entity/player/Player;)V - -
 method public,abstract getTradingPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public,abstract b_ (Lnet/minecraft/world/entity/player/Player;)Laxf; - -
 method public,abstract a (Laxe;)V - -
 method public,abstract notifyTradeUpdated (Lnet/minecraft/world/item/ItemStack;)V - -
 method public,abstract getDisplayName ()Lnet/minecraft/network/chat/Component; - -
 method public,abstract getLevel ()Lnet/minecraft/world/level/Level; - -
 method public,abstract d ()Lnet/minecraft/core/BlockPos; - -
in 135
class axd 52 public,interface,abstract java/lang/Object - -
 method public,abstract setTradingPlayer (Lnet/minecraft/world/entity/player/Player;)V - -
 method public,abstract getTradingPlayer ()Lnet/minecraft/world/entity/player/Player; - -
 method public,abstract b_ (Lnet/minecraft/world/entity/player/Player;)Laxf; - -
 method public,abstract a (Laxf;)V - -
 method public,abstract a (Laxe;)V - -
 method public,abstract notifyTradeUpdated (Lnet/minecraft/world/item/ItemStack;)V - -
 method public,abstract getDisplayName ()Lnet/minecraft/network/chat/Component; - -
 method public,abstract getLevel ()Lnet/minecraft/world/level/Level; - -
 method public,abstract d ()Lnet/minecraft/core/BlockPos; - -
in 131
class axe 52 public,super java/lang/Object - -
 method public i ()V - -
 method public <init> (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public <init> (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;II)V - -
 method public <init> (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/Item;)V - -
 method public a ()Lnet/minecraft/world/item/ItemStack; - -
 method public b ()Lnet/minecraft/world/item/ItemStack; - -
 method public c ()Z - -
 method public d ()Lnet/minecraft/world/item/ItemStack; - -
 method public e ()I - -
 method public f ()I - -
 method public g ()V - -
 method public a (I)V - -
 method public h ()Z - -
 method public j ()Z - -
 method public a (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public k ()Lnet/minecraft/nbt/CompoundTag; - -
in 135
class axe 52 public,super java/lang/Object - -
 method public <init> (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public <init> (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;II)V - -
 method public <init> (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)V - -
 method public <init> (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/Item;)V - -
 method public a ()Lnet/minecraft/world/item/ItemStack; - -
 method public b ()Lnet/minecraft/world/item/ItemStack; - -
 method public c ()Z - -
 method public d ()Lnet/minecraft/world/item/ItemStack; - -
 method public e ()I - -
 method public f ()I - -
 method public g ()V - -
 method public a (I)V - -
 method public h ()Z - -
 method public i ()V - -
 method public j ()Z - -
 method public a (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public k ()Lnet/minecraft/nbt/CompoundTag; - -
in 131
class axf 52 public,super java/util/ArrayList - Ljava/util/ArrayList<Laxe;>;
 method public,static b (Lnet/minecraft/network/FriendlyByteBuf;)Laxf; - java/io/IOException
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public a (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;I)Laxe; - -
 method public a (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public a (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public a ()Lnet/minecraft/nbt/CompoundTag; - -
in 135
class axf 52 public,super java/util/ArrayList - Ljava/util/ArrayList<Laxe;>;
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public a (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;I)Laxe; - -
 method public a (Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public,static b (Lnet/minecraft/network/FriendlyByteBuf;)Laxf; - java/io/IOException
 method public a (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public a ()Lnet/minecraft/nbt/CompoundTag; - -
in 59
class axq 52 public,super it/unimi/dsi/fastutil/longs/Long2ObjectOpenHashMap - <T:Ljava/lang/Object;>Lit/unimi/dsi/fastutil/longs/Long2ObjectOpenHashMap<TT;>;
 inner it/unimi/dsi/fastutil/longs/Long2LongMap$Entry it/unimi/dsi/fastutil/longs/Long2LongMap Entry public,static,interface,abstract
 method public <init> (II)V - -
 method protected a (Ljava/lang/Object;)Z (TT;)Z -
 method public put (JLjava/lang/Object;)Ljava/lang/Object; (JTT;)TT; -
 method public put (Ljava/lang/Long;Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Long;TT;)TT; -
 method public get (J)Ljava/lang/Object; (J)TT; -
 method public putAll (Ljava/util/Map;)V (Ljava/util/Map<+Ljava/lang/Long;+TT;>;)V -
 method public remove (J)Ljava/lang/Object; (J)TT; -
 method public remove (Ljava/lang/Object;)Ljava/lang/Object; (Ljava/lang/Object;)TT; -
in 59
class ayb 52 public,interface,abstract java/lang/Object - -
 method public,abstract blockChanged (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;I)V - -
 method public,abstract a (Lnet/minecraft/core/BlockPos;)V - -
 method public,abstract setBlocksDirty (IIIIII)V - -
 method public,abstract a (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;DDDFF)V - -
 method public,abstract playStreamingMusic (Lnet/minecraft/sounds/SoundEvent;Lnet/minecraft/core/BlockPos;)V - -
 method public,abstract addParticle (Lnet/minecraft/core/particles/ParticleOptions;ZDDDDDD)V - -
 method public,abstract addParticle (Lnet/minecraft/core/particles/ParticleOptions;ZZDDDDDD)V - -
 method public,abstract a (Lnet/minecraft/world/entity/Entity;)V - -
 method public,abstract b (Lnet/minecraft/world/entity/Entity;)V - -
 method public,abstract globalLevelEvent (ILnet/minecraft/core/BlockPos;I)V - -
 method public,abstract levelEvent (Lnet/minecraft/world/entity/player/Player;ILnet/minecraft/core/BlockPos;I)V - -
 method public,abstract destroyBlockProgress (ILnet/minecraft/core/BlockPos;I)V - -
in 59
class ayc 52 public,interface,abstract java/lang/Object net/minecraft/world/level/BlockGetter -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/core/BlockPos$PooledMutableBlockPos net/minecraft/core/BlockPos PooledMutableBlockPos public,static,final
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract isEmptyBlock (Lnet/minecraft/core/BlockPos;)Z - -
 method public,abstract getBiome (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/biome/Biome; - -
 method public,abstract getBrightness (Lnet/minecraft/world/level/LightLayer;Lnet/minecraft/core/BlockPos;)I - -
 method public canSeeSkyFromBelowWater (Lnet/minecraft/core/BlockPos;)Z - -
 method public,abstract getRawBrightness (Lnet/minecraft/core/BlockPos;I)I - -
 method public,abstract a (IIZ)Z - -
 method public,abstract e (Lnet/minecraft/core/BlockPos;)Z - -
 method public getHeightmapPos (Lnet/minecraft/world/level/levelgen/Heightmap$Types;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public,abstract getHeight (Lnet/minecraft/world/level/levelgen/Heightmap$Types;II)I - -
 method public getBrightness (Lnet/minecraft/core/BlockPos;)F - -
 method public a (Lnet/minecraft/world/entity/Entity;D)Lnet/minecraft/world/entity/player/Player; - -
 method public b (Lnet/minecraft/world/entity/Entity;D)Lnet/minecraft/world/entity/player/Player; - -
 method public a (DDDDZ)Lnet/minecraft/world/entity/player/Player; - -
 method public,abstract getNearestPlayer (DDDDLjava/util/function/Predicate;)Lnet/minecraft/world/entity/player/Player; (DDDDLjava/util/function/Predicate<Lnet/minecraft/world/entity/Entity;>;)Lnet/minecraft/world/entity/player/Player; -
 method public,abstract getSkyDarken ()I - -
 method public,abstract getWorldBorder ()Lnet/minecraft/world/level/border/WorldBorder; - -
 method public,abstract isUnobstructed (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/shapes/VoxelShape;)Z - -
 method public,abstract getDirectSignal (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)I - -
 method public,abstract isClientSide ()Z - -
 method public,abstract getSeaLevel ()I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;)Z - -
 method public a_ (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Z - -
 method public a (Lnet/minecraft/world/phys/shapes/VoxelShape;Lnet/minecraft/world/phys/shapes/VoxelShape;Z)Ljava/util/stream/Stream; (Lnet/minecraft/world/phys/shapes/VoxelShape;Lnet/minecraft/world/phys/shapes/VoxelShape;Z)Ljava/util/stream/Stream<Lnet/minecraft/world/phys/shapes/VoxelShape;>; -
 method public a (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;DDD)Ljava/util/stream/Stream; (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;DDD)Ljava/util/stream/Stream<Lnet/minecraft/world/phys/shapes/VoxelShape;>; -
 method public a (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/util/Set;DDD)Ljava/util/stream/Stream; (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/util/Set<Lnet/minecraft/world/entity/Entity;>;DDD)Ljava/util/stream/Stream<Lnet/minecraft/world/phys/shapes/VoxelShape;>; -
 method public b (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Ljava/util/stream/Stream; (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Ljava/util/stream/Stream<Lnet/minecraft/world/phys/shapes/VoxelShape;>; -
 method public a (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/shapes/VoxelShape;Lnet/minecraft/world/phys/shapes/VoxelShape;Ljava/util/Set;)Ljava/util/stream/Stream; (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/shapes/VoxelShape;Lnet/minecraft/world/phys/shapes/VoxelShape;Ljava/util/Set<Lnet/minecraft/world/entity/Entity;>;)Ljava/util/stream/Stream<Lnet/minecraft/world/phys/shapes/VoxelShape;>; -
 method public i (Lnet/minecraft/world/entity/Entity;)Z - -
 method public noCollision (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/util/Set;)Z (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;Ljava/util/Set<Lnet/minecraft/world/entity/Entity;>;)Z -
 method public noCollision (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Z - -
 method public isWaterAt (Lnet/minecraft/core/BlockPos;)Z - -
 method public containsAnyLiquid (Lnet/minecraft/world/phys/AABB;)Z - -
 method public getMaxLocalRawBrightness (Lnet/minecraft/core/BlockPos;)I - -
 method public getMaxLocalRawBrightness (Lnet/minecraft/core/BlockPos;I)I - -
 method public hasChunkAt (Lnet/minecraft/core/BlockPos;)Z - -
 method public b (Lnet/minecraft/core/BlockPos;Z)Z - -
 method public e (Lnet/minecraft/core/BlockPos;I)Z - -
 method public a (Lnet/minecraft/core/BlockPos;IZ)Z - -
 method public hasChunksAt (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)Z - -
 method public a (Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;Z)Z - -
 method public a (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;)Z - -
 method public a (Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Z)Z - -
 method public a (IIIIIIZ)Z - -
 method public,abstract getDimension ()Lnet/minecraft/world/level/dimension/Dimension; - -
in 59
class ayf 52 public,interface,abstract java/lang/Object - -
 method public,abstract h ()Lcck; - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/util/function/Function;Ljava/lang/String;)Lnet/minecraft/world/level/saveddata/SavedData; <T:Lnet/minecraft/world/level/saveddata/SavedData;>(Lnet/minecraft/world/level/dimension/DimensionType;Ljava/util/function/Function<Ljava/lang/String;TT;>;Ljava/lang/String;)TT; -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/lang/String;Lnet/minecraft/world/level/saveddata/SavedData;)V - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/lang/String;)I - -
in 59
class ayv 52 public,super java/lang/Object - -
 inner ayv$a ayv a public
 method public <init> (Lnet/minecraft/world/level/biome/BiomeSource;)V - -
 method public a (II)Layv$a; - -
 method public a (IILnet/minecraft/world/level/biome/Biome;)Lnet/minecraft/world/level/biome/Biome; - -
 method public a ()V - -
 method public b (II)[Lnet/minecraft/world/level/biome/Biome; - -
in 59
class ayv$a 52 public,super java/lang/Object - -
 inner ayv$a ayv a public
 method public <init> (Layv;II)V - -
 method public a (II)Lnet/minecraft/world/level/biome/Biome; - -
in 59
class bcd 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/phys/shapes/VoxelShape; - -
 method public d (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;FI)V - -
 method public isAir (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
in 131
class bch 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public g (Lnet/minecraft/world/level/block/state/BlockState;)F - -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public propagatesSkylightDown (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public canOcclude (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;FI)V - -
in 135
class bch 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public propagatesSkylightDown (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public canOcclude (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public g (Lnet/minecraft/world/level/block/state/BlockState;)F - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;FI)V - -
in 59
class bcm 52 public,super,abstract net/minecraft/world/level/block/Block net/minecraft/world/level/block/EntityBlock -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method protected <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public onRemove (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)V - -
 method public playerDestroy (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/item/ItemStack;)V - -
 method public triggerEvent (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;II)Z - -
in 59
class bcp 52 public,super bcm - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public newBlockEntity (Lnet/minecraft/world/level/BlockGetter;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/core/Direction;FFF)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public setPlacedBy (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;)V - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public,static a (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)V - -
in 59
class bcu 52 public,super bff - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
in 59
class bcw 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
in 131
class bda 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method protected <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method protected mayPlaceOn (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public updateShape (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public canSurvive (Lnet/minecraft/world/level/block/state/BlockState;Layc;Lnet/minecraft/core/BlockPos;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
 method public getLightBlock (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)I - -
in 135
class bda 52 public,super net/minecraft/world/level/block/Block net/minecraftforge/common/IPlantable -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method protected <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public mayPlaceOn (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public updateShape (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public canSurvive (Lnet/minecraft/world/level/block/state/BlockState;Layc;Lnet/minecraft/core/BlockPos;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
 method public getLightBlock (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)I - -
 method public getPlant (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
in 59
class bdk 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
in 59
class bdu 52 public,super net/minecraft/world/level/block/Block - -
 inner bdu$a bdu a public,static
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/core/Direction;FFF)Z - -
in 59
class bdu$a 52 public,super java/lang/Object adl -
 inner bdu$a bdu a public,static
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)V - -
 method public getName ()Lnet/minecraft/network/chat/Component; - -
 method public hasCustomName ()Z - -
 method public getCustomName ()Lnet/minecraft/network/chat/Component; - -
 method public a (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/inventory/AbstractContainerMenu; - -
 method public l ()Ljava/lang/String; - -
in 131
class bei 52 public,super bcm - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public animateTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public newBlockEntity (Lnet/minecraft/world/level/BlockGetter;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public getCloneItemStack (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/item/ItemStack; - -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
in 135
class bei 52 public,super bcm - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public newBlockEntity (Lnet/minecraft/world/level/BlockGetter;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public animateTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public getCloneItemStack (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/item/ItemStack; - -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
in 131
class bex 52 public,super bcm - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 inner net/minecraft/world/level/block/state/StateDefinition$Builder net/minecraft/world/level/block/state/StateDefinition Builder public,static
 field public,static,final a Lnet/minecraft/world/level/block/state/properties/DirectionProperty; -
 field public,static,final b Lnet/minecraft/world/level/block/state/properties/BooleanProperty; -
 method public animateTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public getLightEmission (Lnet/minecraft/world/level/block/state/BlockState;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/core/Direction;FFF)Z - -
 method public newBlockEntity (Lnet/minecraft/world/level/BlockGetter;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public getStateForPlacement (Lnet/minecraft/world/item/BlockPlaceContext;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public setPlacedBy (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;)V - -
 method public onRemove (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)V - -
 method public hasAnalogOutputSignal (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getAnalogOutputSignal (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)I - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public rotate (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public mirror (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/Mirror;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method protected createBlockStateDefinition (Lnet/minecraft/world/level/block/state/StateDefinition$Builder;)V (Lnet/minecraft/world/level/block/state/StateDefinition$Builder<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/block/state/BlockState;>;)V -
in 135
class bex 52 public,super bcm - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 inner net/minecraft/world/level/block/state/StateDefinition$Builder net/minecraft/world/level/block/state/StateDefinition Builder public,static
 field public,static,final a Lnet/minecraft/world/level/block/state/properties/DirectionProperty; -
 field public,static,final b Lnet/minecraft/world/level/block/state/properties/BooleanProperty; -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public getLightEmission (Lnet/minecraft/world/level/block/state/BlockState;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/core/Direction;FFF)Z - -
 method public newBlockEntity (Lnet/minecraft/world/level/BlockGetter;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public getStateForPlacement (Lnet/minecraft/world/item/BlockPlaceContext;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public setPlacedBy (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;)V - -
 method public onRemove (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)V - -
 method public hasAnalogOutputSignal (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getAnalogOutputSignal (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;)I - -
 method public animateTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public rotate (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/Rotation;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public mirror (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/Mirror;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method protected createBlockStateDefinition (Lnet/minecraft/world/level/block/state/StateDefinition$Builder;)V (Lnet/minecraft/world/level/block/state/StateDefinition$Builder<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/block/state/BlockState;>;)V -
in 59
class bey 52 public,super bff - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public propagatesSkylightDown (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method protected X_ ()Z - -
in 59
class bez 52 public,super bfm - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
in 59
class bfa 52 public,super net/minecraft/world/level/block/HorizontalDirectionalBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/world/level/block/state/StateDefinition$Builder net/minecraft/world/level/block/state/StateDefinition Builder public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method protected createBlockStateDefinition (Lnet/minecraft/world/level/block/state/StateDefinition$Builder;)V (Lnet/minecraft/world/level/block/state/StateDefinition$Builder<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/block/state/BlockState;>;)V -
 method public getStateForPlacement (Lnet/minecraft/world/item/BlockPlaceContext;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public getPistonPushReaction (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/material/PushReaction; - -
in 59
class bfb 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;ILnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
in 59
class bfc 52 public,super bhu net/minecraft/world/level/block/BonemealableBlock -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public isValidBonemealTarget (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)Z - -
 method public isBonemealSuccess (Lnet/minecraft/world/level/Level;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public performBonemeal (Lnet/minecraft/world/level/Level;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public canOcclude (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
in 131
class bfe 52 public,super net/minecraft/world/level/block/FallingBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public getDustColor (Lnet/minecraft/world/level/block/state/BlockState;)I - -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
in 135
class bfe 52 public,super net/minecraft/world/level/block/FallingBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public getDustColor (Lnet/minecraft/world/level/block/state/BlockState;)I - -
in 131
class bff 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public skipRendering (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z - -
 method protected <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
in 135
class bff 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method protected <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public skipRendering (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z - -
in 59
class bfg 52 public,super net/minecraft/world/level/block/RotatedPillarBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public fallOn (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;F)V - -
in 131
class bfm 52 public,super net/minecraft/world/level/block/CrossCollisionBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/world/level/block/state/StateDefinition$Builder net/minecraft/world/level/block/state/StateDefinition Builder public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method public skipRendering (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z - -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public getStateForPlacement (Lnet/minecraft/world/item/BlockPlaceContext;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public updateShape (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public,final a (Lnet/minecraft/world/level/block/state/BlockState;Lblb;)Z - -
 method public,static f (Lnet/minecraft/world/level/block/Block;)Z - -
 method protected X_ ()Z - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method protected createBlockStateDefinition (Lnet/minecraft/world/level/block/state/StateDefinition$Builder;)V (Lnet/minecraft/world/level/block/state/StateDefinition$Builder<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/block/state/BlockState;>;)V -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
in 135
class bfm 52 public,super net/minecraft/world/level/block/CrossCollisionBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/world/level/block/state/StateDefinition$Builder net/minecraft/world/level/block/state/StateDefinition Builder public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public getStateForPlacement (Lnet/minecraft/world/item/BlockPlaceContext;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public updateShape (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public skipRendering (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z - -
 method public,final a (Lnet/minecraft/world/level/block/state/BlockState;Lblb;)Z - -
 method public,static f (Lnet/minecraft/world/level/block/Block;)Z - -
 method protected X_ ()Z - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method protected createBlockStateDefinition (Lnet/minecraft/world/level/block/state/StateDefinition$Builder;)V (Lnet/minecraft/world/level/block/state/StateDefinition$Builder<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/block/state/BlockState;>;)V -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
 method public canBeConnectedTo (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Z - -
in 131
class bfx 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelReader;Lnet/minecraft/core/BlockPos;)I - -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public stepOn (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;)V - -
 method public tick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public updateShape (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public randomTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public getTickDelay (Layc;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/Entity;)Z - -
 method public hasPostProcess (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
in 135
class bfx 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public stepOn (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelReader;Lnet/minecraft/core/BlockPos;)I - -
 method public tick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public updateShape (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
 method public randomTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public getTickDelay (Layc;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/Entity;)Z - -
 method public hasPostProcess (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
in 59
class bfy 52 public,super bia - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;ILnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)I - -
 method public getStem ()Lnet/minecraft/world/level/block/StemBlock; - -
 method public getAttachedStem ()Lnet/minecraft/world/level/block/AttachedStemBlock; - -
in 131
class bgb 52 public,super bhu - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public animateTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
in 135
class bgb 52 public,super bhu - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public animateTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
in 59
class bge 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
in 131
class bgh 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;ILnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;FI)V - -
 method public getCloneItemStack (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/item/ItemStack; - -
in 135
class bgh 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;ILnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;FI)V - -
 method public getExpDrop (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelReader;Lnet/minecraft/core/BlockPos;I)I - -
 method public getCloneItemStack (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/item/ItemStack; - -
in 59
class bgi 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
in 59
class bgk 52 public,super net/minecraft/world/level/block/SkullBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/world/level/block/SkullBlock$Types net/minecraft/world/level/block/SkullBlock Types public,static,final,enum
 inner net/minecraft/world/level/block/SkullBlock$a net/minecraft/world/level/block/SkullBlock a public,static,interface,abstract
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public setPlacedBy (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;)V - -
in 59
class bgl 52 public,super net/minecraft/world/level/block/WallSkullBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/world/level/block/SkullBlock$Types net/minecraft/world/level/block/SkullBlock Types public,static,final,enum
 inner net/minecraft/world/level/block/SkullBlock$a net/minecraft/world/level/block/SkullBlock a public,static,interface,abstract
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public setPlacedBy (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;)V - -
in 59
class bgn 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public isSignalSource (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getSignal (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)I - -
in 59
class bgq 52 public,super bia - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/InteractionHand;Lnet/minecraft/core/Direction;FFF)Z - -
 method public getStem ()Lnet/minecraft/world/level/block/StemBlock; - -
 method public getAttachedStem ()Lnet/minecraft/world/level/block/AttachedStemBlock; - -
in 59
class bhe 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;ILnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)I - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method protected X_ ()Z - -
in 59
class bhm 52 public,super bff - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public fallOn (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;F)V - -
 method public updateEntityAfterFallOn (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/entity/Entity;)V - -
 method public stepOn (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;)V - -
 method public getLightBlock (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)I - -
in 59
class bhn 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)I - -
 method public tick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
in 131
class bhs 52 public,super bcm - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public newBlockEntity (Lnet/minecraft/world/level/BlockGetter;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;FI)V - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public getCloneItemStack (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/item/ItemStack; - -
in 135
class bhs 52 public,super bcm - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public newBlockEntity (Lnet/minecraft/world/level/BlockGetter;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;FI)V - -
 method public getExpDrop (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/LevelReader;Lnet/minecraft/core/BlockPos;I)I - -
 method public getRenderShape (Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/level/block/RenderShape; - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public getCloneItemStack (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Lnet/minecraft/world/item/ItemStack; - -
in 59
class bhu 52 public,super,abstract net/minecraft/world/level/block/SnowyDirtBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method protected <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public tick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
in 59
class bia 52 public,super,abstract net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public,abstract getStem ()Lnet/minecraft/world/level/block/StemBlock; - -
 method public,abstract getAttachedStem ()Lnet/minecraft/world/level/block/AttachedStemBlock; - -
in 59
class bib 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
in 59
class bic 52 public,super net/minecraft/world/level/block/ButtonBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method protected getSound (Z)Lnet/minecraft/sounds/SoundEvent; - -
in 59
class big 52 public,super net/minecraft/world/level/block/DoublePlantBlock net/minecraft/world/level/block/BonemealableBlock -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public canBeReplaced (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/item/BlockPlaceContext;)Z - -
 method public isValidBonemealTarget (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)Z - -
 method public isBonemealSuccess (Lnet/minecraft/world/level/Level;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public performBonemeal (Lnet/minecraft/world/level/Level;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 59
class bim 52 public,super net/minecraft/world/level/block/ChestBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public newBlockEntity (Lnet/minecraft/world/level/BlockGetter;)Lnet/minecraft/world/level/block/entity/BlockEntity; - -
 method protected getOpenChestStat ()Lnet/minecraft/stats/Stat; ()Lnet/minecraft/stats/Stat<Lnet/minecraft/resources/ResourceLocation;>; -
 method public isSignalSource (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public getSignal (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)I - -
 method public getDirectSignal (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)I - -
in 131
class bix 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public entityInside (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method protected X_ ()Z - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public playerDestroy (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/item/ItemStack;)V - -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
in 135
class bix 52 public,super net/minecraft/world/level/block/Block net/minecraftforge/common/IShearable -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public entityInside (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/entity/Entity;)V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;)Z - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/ItemLike; - -
 method protected X_ ()Z - -
 method public getRenderLayer ()Lnet/minecraft/world/level/BlockLayer; - -
 method public playerDestroy (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/entity/BlockEntity;Lnet/minecraft/world/item/ItemStack;)V - -
 method public a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/BlockPos;Lnet/minecraft/core/Direction;)Lblb; - -
 method public onSheared (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;I)Ljava/util/List; (Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;I)Ljava/util/List<Lnet/minecraft/world/item/ItemStack;>; -
in 131
class biz 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method public animateTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
in 135
class biz 52 public,super net/minecraft/world/level/block/Block - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public animateTick (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Ljava/util/Random;)V - -
in 59
class bjb 52 public,super net/minecraft/world/level/block/WallSkullBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 inner net/minecraft/world/level/block/SkullBlock$Types net/minecraft/world/level/block/SkullBlock Types public,static,final,enum
 inner net/minecraft/world/level/block/SkullBlock$a net/minecraft/world/level/block/SkullBlock a public,static,interface,abstract
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method public setPlacedBy (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;)V - -
in 59
class bjc 52 public,super net/minecraft/world/level/block/ButtonBlock - -
 inner net/minecraft/world/level/block/Block$Properties net/minecraft/world/level/block/Block Properties public,static
 method public <init> (Lnet/minecraft/world/level/block/Block$Properties;)V - -
 method protected getSound (Z)Lnet/minecraft/sounds/SoundEvent; - -
in 59
class bjp 52 public,super net/minecraft/world/level/block/entity/BlockEntity pt -
 method public <init> ()V - -
 method public tick ()V - -
in 59
class bjr 52 public,super net/minecraft/world/level/block/entity/DispenserBlockEntity - -
 method public <init> ()V - -
 method public getName ()Lnet/minecraft/network/chat/Component; - -
 method public l ()Ljava/lang/String; - -
in 131
class bju 52 public,super net/minecraft/world/level/block/entity/BaseContainerBlockEntity net/minecraft/world/WorldlyContainer,net/minecraft/world/inventory/RecipeHolder,net/minecraft/world/inventory/StackedContentsCompatible,pt -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/network/chat/Component$Serializer net/minecraft/network/chat/Component Serializer public,static
 method public,static a (Lnet/minecraft/world/Container;)Z - -
 method public,static p ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/world/item/Item;Ljava/lang/Integer;>; -
 method public <init> ()V - -
 method public getContainerSize ()I - -
 method public isEmpty ()Z - -
 method public getItem (I)Lnet/minecraft/world/item/ItemStack; - -
 method public removeItem (II)Lnet/minecraft/world/item/ItemStack; - -
 method public removeItemNoUpdate (I)Lnet/minecraft/world/item/ItemStack; - -
 method public setItem (ILnet/minecraft/world/item/ItemStack;)V - -
 method public getName ()Lnet/minecraft/network/chat/Component; - -
 method public hasCustomName ()Z - -
 method public getCustomName ()Lnet/minecraft/network/chat/Component; - -
 method public a (Lnet/minecraft/network/chat/Component;)V - -
 method public load (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public save (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getMaxStackSize ()I - -
 method public tick ()V - -
 method public,static a (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public stillValid (Lnet/minecraft/world/entity/player/Player;)Z - -
 method public startOpen (Lnet/minecraft/world/entity/player/Player;)V - -
 method public stopOpen (Lnet/minecraft/world/entity/player/Player;)V - -
 method public canPlaceItem (ILnet/minecraft/world/item/ItemStack;)Z - -
 method public getSlotsForFace (Lnet/minecraft/core/Direction;)[I - -
 method public canPlaceItemThroughFace (ILnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/Direction;)Z - -
 method public canTakeItemThroughFace (ILnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/Direction;)Z - -
 method public l ()Ljava/lang/String; - -
 method public a (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/inventory/AbstractContainerMenu; - -
 method public c (I)I - -
 method public b (II)V - -
 method public h ()I - -
 method public clearContent ()V - -
 method public fillStackedContents (Lnet/minecraft/world/entity/player/StackedContents;)V - -
 method public setRecipeUsed (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method public getRecipeUsed ()Lnet/minecraft/world/item/crafting/Recipe; - -
 method public q ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/lang/Integer;>; -
 method public setRecipeUsed (Lnet/minecraft/world/level/Level;Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public awardAndReset (Lnet/minecraft/world/entity/player/Player;)V - -
in 135
class bju 52 public,super net/minecraft/world/level/block/entity/BaseContainerBlockEntity net/minecraft/world/WorldlyContainer,net/minecraft/world/inventory/RecipeHolder,net/minecraft/world/inventory/StackedContentsCompatible,pt -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/network/chat/Component$Serializer net/minecraft/network/chat/Component Serializer public,static
 method public,static p ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/world/item/Item;Ljava/lang/Integer;>; -
 method public <init> ()V - -
 method public getContainerSize ()I - -
 method public isEmpty ()Z - -
 method public getItem (I)Lnet/minecraft/world/item/ItemStack; - -
 method public removeItem (II)Lnet/minecraft/world/item/ItemStack; - -
 method public removeItemNoUpdate (I)Lnet/minecraft/world/item/ItemStack; - -
 method public setItem (ILnet/minecraft/world/item/ItemStack;)V - -
 method public getName ()Lnet/minecraft/network/chat/Component; - -
 method public hasCustomName ()Z - -
 method public getCustomName ()Lnet/minecraft/network/chat/Component; - -
 method public a (Lnet/minecraft/network/chat/Component;)V - -
 method public load (Lnet/minecraft/nbt/CompoundTag;)V - -
 method public save (Lnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/nbt/CompoundTag; - -
 method public getMaxStackSize ()I - -
 method public,static a (Lnet/minecraft/world/Container;)Z - -
 method public tick ()V - -
 method public,static a (Lnet/minecraft/world/item/ItemStack;)Z - -
 method public stillValid (Lnet/minecraft/world/entity/player/Player;)Z - -
 method public startOpen (Lnet/minecraft/world/entity/player/Player;)V - -
 method public stopOpen (Lnet/minecraft/world/entity/player/Player;)V - -
 method public canPlaceItem (ILnet/minecraft/world/item/ItemStack;)Z - -
 method public getSlotsForFace (Lnet/minecraft/core/Direction;)[I - -
 method public canPlaceItemThroughFace (ILnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/Direction;)Z - -
 method public canTakeItemThroughFace (ILnet/minecraft/world/item/ItemStack;Lnet/minecraft/core/Direction;)Z - -
 method public l ()Ljava/lang/String; - -
 method public a (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/inventory/AbstractContainerMenu; - -
 method public c (I)I - -
 method public b (II)V - -
 method public h ()I - -
 method public clearContent ()V - -
 method public fillStackedContents (Lnet/minecraft/world/entity/player/StackedContents;)V - -
 method public setRecipeUsed (Lnet/minecraft/world/item/crafting/Recipe;)V - -
 method public getRecipeUsed ()Lnet/minecraft/world/item/crafting/Recipe; - -
 method public q ()Ljava/util/Map; ()Ljava/util/Map<Lnet/minecraft/resources/ResourceLocation;Ljava/lang/Integer;>; -
 method public setRecipeUsed (Lnet/minecraft/world/level/Level;Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/item/crafting/Recipe;)Z - -
 method public awardAndReset (Lnet/minecraft/world/entity/player/Player;)V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/core/Direction;)Lnet/minecraftforge/common/util/LazyOptional; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/core/Direction;)Lnet/minecraftforge/common/util/LazyOptional<TT;>; -
 method public setRemoved ()V - -
in 131
class bkh 52 public,super net/minecraft/world/level/block/entity/BlockEntity - -
 method public shouldRenderFace (Lnet/minecraft/core/Direction;)Z - -
 method public <init> (Lnet/minecraft/world/level/block/entity/BlockEntityType;)V (Lnet/minecraft/world/level/block/entity/BlockEntityType<*>;)V -
 method public <init> ()V - -
in 135
class bkh 52 public,super net/minecraft/world/level/block/entity/BlockEntity - -
 method public <init> (Lnet/minecraft/world/level/block/entity/BlockEntityType;)V (Lnet/minecraft/world/level/block/entity/BlockEntityType<*>;)V -
 method public <init> ()V - -
 method public shouldRenderFace (Lnet/minecraft/core/Direction;)Z - -
in 59
class bki 52 public,super net/minecraft/world/level/block/entity/ChestBlockEntity - -
 method public <init> ()V - -
 method protected signalOpenCount ()V - -
in 59
class bkl 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method protected,abstract getFeature (Ljava/util/Random;)Lnet/minecraft/world/level/levelgen/feature/AbstractTreeFeature; (Ljava/util/Random;)Lnet/minecraft/world/level/levelgen/feature/AbstractTreeFeature<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;>; -
 method public growTree (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Ljava/util/Random;)Z - -
in 59
class blb 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lblb;>;
 field public,static,final,enum SOLID Lblb; -
 field public,static,final,enum b Lblb; -
 field public,static,final,enum c Lblb; -
 field public,static,final,enum d Lblb; -
 field public,static,final,enum e Lblb; -
 field public,static,final,enum f Lblb; -
 field public,static,final,enum g Lblb; -
 field public,static,final,enum h Lblb; -
 field public,static,final,enum i Lblb; -
 method public,static values ()[Lblb; - -
 method public,static valueOf (Ljava/lang/String;)Lblb; - -
in 59
class bld 52 public,super net/minecraft/world/level/block/state/AbstractStateHolder net/minecraft/world/level/block/state/BlockState Lnet/minecraft/world/level/block/state/AbstractStateHolder<Lnet/minecraft/world/level/block/Block;Lnet/minecraft/world/level/block/state/BlockState;>;Lnet/minecraft/world/level/block/state/BlockState;
 method public <init> (Lnet/minecraft/world/level/block/Block;Lcom/google/common/collect/ImmutableMap;)V (Lnet/minecraft/world/level/block/Block;Lcom/google/common/collect/ImmutableMap<Lnet/minecraft/world/level/block/state/properties/Property<*>;Ljava/lang/Comparable<*>;>;)V -
 method public getBlock ()Lnet/minecraft/world/level/block/Block; - -
in 59
class bll 52 public,super java/lang/Object blm Ljava/lang/Object;Lblm<Lnet/minecraft/world/level/block/state/BlockState;>;
 method public <init> (Lnet/minecraft/world/level/block/Block;)V - -
 method public,static a (Lnet/minecraft/world/level/block/Block;)Lbll; - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
in 59
class blm 52 public,interface,abstract java/lang/Object - <T:Ljava/lang/Object;>Ljava/lang/Object;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,abstract test (Ljava/lang/Object;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z (TT;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z -
in 59
class blq 52 public,final,super java/lang/Object - -
 inner blq$c blq c static
 inner blq$b blq b static
 method public,static a (Lblm;)Lblm; <T:Ljava/lang/Object;>(Lblm<TT;>;)Lblm<TT;>; -
 method public,static,varargs b ([Lblm;)Lblm; <T:Ljava/lang/Object;>([Lblm<-TT;>;)Lblm<TT;>; -
in 59
class blq$b 52 super java/lang/Object blm <T:Ljava/lang/Object;>Ljava/lang/Object;Lblm<TT;>;
 inner blq$b blq b static
 method public test (Ljava/lang/Object;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z (TT;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z -
in 59
class blq$c 52 super java/lang/Object blm <T:Ljava/lang/Object;>Ljava/lang/Object;Lblm<TT;>;
 inner blq$c blq c static
 method public test (Ljava/lang/Object;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z (TT;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z -
in 59
class blr 52 public,super java/lang/Object blm Ljava/lang/Object;Lblm<Lnet/minecraft/world/level/block/state/BlockState;>;
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public,static a ()Lblr; - -
in 59
class bls 52 public,super java/lang/Object blm Ljava/lang/Object;Lblm<Lnet/minecraft/world/level/block/state/BlockState;>;
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public,static a ()Lbls; - -
in 59
class blt 52 public,super java/lang/Object blm Ljava/lang/Object;Lblm<Lnet/minecraft/world/level/block/state/BlockState;>;
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public,static a ()Lblt; - -
in 59
class blu 52 public,super java/lang/Object blm Ljava/lang/Object;Lblm<Lnet/minecraft/world/level/block/state/BlockState;>;
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
 method public,static a ()Lblu; - -
in 59
class blv 52 public,super java/lang/Object blm Ljava/lang/Object;Lblm<Lnet/minecraft/world/level/block/state/BlockState;>;
 method public <init> (Lnet/minecraft/tags/Tag;)V (Lnet/minecraft/tags/Tag<Lnet/minecraft/world/level/block/Block;>;)V -
 method public,static a (Lnet/minecraft/tags/Tag;)Lblv; (Lnet/minecraft/tags/Tag<Lnet/minecraft/world/level/block/Block;>;)Lblv; -
 method public a (Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z - -
in 59
class bmz 52 public,super,abstract java/lang/Object net/minecraft/world/level/chunk/ChunkGenerator <C::Lbom;>Ljava/lang/Object;Lnet/minecraft/world/level/chunk/ChunkGenerator<TC;>;
 inner net/minecraft/world/level/levelgen/GenerationStep$Carving net/minecraft/world/level/levelgen/GenerationStep Carving public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/world/level/levelgen/GenerationStep$Decoration net/minecraft/world/level/levelgen/GenerationStep Decoration public,static,final,enum
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final a Lnet/minecraft/world/level/LevelAccessor; -
 field protected,final b J -
 field protected,final c Lnet/minecraft/world/level/biome/BiomeSource; -
 field protected,final d Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/world/level/levelgen/feature/StructureFeature<+Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>;Lit/unimi/dsi/fastutil/longs/Long2ObjectMap<Lnet/minecraft/world/level/levelgen/structure/StructureStart;>;>;
 field protected,final e Ljava/util/Map; Ljava/util/Map<Lnet/minecraft/world/level/levelgen/feature/StructureFeature<+Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>;Lit/unimi/dsi/fastutil/longs/Long2ObjectMap<Lit/unimi/dsi/fastutil/longs/LongSet;>;>;
 method public <init> (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/biome/BiomeSource;)V - -
 method public a (Lnet/minecraft/server/level/WorldGenRegion;Lnet/minecraft/world/level/levelgen/GenerationStep$Carving;)V - -
 method public findNearestMapFeature (Lnet/minecraft/world/level/Level;Ljava/lang/String;Lnet/minecraft/core/BlockPos;IZ)Lnet/minecraft/core/BlockPos; - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkAccess;Ljava/util/Random;)V - -
 method public applyBiomeDecoration (Lnet/minecraft/server/level/WorldGenRegion;)V - -
 method public a (Lnet/minecraft/world/level/chunk/ChunkAccess;[Lnet/minecraft/world/level/biome/Biome;Lnet/minecraft/world/level/levelgen/WorldgenRandom;I)V - -
 method public,abstract getSettings ()Lbom; ()TC; -
 method public,abstract a (II)[D - -
 method public isBiomeValidStartForStructure (Lnet/minecraft/world/level/biome/Biome;Lnet/minecraft/world/level/levelgen/feature/StructureFeature;)Z (Lnet/minecraft/world/level/biome/Biome;Lnet/minecraft/world/level/levelgen/feature/StructureFeature<+Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>;)Z -
 method public getStructureConfiguration (Lnet/minecraft/world/level/biome/Biome;Lnet/minecraft/world/level/levelgen/feature/StructureFeature;)Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration; (Lnet/minecraft/world/level/biome/Biome;Lnet/minecraft/world/level/levelgen/feature/StructureFeature<+Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>;)Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration; -
 method public getBiomeSource ()Lnet/minecraft/world/level/biome/BiomeSource; - -
 method public getSeed ()J - -
 method public a (Lnet/minecraft/world/level/levelgen/feature/StructureFeature;)Lit/unimi/dsi/fastutil/longs/Long2ObjectMap; (Lnet/minecraft/world/level/levelgen/feature/StructureFeature<+Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>;)Lit/unimi/dsi/fastutil/longs/Long2ObjectMap<Lnet/minecraft/world/level/levelgen/structure/StructureStart;>; -
 method public b (Lnet/minecraft/world/level/levelgen/feature/StructureFeature;)Lit/unimi/dsi/fastutil/longs/Long2ObjectMap; (Lnet/minecraft/world/level/levelgen/feature/StructureFeature<+Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>;)Lit/unimi/dsi/fastutil/longs/Long2ObjectMap<Lit/unimi/dsi/fastutil/longs/LongSet;>; -
 method public getGenDepth ()I - -
in 59
class bnc 52 public,interface,abstract java/lang/Object java/lang/AutoCloseable -
 method public,abstract a (IIZZ)Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method public a (IIZ)Lnet/minecraft/world/level/chunk/ChunkAccess; - -
 method public,abstract a (Ljava/util/function/BooleanSupplier;)Z - -
 method public,abstract gatherStats ()Ljava/lang/String; - -
 method public,abstract getGenerator ()Lnet/minecraft/world/level/chunk/ChunkGenerator; ()Lnet/minecraft/world/level/chunk/ChunkGenerator<*>; -
 method public close ()V - -
in 131
class bnv 52 public,super java/lang/Object bnw,cdx -
 inner net/minecraft/world/level/chunk/ChunkStatus$ChunkType net/minecraft/world/level/chunk/ChunkStatus ChunkType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/level/levelgen/GenerationStep$Carving net/minecraft/world/level/levelgen/GenerationStep Carving public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/Heightmap$Usage net/minecraft/world/level/levelgen/Heightmap Usage public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/io/File;Lcom/mojang/datafixers/DataFixer;)V - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Lcck;)V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer;)Lnet/minecraft/world/level/chunk/LevelChunk; (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer<Lnet/minecraft/world/level/chunk/LevelChunk;>;)Lnet/minecraft/world/level/chunk/LevelChunk; java/io/IOException
 method public b (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer;)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer<Lnet/minecraft/world/level/chunk/ChunkAccess;>;)Lnet/minecraft/world/level/chunk/ProtoChunk; java/io/IOException
 method protected a (Lnet/minecraft/world/level/LevelAccessor;IILnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method protected b (Lnet/minecraft/world/level/LevelAccessor;IILnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/chunk/ProtoChunk; - -
 method public a (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkAccess;)V - java/io/IOException,net/minecraft/world/level/LevelConflictException
 method protected a (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/nbt/CompoundTag;)V - -
 method public a ()Z - -
 method public b ()V - -
 method public,static a ([Lit/unimi/dsi/fastutil/shorts/ShortList;)Lnet/minecraft/nbt/ListTag; - -
 method public,static a (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/LevelChunk;)Lnet/minecraft/world/entity/Entity; - -
 method public,static a (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/level/Level;DDDZ)Lnet/minecraft/world/entity/Entity; - -
 method public,static a (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/level/Level;Z)Lnet/minecraft/world/entity/Entity; - -
 method protected,static a (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/level/Level;)Lnet/minecraft/world/entity/Entity; - -
 method public,static a (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/level/LevelAccessor;)V - -
 method public a (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/dimension/DimensionType;Lcck;)Z - -
in 135
class bnv 52 public,super java/lang/Object bnw,cdx -
 inner net/minecraft/world/level/chunk/ChunkStatus$ChunkType net/minecraft/world/level/chunk/ChunkStatus ChunkType public,static,final,enum
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/level/levelgen/GenerationStep$Carving net/minecraft/world/level/levelgen/GenerationStep Carving public,static,final,enum
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraftforge/event/world/ChunkDataEvent$Save net/minecraftforge/event/world/ChunkDataEvent Save public,static
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 inner net/minecraft/world/level/levelgen/Heightmap$Usage net/minecraft/world/level/levelgen/Heightmap Usage public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,final c Ljava/io/File; -
 method public <init> (Ljava/io/File;Lcom/mojang/datafixers/DataFixer;)V - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Lcck;)V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer;)Lnet/minecraft/world/level/chunk/LevelChunk; (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer<Lnet/minecraft/world/level/chunk/LevelChunk;>;)Lnet/minecraft/world/level/chunk/LevelChunk; java/io/IOException
 method public b (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer;)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer<Lnet/minecraft/world/level/chunk/ChunkAccess;>;)Lnet/minecraft/world/level/chunk/ProtoChunk; java/io/IOException
 method protected a (Lnet/minecraft/world/level/LevelAccessor;IILnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method protected b (Lnet/minecraft/world/level/LevelAccessor;IILnet/minecraft/nbt/CompoundTag;)Lnet/minecraft/world/level/chunk/ProtoChunk; - -
 method public a (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkAccess;)V - java/io/IOException,net/minecraft/world/level/LevelConflictException
 method protected a (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/nbt/CompoundTag;)V - -
 method public a ()Z - -
 method public b ()V - -
 method public,static a ([Lit/unimi/dsi/fastutil/shorts/ShortList;)Lnet/minecraft/nbt/ListTag; - -
 method public,static a (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/LevelChunk;)Lnet/minecraft/world/entity/Entity; - -
 method public,static a (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/level/Level;DDDZ)Lnet/minecraft/world/entity/Entity; - -
 method public,static a (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/level/Level;Z)Lnet/minecraft/world/entity/Entity; - -
 method protected,static a (Lnet/minecraft/nbt/CompoundTag;Lnet/minecraft/world/level/Level;)Lnet/minecraft/world/entity/Entity; - -
 method public,static a (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/level/LevelAccessor;)V - -
 method public a (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/dimension/DimensionType;Lcck;)Z - -
 method public getPendingSaveCount ()I - -
in 59
class bnw 52 public,interface,abstract java/lang/Object - -
 method public,abstract a (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer;)Lnet/minecraft/world/level/chunk/LevelChunk; (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer<Lnet/minecraft/world/level/chunk/LevelChunk;>;)Lnet/minecraft/world/level/chunk/LevelChunk; java/io/IOException
 method public,abstract b (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer;)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/LevelAccessor;IILjava/util/function/Consumer<Lnet/minecraft/world/level/chunk/ChunkAccess;>;)Lnet/minecraft/world/level/chunk/ProtoChunk; java/io/IOException
 method public,abstract a (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkAccess;)V - java/io/IOException,net/minecraft/world/level/LevelConflictException
 method public,abstract b ()V - -
in 59
class bom 52 public,interface,abstract java/lang/Object - -
 method public,abstract getVillagesSpacing ()I - -
 method public,abstract getVillagesSeparation ()I - -
 method public,abstract getMonumentsSpacing ()I - -
 method public,abstract getMonumentsSeparation ()I - -
 method public,abstract getStrongholdsDistance ()I - -
 method public,abstract getStrongholdsCount ()I - -
 method public,abstract getStrongholdsSpread ()I - -
 method public,abstract getTemplesSpacing ()I - -
 method public,abstract getTemplesSeparation ()I - -
 method public,abstract getShipwreckSpacing ()I - -
 method public,abstract getShipwreckSeparation ()I - -
 method public,abstract getOceanRuinSpacing ()I - -
 method public,abstract getOceanRuinSeparation ()I - -
 method public,abstract getEndCitySpacing ()I - -
 method public,abstract getEndCitySeparation ()I - -
 method public,abstract getWoodlandMansionSpacing ()I - -
 method public,abstract getWoodlandMangionSeparation ()I - -
 method public,abstract getDefaultBlock ()Lnet/minecraft/world/level/block/state/BlockState; - -
 method public,abstract getDefaultFluid ()Lnet/minecraft/world/level/block/state/BlockState; - -
in 59
class bon 52 public,super net/minecraft/world/level/levelgen/ChunkGeneratorSettings - -
 method public <init> ()V - -
in 131
class bot 52 public,super bmz - Lbmz<Lnet/minecraft/world/level/levelgen/NetherGeneratorSettings;>;
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/world/level/biome/Biome$SpawnerData net/minecraft/world/level/biome/Biome SpawnerData public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 field protected,static,final f Lnet/minecraft/world/level/block/state/BlockState; -
 field protected,static,final g Lnet/minecraft/world/level/block/state/BlockState; -
 field protected,static,final h Lnet/minecraft/world/level/block/state/BlockState; -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/biome/BiomeSource;Lnet/minecraft/world/level/levelgen/NetherGeneratorSettings;)V - -
 method public a (IILnet/minecraft/world/level/chunk/ChunkAccess;)V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkAccess;Ljava/util/Random;)V - -
 method public a (II)[D - -
 method public a (Lnet/minecraft/world/level/chunk/ChunkAccess;)V - -
 method public spawnOriginalMobs (Lnet/minecraft/server/level/WorldGenRegion;)V - -
 method public getMobsAt (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Ljava/util/List; (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Ljava/util/List<Lnet/minecraft/world/level/biome/Biome$SpawnerData;>; -
 method public tickCustomSpawners (Lnet/minecraft/world/level/Level;ZZ)I - -
 method public getSettings ()Lnet/minecraft/world/level/levelgen/NetherGeneratorSettings; - -
 method public getSpawnHeight ()I - -
 method public getGenDepth ()I - -
in 135
class bot 52 public,super bmz - Lbmz<Lnet/minecraft/world/level/levelgen/NetherGeneratorSettings;>;
 inner net/minecraftforge/event/terraingen/InitNoiseGensEvent$ContextHell net/minecraftforge/event/terraingen/InitNoiseGensEvent ContextHell public,static
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraftforge/event/terraingen/ChunkGeneratorEvent$InitNoiseField net/minecraftforge/event/terraingen/ChunkGeneratorEvent InitNoiseField public,static
 inner net/minecraft/world/level/biome/Biome$SpawnerData net/minecraft/world/level/biome/Biome SpawnerData public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraftforge/event/terraingen/InitNoiseGensEvent$Context net/minecraftforge/event/terraingen/InitNoiseGensEvent Context public,static
 inner net/minecraftforge/eventbus/api/Event$Result net/minecraftforge/eventbus/api/Event Result public,static,final,enum
 field protected,static,final f Lnet/minecraft/world/level/block/state/BlockState; -
 field protected,static,final g Lnet/minecraft/world/level/block/state/BlockState; -
 field protected,static,final h Lnet/minecraft/world/level/block/state/BlockState; -
 method public <init> (Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/biome/BiomeSource;Lnet/minecraft/world/level/levelgen/NetherGeneratorSettings;)V - -
 method public a (IILnet/minecraft/world/level/chunk/ChunkAccess;)V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkAccess;Ljava/util/Random;)V - -
 method public a (II)[D - -
 method public a (Lnet/minecraft/world/level/chunk/ChunkAccess;)V - -
 method public spawnOriginalMobs (Lnet/minecraft/server/level/WorldGenRegion;)V - -
 method public getMobsAt (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Ljava/util/List; (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Ljava/util/List<Lnet/minecraft/world/level/biome/Biome$SpawnerData;>; -
 method public tickCustomSpawners (Lnet/minecraft/world/level/Level;ZZ)I - -
 method public getSettings ()Lnet/minecraft/world/level/levelgen/NetherGeneratorSettings; - -
 method public getSpawnHeight ()I - -
 method public getGenDepth ()I - -
in 131
class boy 52 public,super bmz - Lbmz<Lnet/minecraft/world/level/levelgen/TheEndGeneratorSettings;>;
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/world/level/biome/Biome$SpawnerData net/minecraft/world/level/biome/Biome SpawnerData public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 field protected,static,final f Lnet/minecraft/world/level/block/state/BlockState; -
 method public <init> (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/biome/BiomeSource;Lnet/minecraft/world/level/levelgen/TheEndGeneratorSettings;)V - -
 method public a (IILnet/minecraft/world/level/chunk/ChunkAccess;)V - -
 method public a (Lnet/minecraft/world/level/chunk/ChunkAccess;)V - -
 method public spawnOriginalMobs (Lnet/minecraft/server/level/WorldGenRegion;)V - -
 method public getMobsAt (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Ljava/util/List; (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Ljava/util/List<Lnet/minecraft/world/level/biome/Biome$SpawnerData;>; -
 method public f ()Lnet/minecraft/core/BlockPos; - -
 method public tickCustomSpawners (Lnet/minecraft/world/level/Level;ZZ)I - -
 method public getSettings ()Lnet/minecraft/world/level/levelgen/TheEndGeneratorSettings; - -
 method public a (II)[D - -
 method public getSpawnHeight ()I - -
in 135
class boy 52 public,super bmz - Lbmz<Lnet/minecraft/world/level/levelgen/TheEndGeneratorSettings;>;
 inner net/minecraftforge/event/terraingen/InitNoiseGensEvent$ContextEnd net/minecraftforge/event/terraingen/InitNoiseGensEvent ContextEnd public,static
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraftforge/event/terraingen/ChunkGeneratorEvent$InitNoiseField net/minecraftforge/event/terraingen/ChunkGeneratorEvent InitNoiseField public,static
 inner net/minecraft/world/level/biome/Biome$SpawnerData net/minecraft/world/level/biome/Biome SpawnerData public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraftforge/event/terraingen/InitNoiseGensEvent$Context net/minecraftforge/event/terraingen/InitNoiseGensEvent Context public,static
 inner net/minecraftforge/eventbus/api/Event$Result net/minecraftforge/eventbus/api/Event Result public,static,final,enum
 field protected,static,final f Lnet/minecraft/world/level/block/state/BlockState; -
 method public <init> (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/biome/BiomeSource;Lnet/minecraft/world/level/levelgen/TheEndGeneratorSettings;)V - -
 method public a (IILnet/minecraft/world/level/chunk/ChunkAccess;)V - -
 method public a (Lnet/minecraft/world/level/chunk/ChunkAccess;)V - -
 method public spawnOriginalMobs (Lnet/minecraft/server/level/WorldGenRegion;)V - -
 method public getMobsAt (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Ljava/util/List; (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Ljava/util/List<Lnet/minecraft/world/level/biome/Biome$SpawnerData;>; -
 method public f ()Lnet/minecraft/core/BlockPos; - -
 method public tickCustomSpawners (Lnet/minecraft/world/level/Level;ZZ)I - -
 method public getSettings ()Lnet/minecraft/world/level/levelgen/TheEndGeneratorSettings; - -
 method public a (II)[D - -
 method public getSpawnHeight ()I - -
in 59
class bpn 52 public,super net/minecraft/world/level/levelgen/feature/Feature - <F::Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;D::Lnet/minecraft/world/level/levelgen/feature/DecoratorConfiguration;>Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;>;
 field protected,final a Lnet/minecraft/world/level/levelgen/feature/Feature; Lnet/minecraft/world/level/levelgen/feature/Feature<TF;>;
 field protected,final b Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration; TF;
 field protected,final c Lbvg; Lbvg<TD;>;
 field protected,final d Lnet/minecraft/world/level/levelgen/feature/DecoratorConfiguration; TD;
 method public <init> (Lnet/minecraft/world/level/levelgen/feature/Feature;Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;Lbvg;Lnet/minecraft/world/level/levelgen/feature/DecoratorConfiguration;)V (Lnet/minecraft/world/level/levelgen/feature/Feature<TF;>;TF;Lbvg<TD;>;TD;)V -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z -
 method public toString ()Ljava/lang/String; - -
 method public a ()Lnet/minecraft/world/level/levelgen/feature/Feature; ()Lnet/minecraft/world/level/levelgen/feature/Feature<TF;>; -
in 59
class bqb 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class bqi 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class bqr 52 public,super bpn - <D::Lnet/minecraft/world/level/levelgen/feature/DecoratorConfiguration;>Lbpn<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;TD;>;
 method public <init> (Lbqs;Lbvg;Lnet/minecraft/world/level/levelgen/feature/DecoratorConfiguration;)V (Lbqs;Lbvg<TD;>;TD;)V -
 method public a (Ljava/util/Random;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
in 59
class bqs 52 public,super,abstract net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z -
 method public,abstract getRandomFlower (Ljava/util/Random;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/block/state/BlockState; - -
in 59
class bqy 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/HellSpringConfiguration;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/HellSpringConfiguration;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/HellSpringConfiguration;)Z -
in 59
class brf 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class bri 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class bro 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z -
in 59
class brw 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class bsa 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class bsi 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z -
in 59
class bsm 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/RandomRandomFeatureConfig;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/RandomRandomFeatureConfig;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/RandomRandomFeatureConfig;)Z -
in 59
class bsp 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/RandomFeatureConfig;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/RandomFeatureConfig;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/RandomFeatureConfig;)Z -
in 59
class bst 52 public,super net/minecraft/world/level/levelgen/feature/AbstractTreeFeature - Lnet/minecraft/world/level/levelgen/feature/AbstractTreeFeature<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;>;
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 inner net/minecraft/core/Direction$Plane net/minecraft/core/Direction Plane public,static,final,enum
 method public <init> (Z)V - -
 method public doPlace (Ljava/util/Set;Lnet/minecraft/world/level/LevelAccessor;Ljava/util/Random;Lnet/minecraft/core/BlockPos;)Z (Ljava/util/Set<Lnet/minecraft/core/BlockPos;>;Lnet/minecraft/world/level/LevelAccessor;Ljava/util/Random;Lnet/minecraft/core/BlockPos;)Z -
in 59
class btd 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/SimpleRandomFeatureConfig;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/SimpleRandomFeatureConfig;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/SimpleRandomFeatureConfig;)Z -
in 59
class btf 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;>;
 inner net/minecraft/world/level/levelgen/feature/SpikeFeature$EndSpike btf EndSpike public,static
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/level/levelgen/feature/SpikeFeature$EndSpike;)V - -
 method public a (Z)V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z -
 method public a (Lnet/minecraft/core/BlockPos;)V - -
in 59
class bth 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lnet/minecraft/world/level/levelgen/feature/SpringConfiguration;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/SpringConfiguration;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/SpringConfiguration;)Z -
in 59
class btj 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class bto 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class btr 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 field public,final a Lnet/minecraft/world/level/block/state/BlockState; -
 method public <init> (Lnet/minecraft/world/level/block/state/BlockState;)V - -
in 59
class bts 52 public,super net/minecraft/world/level/levelgen/feature/Feature - Lnet/minecraft/world/level/levelgen/feature/Feature<Lbtr;>;
 method public <init> ()V - -
 method public place (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lbtr;)Z (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lbtr;)Z -
in 59
class btz 52 public,super java/lang/Object net/minecraft/world/level/levelgen/feature/FeatureConfiguration -
 method public <init> ()V - -
in 59
class bvg 52 public,super,abstract java/lang/Object - <T::Lnet/minecraft/world/level/levelgen/feature/DecoratorConfiguration;>Ljava/lang/Object;
 method public <init> ()V - -
 method public,abstract a (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/DecoratorConfiguration;Lnet/minecraft/world/level/levelgen/feature/Feature;Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;)Z <C::Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;TT;Lnet/minecraft/world/level/levelgen/feature/Feature<TC;>;TC;)Z -
 method public toString ()Ljava/lang/String; - -
in 59
class bvr 52 public,super bvg - Lbvg<Lnet/minecraft/world/level/levelgen/feature/NoneDecoratorConfiguration;>;
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneDecoratorConfiguration;Lnet/minecraft/world/level/levelgen/feature/Feature;Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;)Z <C::Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneDecoratorConfiguration;Lnet/minecraft/world/level/levelgen/feature/Feature<TC;>;TC;)Z -
in 59
class bvs 52 public,super bvg - Lbvg<Lnet/minecraft/world/level/levelgen/feature/NoneDecoratorConfiguration;>;
 inner bvs$a bvs a static
 inner net/minecraft/world/level/levelgen/feature/SpikeFeature$EndSpike btf EndSpike public,static
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneDecoratorConfiguration;Lnet/minecraft/world/level/levelgen/feature/Feature;Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;)Z <C::Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>(Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/chunk/ChunkGenerator<+Lbom;>;Ljava/util/Random;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/feature/NoneDecoratorConfiguration;Lnet/minecraft/world/level/levelgen/feature/Feature<TC;>;TC;)Z -
 method public,static a (Lnet/minecraft/world/level/LevelAccessor;)[Lnet/minecraft/world/level/levelgen/feature/SpikeFeature$EndSpike; - -
in 59
class bvs$a 52 super com/google/common/cache/CacheLoader - Lcom/google/common/cache/CacheLoader<Ljava/lang/Long;[Lnet/minecraft/world/level/levelgen/feature/SpikeFeature$EndSpike;>;
 inner bvs$a bvs a static
 inner net/minecraft/world/level/levelgen/feature/SpikeFeature$EndSpike btf EndSpike public,static
 method public a (Ljava/lang/Long;)[Lnet/minecraft/world/level/levelgen/feature/SpikeFeature$EndSpike; - java/lang/Exception
in 59
class bwg 52 public,super java/lang/Object - -
 inner net/minecraft/world/level/levelgen/structure/BuriedTreasurePieces$BuriedTreasurePiece bwg BuriedTreasurePiece public,static
 method public,static a ()V - -
in 59
class bwj 52 public,super java/lang/Object bxj <C::Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>Ljava/lang/Object;Lbxj<Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;>;
 method public <init> (Lbxj;Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;)V (Lbxj<TC;>;TC;)V -
 method public a (Lnet/minecraft/world/level/BlockGetter;Ljava/util/Random;IILnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z - -
 method public a (Lnet/minecraft/world/level/LevelAccessor;Ljava/util/Random;IIIILjava/util/BitSet;Lnet/minecraft/world/level/levelgen/feature/NoneFeatureConfiguration;)Z - -
in 59
class bxj 52 public,interface,abstract java/lang/Object - <C::Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;>Ljava/lang/Object;
 method public,abstract a (Lnet/minecraft/world/level/BlockGetter;Ljava/util/Random;IILnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;)Z (Lnet/minecraft/world/level/BlockGetter;Ljava/util/Random;IITC;)Z -
 method public,abstract a (Lnet/minecraft/world/level/LevelAccessor;Ljava/util/Random;IIIILjava/util/BitSet;Lnet/minecraft/world/level/levelgen/feature/FeatureConfiguration;)Z (Lnet/minecraft/world/level/LevelAccessor;Ljava/util/Random;IIIILjava/util/BitSet;TC;)Z -
in 59
class bxo 52 public,interface,abstract java/lang/Object - -
 inner net/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate$StructureBlockInfo net/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate StructureBlockInfo public,static
 method public,abstract a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate$StructureBlockInfo;)Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate$StructureBlockInfo; - -
in 59
class bxr 52 public,super java/lang/Object byc <C::Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderConfiguration;>Ljava/lang/Object;Lbyc<Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;>;
 method public <init> (Lbyc;Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderConfiguration;)V (Lbyc<TC;>;TC;)V -
 method public apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;)V - -
 method public initNoise (J)V - -
 method public a ()Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderConfiguration; ()TC; -
in 59
class bxt 52 public,super java/lang/Object byc Ljava/lang/Object;Lbyc<Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;>;
 method public <init> ()V - -
 method public apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;)V - -
in 59
class bxu 52 public,super java/lang/Object byc Ljava/lang/Object;Lbyc<Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;>;
 method public <init> ()V - -
 method public apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;)V - -
in 59
class bxw 52 public,super bxy - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 method public <init> ()V - -
 method public apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;)V - -
in 59
class bxx 52 public,super bxy - -
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 method public <init> ()V - -
 method public apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;)V - -
in 59
class bxy 52 public,super java/lang/Object byc Ljava/lang/Object;Lbyc<Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;>;
 inner net/minecraft/core/BlockPos$MutableBlockPos net/minecraft/core/BlockPos MutableBlockPos public,static
 field protected a [Lnet/minecraft/world/level/block/state/BlockState; -
 field protected b J -
 field protected c Lnet/minecraft/world/level/levelgen/synth/PerlinSimplexNoise; -
 field protected d Lnet/minecraft/world/level/levelgen/synth/PerlinSimplexNoise; -
 field protected e Lnet/minecraft/world/level/levelgen/synth/PerlinSimplexNoise; -
 method public <init> ()V - -
 method public apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;)V - -
 method public initNoise (J)V - -
 method protected b (J)V - -
 method protected a (III)Lnet/minecraft/world/level/block/state/BlockState; - -
in 59
class byb 52 public,super java/lang/Object byc Ljava/lang/Object;Lbyc<Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;>;
 method public <init> ()V - -
 method public apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;)V - -
in 59
class byc 52 public,interface,abstract java/lang/Object - <C::Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderConfiguration;>Ljava/lang/Object;
 method public,abstract apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderConfiguration;)V (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJTC;)V -
 method public initNoise (J)V - -
in 59
class byg 52 public,super java/lang/Object byc Ljava/lang/Object;Lbyc<Lnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;>;
 method public <init> ()V - -
 method public apply (Ljava/util/Random;Lnet/minecraft/world/level/chunk/ChunkAccess;Lnet/minecraft/world/level/biome/Biome;IIIDLnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;IJLnet/minecraft/world/level/levelgen/surfacebuilders/SurfaceBuilderBaseConfiguration;)V - -
in 59
class bym 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
in 59
class byo 52 public,super,abstract java/lang/Object byq -
 inner net/minecraft/core/BlockPos$PooledMutableBlockPos net/minecraft/core/BlockPos PooledMutableBlockPos public,static,final
 method public <init> ()V - -
 method public a (Layc;Lnet/minecraft/core/BlockPos;)I - -
 method public a (Lnet/minecraft/world/level/LevelWriter;Lnet/minecraft/core/BlockPos;I)V - -
 method protected a (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)I - -
 method protected b (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)I - -
 method protected a (Lnet/minecraft/world/level/LevelAccessor;Lnet/minecraft/world/level/ChunkPos;)V - -
 method protected a (Lnet/minecraft/world/level/ChunkPos;IIII)V - -
 method protected a (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/core/BlockPos;I)V - -
in 59
class byq 52 public,interface,abstract java/lang/Object - -
 method public,abstract a ()Lnet/minecraft/world/level/LightLayer; - -
in 59
class bzg 52 public,final,super java/lang/Object - -
 method public <init> (IIII)V - -
 method public a ()I - -
 method public b ()I - -
 method public c ()I - -
 method public d ()I - -
in 59
class bzk 52 public,interface,abstract java/lang/Object bzl <R::Lnet/minecraft/world/level/newbiome/area/Area;>Ljava/lang/Object;Lbzl;
 method public,abstract initRandom (JJ)V - -
 method public,abstract a (Lbzg;Lnet/minecraft/world/level/newbiome/layer/traits/PixelTransformer;)Lnet/minecraft/world/level/newbiome/area/Area; (Lbzg;Lnet/minecraft/world/level/newbiome/layer/traits/PixelTransformer;)TR; -
 method public a (Lbzg;Lnet/minecraft/world/level/newbiome/layer/traits/PixelTransformer;Lnet/minecraft/world/level/newbiome/area/Area;)Lnet/minecraft/world/level/newbiome/area/Area; (Lbzg;Lnet/minecraft/world/level/newbiome/layer/traits/PixelTransformer;TR;)TR; -
 method public a (Lbzg;Lnet/minecraft/world/level/newbiome/layer/traits/PixelTransformer;Lnet/minecraft/world/level/newbiome/area/Area;Lnet/minecraft/world/level/newbiome/area/Area;)Lnet/minecraft/world/level/newbiome/area/Area; (Lbzg;Lnet/minecraft/world/level/newbiome/layer/traits/PixelTransformer;TR;TR;)TR; -
 method public,varargs,abstract a ([I)I - -
in 59
class bzl 52 public,interface,abstract java/lang/Object - -
 method public,abstract nextRandom (I)I - -
 method public,abstract getBiomeNoise ()Lnet/minecraft/world/level/levelgen/synth/ImprovedNoise; - -
in 59
class bzm 52 public,super,abstract java/lang/Object bzk <R::Lnet/minecraft/world/level/newbiome/area/Area;>Ljava/lang/Object;Lbzk<TR;>;
 field protected a J -
 field protected b Lnet/minecraft/world/level/levelgen/synth/ImprovedNoise; -
 method public <init> (J)V - -
 method public a (J)V - -
 method public initRandom (JJ)V - -
 method public nextRandom (I)I - -
 method public,varargs a ([I)I - -
 method public getBiomeNoise ()Lnet/minecraft/world/level/levelgen/synth/ImprovedNoise; - -
in 59
class bzp 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/CastleTransformer Ljava/lang/Enum<Lbzp;>;Lnet/minecraft/world/level/newbiome/layer/traits/CastleTransformer;
 field public,static,final,enum INSTANCE Lbzp; -
 method public,static values ()[Lbzp; - -
 method public,static valueOf (Ljava/lang/String;)Lbzp; - -
 method public apply (Lbzl;IIIII)I - -
in 59
class bzq 52 public,super java/lang/Object - -
 inner bzq$c bzq c public,static,final,enum
 inner bzq$b bzq b public,static,final,enum
 inner bzq$a bzq a public,static,final,enum
in 59
class bzq$a 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/CastleTransformer Ljava/lang/Enum<Lbzq$a;>;Lnet/minecraft/world/level/newbiome/layer/traits/CastleTransformer;
 inner bzq$a bzq a public,static,final,enum
 field public,static,final,enum INSTANCE Lbzq$a; -
 method public,static values ()[Lbzq$a; - -
 method public,static valueOf (Ljava/lang/String;)Lbzq$a; - -
 method public apply (Lbzl;IIIII)I - -
in 59
class bzq$b 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/CastleTransformer Ljava/lang/Enum<Lbzq$b;>;Lnet/minecraft/world/level/newbiome/layer/traits/CastleTransformer;
 inner bzq$b bzq b public,static,final,enum
 field public,static,final,enum INSTANCE Lbzq$b; -
 method public,static values ()[Lbzq$b; - -
 method public,static valueOf (Ljava/lang/String;)Lbzq$b; - -
 method public apply (Lbzl;IIIII)I - -
in 59
class bzq$c 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/C0Transformer Ljava/lang/Enum<Lbzq$c;>;Lnet/minecraft/world/level/newbiome/layer/traits/C0Transformer;
 inner bzq$c bzq c public,static,final,enum
 field public,static,final,enum INSTANCE Lbzq$c; -
 method public,static values ()[Lbzq$c; - -
 method public,static valueOf (Ljava/lang/String;)Lbzq$c; - -
 method public apply (Lbzl;I)I - -
in 59
class bzr 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/BishopTransformer Ljava/lang/Enum<Lbzr;>;Lnet/minecraft/world/level/newbiome/layer/traits/BishopTransformer;
 field public,static,final,enum INSTANCE Lbzr; -
 method public,static values ()[Lbzr; - -
 method public,static valueOf (Ljava/lang/String;)Lbzr; - -
 method public apply (Lbzl;IIIII)I - -
in 59
class bzt 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/C1Transformer Ljava/lang/Enum<Lbzt;>;Lnet/minecraft/world/level/newbiome/layer/traits/C1Transformer;
 field public,static,final,enum INSTANCE Lbzt; -
 method public,static values ()[Lbzt; - -
 method public,static valueOf (Ljava/lang/String;)Lbzt; - -
 method public apply (Lbzl;I)I - -
in 59
class bzw 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/AreaTransformer0 Ljava/lang/Enum<Lbzw;>;Lnet/minecraft/world/level/newbiome/layer/traits/AreaTransformer0;
 field public,static,final,enum INSTANCE Lbzw; -
 method public,static values ()[Lbzw; - -
 method public,static valueOf (Ljava/lang/String;)Lbzw; - -
 method public a (Lbzl;Lbzg;II)I - -
in 59
class caa 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/AreaTransformer2,net/minecraft/world/level/newbiome/layer/traits/DimensionOffset0Transformer Ljava/lang/Enum<Lcaa;>;Lnet/minecraft/world/level/newbiome/layer/traits/AreaTransformer2;Lnet/minecraft/world/level/newbiome/layer/traits/DimensionOffset0Transformer;
 field public,static,final,enum INSTANCE Lcaa; -
 method public,static values ()[Lcaa; - -
 method public,static valueOf (Ljava/lang/String;)Lcaa; - -
 method public a (Lbzl;Lbzg;Lnet/minecraft/world/level/newbiome/area/Area;Lnet/minecraft/world/level/newbiome/area/Area;II)I - -
in 59
class cad 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/CastleTransformer Ljava/lang/Enum<Lcad;>;Lnet/minecraft/world/level/newbiome/layer/traits/CastleTransformer;
 field public,static,final,enum INSTANCE Lcad; -
 method public,static values ()[Lcad; - -
 method public,static valueOf (Ljava/lang/String;)Lcad; - -
 method public apply (Lbzl;IIIII)I - -
in 59
class cae 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/C0Transformer Ljava/lang/Enum<Lcae;>;Lnet/minecraft/world/level/newbiome/layer/traits/C0Transformer;
 field public,static,final,enum INSTANCE Lcae; -
 method public,static values ()[Lcae; - -
 method public,static valueOf (Ljava/lang/String;)Lcae; - -
 method public apply (Lbzl;I)I - -
in 59
class cai 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/CastleTransformer Ljava/lang/Enum<Lcai;>;Lnet/minecraft/world/level/newbiome/layer/traits/CastleTransformer;
 field public,static,final,enum INSTANCE Lcai; -
 method public,static values ()[Lcai; - -
 method public,static valueOf (Ljava/lang/String;)Lcai; - -
 method public apply (Lbzl;IIIII)I - -
in 59
class caj 52 public,final,super,enum java/lang/Enum net/minecraft/world/level/newbiome/layer/traits/AreaTransformer1 Ljava/lang/Enum<Lcaj;>;Lnet/minecraft/world/level/newbiome/layer/traits/AreaTransformer1;
 field public,static,final,enum INSTANCE Lcaj; -
 method public,static values ()[Lcaj; - -
 method public,static valueOf (Ljava/lang/String;)Lcaj; - -
 method public a (Lbzk;Lbzg;Lnet/minecraft/world/level/newbiome/area/Area;II)I (Lbzk<*>;Lbzg;Lnet/minecraft/world/level/newbiome/area/Area;II)I -
 method public a (Lbzg;)Lbzg; - -
in 59
class cbv 52 public,super net/minecraft/world/level/storage/LevelStorage - -
 method public <init> (Ljava/io/File;Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;Lcom/mojang/datafixers/DataFixer;)V - -
 method public a (Lnet/minecraft/world/level/dimension/Dimension;)Lbnw; - -
 method public saveLevelData (Lnet/minecraft/world/level/storage/LevelData;Lnet/minecraft/nbt/CompoundTag;)V - -
 method public a ()V - -
in 131
class cbw 52 public,super cca - -
 inner net/minecraft/world/level/chunk/storage/OldChunkStorage$OldLevelChunk net/minecraft/world/level/chunk/storage/ChunkStorage OldLevelChunk public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public getName ()Ljava/lang/String; - -
 method public getLevelList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/world/level/storage/LevelSummary;>; net/minecraft/world/level/storage/LevelStorageException
 method public d ()V - -
 method public a (Ljava/lang/String;)Z - -
 method public <init> (Ljava/nio/file/Path;Ljava/nio/file/Path;Lcom/mojang/datafixers/DataFixer;)V - -
 method protected c ()I - -
 method public selectLevel (Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)Lccc; - -
 method public requiresConversion (Ljava/lang/String;)Z - -
 method public convertLevel (Ljava/lang/String;Lnet/minecraft/util/ProgressListener;)Z - -
in 135
class cbw 52 public,super cca - -
 inner net/minecraft/world/level/chunk/storage/OldChunkStorage$OldLevelChunk net/minecraft/world/level/chunk/storage/ChunkStorage OldLevelChunk public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ljava/nio/file/Path;Ljava/nio/file/Path;Lcom/mojang/datafixers/DataFixer;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getLevelList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/world/level/storage/LevelSummary;>; net/minecraft/world/level/storage/LevelStorageException
 method protected c ()I - -
 method public d ()V - -
 method public selectLevel (Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)Lccc; - -
 method public a (Ljava/lang/String;)Z - -
 method public requiresConversion (Ljava/lang/String;)Z - -
 method public convertLevel (Ljava/lang/String;Lnet/minecraft/util/ProgressListener;)Z - -
in 131
class cca 52 public,super java/lang/Object net/minecraft/world/level/storage/LevelStorageSource -
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 field protected,final a Ljava/nio/file/Path; -
 field protected,final b Ljava/nio/file/Path; -
 field protected,final c Lcom/mojang/datafixers/DataFixer; -
 method public getName ()Ljava/lang/String; - -
 method public getLevelList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/world/level/storage/LevelSummary;>; net/minecraft/world/level/storage/LevelStorageException
 method public d ()V - -
 method public renameLevel (Ljava/lang/String;Ljava/lang/String;)V - -
 method public isNewLevelIdAcceptable (Ljava/lang/String;)Z - -
 method public deleteLevel (Ljava/lang/String;)Z - -
 method protected,static a ([Ljava/io/File;)Z - -
 method public a (Ljava/lang/String;)Z - -
 method public levelExists (Ljava/lang/String;)Z - -
 method public getLevelPath (Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getBackupPath ()Ljava/nio/file/Path; - -
 method public <init> (Ljava/nio/file/Path;Ljava/nio/file/Path;Lcom/mojang/datafixers/DataFixer;)V - -
 method public getDataTagFor (Ljava/lang/String;)Lnet/minecraft/world/level/storage/LevelData; - -
 method public,static a (Ljava/io/File;Lcom/mojang/datafixers/DataFixer;)Lnet/minecraft/world/level/storage/LevelData; - -
 method public selectLevel (Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)Lccc; - -
 method public requiresConversion (Ljava/lang/String;)Z - -
 method public convertLevel (Ljava/lang/String;Lnet/minecraft/util/ProgressListener;)Z - -
 method public getFile (Ljava/lang/String;Ljava/lang/String;)Ljava/io/File; - -
in 135
class cca 52 public,super java/lang/Object net/minecraft/world/level/storage/LevelStorageSource -
 inner net/minecraftforge/fml/StartupQuery$AbortedException net/minecraftforge/fml/StartupQuery AbortedException public,static
 inner com/mojang/datafixers/DSL$TypeReference com/mojang/datafixers/DSL TypeReference public,static,interface,abstract
 field public,final a Ljava/nio/file/Path; -
 field protected,final b Ljava/nio/file/Path; -
 field protected,final c Lcom/mojang/datafixers/DataFixer; -
 method public <init> (Ljava/nio/file/Path;Ljava/nio/file/Path;Lcom/mojang/datafixers/DataFixer;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getLevelList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/world/level/storage/LevelSummary;>; net/minecraft/world/level/storage/LevelStorageException
 method public d ()V - -
 method public getDataTagFor (Ljava/lang/String;)Lnet/minecraft/world/level/storage/LevelData; - -
 method public,static a (Ljava/io/File;Lcom/mojang/datafixers/DataFixer;)Lnet/minecraft/world/level/storage/LevelData; - -
 method public,static getWorldData (Ljava/io/File;Lcom/mojang/datafixers/DataFixer;Lnet/minecraft/world/level/storage/LevelStorage;)Lnet/minecraft/world/level/storage/LevelData; - -
 method public renameLevel (Ljava/lang/String;Ljava/lang/String;)V - -
 method public isNewLevelIdAcceptable (Ljava/lang/String;)Z - -
 method public deleteLevel (Ljava/lang/String;)Z - -
 method protected,static a ([Ljava/io/File;)Z - -
 method public selectLevel (Ljava/lang/String;Lnet/minecraft/server/MinecraftServer;)Lccc; - -
 method public a (Ljava/lang/String;)Z - -
 method public requiresConversion (Ljava/lang/String;)Z - -
 method public convertLevel (Ljava/lang/String;Lnet/minecraft/util/ProgressListener;)Z - -
 method public levelExists (Ljava/lang/String;)Z - -
 method public getFile (Ljava/lang/String;Ljava/lang/String;)Ljava/io/File; - -
 method public getLevelPath (Ljava/lang/String;)Ljava/nio/file/Path; - -
 method public getBackupPath ()Ljava/nio/file/Path; - -
in 59
class ccc 52 public,interface,abstract java/lang/Object - -
 method public,abstract prepareLevel ()Lnet/minecraft/world/level/storage/LevelData; - -
 method public,abstract checkSession ()V - net/minecraft/world/level/LevelConflictException
 method public,abstract a (Lnet/minecraft/world/level/dimension/Dimension;)Lbnw; - -
 method public,abstract saveLevelData (Lnet/minecraft/world/level/storage/LevelData;Lnet/minecraft/nbt/CompoundTag;)V - -
 method public,abstract saveLevelData (Lnet/minecraft/world/level/storage/LevelData;)V - -
 method public,abstract e ()Lnet/minecraft/world/level/storage/PlayerIO; - -
 method public,abstract a ()V - -
 method public,abstract getFolder ()Ljava/io/File; - -
 method public,abstract a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/lang/String;)Ljava/io/File; - -
 method public,abstract getStructureManager ()Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureManager; - -
 method public,abstract getFixerUpper ()Lcom/mojang/datafixers/DataFixer; - -
in 59
class cch 52 public,super java/lang/Object ccc -
 method public <init> ()V - -
 method public prepareLevel ()Lnet/minecraft/world/level/storage/LevelData; - -
 method public checkSession ()V - net/minecraft/world/level/LevelConflictException
 method public a (Lnet/minecraft/world/level/dimension/Dimension;)Lbnw; - -
 method public saveLevelData (Lnet/minecraft/world/level/storage/LevelData;Lnet/minecraft/nbt/CompoundTag;)V - -
 method public saveLevelData (Lnet/minecraft/world/level/storage/LevelData;)V - -
 method public e ()Lnet/minecraft/world/level/storage/PlayerIO; - -
 method public a ()V - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/lang/String;)Ljava/io/File; - -
 method public getFolder ()Ljava/io/File; - -
 method public getStructureManager ()Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureManager; - -
 method public getFixerUpper ()Lcom/mojang/datafixers/DataFixer; - -
in 59
class ccj 52 public,super cck - -
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/lang/String;)I - -
in 59
class cck 52 public,super java/lang/Object - -
 inner com/google/common/collect/ImmutableMap$Builder com/google/common/collect/ImmutableMap Builder public,static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lccc;)V - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/util/function/Function;Ljava/lang/String;)Lnet/minecraft/world/level/saveddata/SavedData; <T:Lnet/minecraft/world/level/saveddata/SavedData;>(Lnet/minecraft/world/level/dimension/DimensionType;Ljava/util/function/Function<Ljava/lang/String;TT;>;Ljava/lang/String;)TT; -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/lang/String;Lnet/minecraft/world/level/saveddata/SavedData;)V - -
 method public a ()V - -
 method public a (Lnet/minecraft/world/level/dimension/DimensionType;Ljava/lang/String;)I - -
 method public a (Ljava/lang/String;I)Lnet/minecraft/nbt/CompoundTag; - java/io/IOException
in 131
class ccm 52 public,super net/minecraft/world/level/storage/loot/entries/LootPoolEntryContainer - -
 method public <init> (II[Lcdk;)V - -
 method public a (Ljava/util/Collection;Ljava/util/Random;Lnet/minecraft/world/level/storage/loot/LootContext;)V (Ljava/util/Collection<Lnet/minecraft/world/item/ItemStack;>;Ljava/util/Random;Lnet/minecraft/world/level/storage/loot/LootContext;)V -
 method protected a (Lcom/google/gson/JsonObject;Lcom/google/gson/JsonSerializationContext;)V - -
 method public,static a (Lcom/google/gson/JsonObject;Lcom/google/gson/JsonDeserializationContext;II[Lcdk;)Lccm; - -
in 135
class ccm 52 public,super net/minecraft/world/level/storage/loot/entries/LootPoolEntryContainer - -
 method public <init> (II[Lcdk;Ljava/lang/String;)V - -
 method public a (Ljava/util/Collection;Ljava/util/Random;Lnet/minecraft/world/level/storage/loot/LootContext;)V (Ljava/util/Collection<Lnet/minecraft/world/item/ItemStack;>;Ljava/util/Random;Lnet/minecraft/world/level/storage/loot/LootContext;)V -
 method protected a (Lcom/google/gson/JsonObject;Lcom/google/gson/JsonSerializationContext;)V - -
 method public,static a (Lcom/google/gson/JsonObject;Lcom/google/gson/JsonDeserializationContext;II[Lcdk;)Lccm; - -
in 59
class ccy 52 public,super,abstract java/lang/Object - -
 inner net/minecraft/world/level/storage/loot/functions/LootItemFunction$Serializer ccy Serializer public,static,abstract
 method protected <init> ([Lcdk;)V - -
 method public,abstract a (Lnet/minecraft/world/item/ItemStack;Ljava/util/Random;Lnet/minecraft/world/level/storage/loot/LootContext;)Lnet/minecraft/world/item/ItemStack; - -
 method public b ()[Lcdk; - -
in 59
class cdk 52 public,interface,abstract java/lang/Object - -
 inner net/minecraft/world/level/storage/loot/predicates/LootItemCondition$Serializer cdk Serializer public,static,abstract
 method public,abstract a (Ljava/util/Random;Lnet/minecraft/world/level/storage/loot/LootContext;)Z - -
in 59
class cdr 52 public,super java/lang/Object - -
 inner cds$a cds a public,static,abstract
 inner cdt$a cdt a public,static
 method public,static a (Lcds$a;)V <T::Lcds;>(Lcds$a<+TT;>;)V -
 method public,static a (Lnet/minecraft/resources/ResourceLocation;)Lcds$a; (Lnet/minecraft/resources/ResourceLocation;)Lcds$a<*>; -
 method public,static a (Lcds;)Lcds$a; <T::Lcds;>(TT;)Lcds$a<TT;>; -
in 59
class cds 52 public,interface,abstract java/lang/Object - -
 inner cds$a cds a public,static,abstract
 method public,abstract a (Ljava/util/Random;Lnet/minecraft/world/entity/Entity;)Z - -
in 59
class cds$a 52 public,super,abstract java/lang/Object - <T::Lcds;>Ljava/lang/Object;
 inner cds$a cds a public,static,abstract
 method protected <init> (Lnet/minecraft/resources/ResourceLocation;Ljava/lang/Class;)V (Lnet/minecraft/resources/ResourceLocation;Ljava/lang/Class<TT;>;)V -
 method public a ()Lnet/minecraft/resources/ResourceLocation; - -
 method public b ()Ljava/lang/Class; ()Ljava/lang/Class<TT;>; -
 method public,abstract a (Lcds;Lcom/google/gson/JsonSerializationContext;)Lcom/google/gson/JsonElement; (TT;Lcom/google/gson/JsonSerializationContext;)Lcom/google/gson/JsonElement; -
 method public,abstract a (Lcom/google/gson/JsonElement;Lcom/google/gson/JsonDeserializationContext;)Lcds; (Lcom/google/gson/JsonElement;Lcom/google/gson/JsonDeserializationContext;)TT; -
in 59
class cdt 52 public,super java/lang/Object cds -
 inner cdt$a cdt a public,static
 method public <init> (Z)V - -
 method public a (Ljava/util/Random;Lnet/minecraft/world/entity/Entity;)Z - -
in 59
class cdt$a 52 public,super cds$a - Lcds$a<Lcdt;>;
 inner cdt$a cdt a public,static
 inner cds$a cds a public,static,abstract
 method protected <init> ()V - -
 method public a (Lcdt;Lcom/google/gson/JsonSerializationContext;)Lcom/google/gson/JsonElement; - -
 method public b (Lcom/google/gson/JsonElement;Lcom/google/gson/JsonDeserializationContext;)Lcdt; - -
in 59
class cdw 52 public,super java/lang/Object java/lang/Runnable -
 inner java/lang/Thread$UncaughtExceptionHandler java/lang/Thread UncaughtExceptionHandler public,static,interface,abstract
 method public,static a ()Lcdw; - -
 method public run ()V - -
 method public a (Lcdx;)V - -
 method public b ()V - java/lang/InterruptedException
in 59
class cdx 52 public,interface,abstract java/lang/Object - -
 method public,abstract a ()Z - -
in 59
class ceq 52 public,super it/unimi/dsi/fastutil/doubles/AbstractDoubleList - -
 method public getDouble (I)D - -
 method public size ()I - -
in 59
class cex 52 public,final,super net/minecraft/world/phys/shapes/VoxelShape - -
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method public <init> (Lnet/minecraft/world/phys/shapes/DiscreteVoxelShape;III)V - -
 method protected getCoords (Lnet/minecraft/core/Direction$Axis;)Lit/unimi/dsi/fastutil/doubles/DoubleList; - -
in 59
class cgm 52 public,super,abstract java/lang/Object - -
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 field public,static,final b Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final c Lnet/minecraft/resources/ResourceLocation; -
 field public,static,final d Lnet/minecraft/resources/ResourceLocation; -
 field protected e F -
 method public <init> ()V - -
 method protected a (IIII)V - -
 method protected b (IIII)V - -
 method public,static a (IIIII)V - -
 method protected a (IIIIII)V - -
 method public a (Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V - -
 method public c (Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V - -
 method public b (IIIIII)V - -
 method public a (FFIIII)V - -
 method public a (IILnet/minecraft/client/renderer/texture/TextureAtlasSprite;II)V - -
 method public,static a (IIFFIIFF)V - -
 method public,static a (IIFFIIIIFF)V - -
in 131
class cgu 52 public,super,abstract cgm net/minecraft/client/gui/components/events/GuiEventListener -
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 field protected,static,final a Lnet/minecraft/resources/ResourceLocation; -
 field protected f I -
 field protected g I -
 field public h I -
 field public i I -
 field public j Ljava/lang/String; -
 field public k I -
 field public l Z -
 field public m Z -
 field protected n Z -
 method public <init> (IIILjava/lang/String;)V - -
 method public <init> (IIIIILjava/lang/String;)V - -
 method protected a (Z)I - -
 method public a (IIF)V - -
 method protected a (Lnet/minecraft/client/Minecraft;II)V - -
 method public onClick (DD)V - -
 method public onRelease (DD)V - -
 method protected a (DDDD)V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method protected c (DD)Z - -
 method public a ()Z - -
 method public a (II)V - -
 method public a (Lnet/minecraft/client/sounds/SoundManager;)V - -
 method public getWidth ()I - -
 method public a (I)V - -
in 135
class cgu 52 public,super,abstract cgm net/minecraft/client/gui/components/events/GuiEventListener -
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 field protected,static,final a Lnet/minecraft/resources/ResourceLocation; -
 field public f I -
 field public g I -
 field public h I -
 field public i I -
 field public j Ljava/lang/String; -
 field public k I -
 field public l Z -
 field public m Z -
 field protected n Z -
 field public packedFGColor I -
 method public <init> (IIILjava/lang/String;)V - -
 method public <init> (IIIIILjava/lang/String;)V - -
 method protected a (Z)I - -
 method public a (IIF)V - -
 method protected a (Lnet/minecraft/client/Minecraft;II)V - -
 method public onClick (DD)V - -
 method public onRelease (DD)V - -
 method protected a (DDDD)V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method protected c (DD)Z - -
 method public a ()Z - -
 method public a (II)V - -
 method public a (Lnet/minecraft/client/sounds/SoundManager;)V - -
 method public getWidth ()I - -
 method public a (I)V - -
in 59
class ch 52 public,super java/lang/Object com/mojang/brigadier/arguments/ArgumentType Ljava/lang/Object;Lcom/mojang/brigadier/arguments/ArgumentType<Lnet/minecraft/nbt/CompoundTag;>;
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final a Lcom/mojang/brigadier/exceptions/DynamicCommandExceptionType; -
 method public,static a ()Lch; - -
 method public,static a (Lcom/mojang/brigadier/context/CommandContext;Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; <S:Ljava/lang/Object;>(Lcom/mojang/brigadier/context/CommandContext<TS;>;Ljava/lang/String;)Lnet/minecraft/nbt/CompoundTag; -
 method public a (Lcom/mojang/brigadier/StringReader;)Lnet/minecraft/nbt/CompoundTag; - com/mojang/brigadier/exceptions/CommandSyntaxException
 method public getExamples ()Ljava/util/Collection; ()Ljava/util/Collection<Ljava/lang/String;>; -
in 59
class chb 52 public,super cgm net/minecraft/client/gui/components/events/GuiEventListener -
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 field protected a I -
 field protected f I -
 field public g I -
 field public h I -
 field public j Z -
 method public a (IIF)V - -
 method protected b (IIF)V - -
in 59
class chc 52 public,super,abstract cgu - -
 method public <init> (III)V - -
 method public a (IIF)V - -
in 59
class chg 52 public,super,abstract chl - <E:Lchg$a<TE;>;>Lchl;
 inner chg$b chg b -
 inner chg$a chg a public,static,abstract
 method public <init> (Lnet/minecraft/client/Minecraft;IIIII)V - -
 method protected a (IIDD)Z - -
 method protected a (I)Z - -
 method protected a ()V - -
 method protected a (IIIIIIF)V - -
 method protected a (IIIF)V - -
 method public,final b ()Ljava/util/List; ()Ljava/util/List<TE;>; -
 method protected,final c ()V - -
 method protected,final a (Lchg$a;)V (TE;)V -
 method public b (I)V - -
 method protected,final d ()I - -
in 59
class chg$a 52 public,super,abstract java/lang/Object net/minecraft/client/gui/components/events/GuiEventListener <E:Lchg$a<TE;>;>Ljava/lang/Object;Lnet/minecraft/client/gui/components/events/GuiEventListener;
 inner chg$a chg a public,static,abstract
 field protected a Lchg; Lchg<TE;>;
 field protected b I -
 method public <init> ()V - -
 method protected a ()Lchg; ()Lchg<TE;>; -
 method protected b ()I - -
 method protected c ()I - -
 method protected d ()I - -
 method protected a (F)V - -
 method public,abstract a (IIIIZF)V - -
in 59
class chg$b 52 super java/util/AbstractList - Ljava/util/AbstractList<TE;>;
 inner chg$b chg b -
 inner chg$a chg a public,static,abstract
 method public a (I)Lchg$a; (I)TE; -
 method public size ()I - -
 method public a (ILchg$a;)Lchg$a; (ITE;)TE; -
 method public b (ILchg$a;)V (ITE;)V -
 method public b (I)Lchg$a; (I)TE; -
in 59
class chi 52 public,super chg - Lchg<Lchi$a;>;
 inner chi$a chi a public,final
 inner net/minecraft/client/Options$a net/minecraft/client/Options a public,static,final,enum
 inner chg$a chg a public,static,abstract
 method public,varargs <init> (Lnet/minecraft/client/Minecraft;IIIII[Lnet/minecraft/client/Options$a;)V - -
 method public e ()I - -
 method protected f ()I - -
in 59
class chi$a 52 public,final,super chg$a - Lchg$a<Lchi$a;>;
 inner chi$a chi a public,final
 inner net/minecraft/client/Options$a net/minecraft/client/Options a public,static,final,enum
 inner chg$a chg a public,static,abstract
 method public <init> (Lchi;Lcgu;Lcgu;)V - -
 method public <init> (Lchi;ILnet/minecraft/client/Options$a;)V - -
 method public <init> (Lchi;ILnet/minecraft/client/Options$a;Lnet/minecraft/client/Options$a;)V - -
 method public a (IIIIZF)V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public a (F)V - -
in 131
class chl 52 public,super,abstract chq - -
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final a Lnet/minecraft/client/Minecraft; -
 field protected f I -
 field protected g I -
 field protected h I -
 field protected i I -
 field protected j I -
 field protected k I -
 field protected,final l I -
 field protected m Z -
 field protected n I -
 field protected o D -
 field protected p I -
 field protected q J -
 field protected r Z -
 field protected s Z -
 field protected t Z -
 field protected u I -
 method public <init> (Lnet/minecraft/client/Minecraft;IIIII)V - -
 method public c (IIII)V - -
 method public c (Z)V - -
 method protected a (ZI)V - -
 method public m ()Z - -
 method protected,abstract d ()I - -
 method public b (I)V - -
 method protected b ()Ljava/util/List; ()Ljava/util/List<+Lnet/minecraft/client/gui/components/events/GuiEventListener;>; -
 method protected a (IIDD)Z - -
 method protected,abstract a (I)Z - -
 method protected n ()I - -
 method protected,abstract a ()V - -
 method protected a (IIIF)V - -
 method protected,abstract a (IIIIIIF)V - -
 method protected a (IILcom/mojang/blaze3d/vertex/Tesselator;)V - -
 method protected a (II)V - -
 method protected b (II)V - -
 method public a (DD)I - -
 method protected o ()V - -
 method public p ()I - -
 method public q ()I - -
 method public b (DD)Z - -
 method public e (I)V - -
 method public a (IIF)V - -
 method protected a (DDI)V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public mouseScrolled (D)Z - -
 method public keyPressed (III)Z - -
 method public charTyped (CI)Z - -
 method public e ()I - -
 method protected a (IIIIF)V - -
 method protected f ()I - -
 method protected d (IIII)V - -
 method public f (I)V - -
 method public s ()I - -
in 135
class chl 52 public,super,abstract chq - -
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final a Lnet/minecraft/client/Minecraft; -
 field public f I -
 field public g I -
 field public h I -
 field public i I -
 field public j I -
 field public k I -
 field public,final l I -
 field protected m Z -
 field protected n I -
 field protected o D -
 field protected p I -
 field protected q J -
 field protected r Z -
 field protected s Z -
 field protected t Z -
 field public u I -
 method public <init> (Lnet/minecraft/client/Minecraft;IIIII)V - -
 method public c (IIII)V - -
 method public c (Z)V - -
 method protected a (ZI)V - -
 method public m ()Z - -
 method protected,abstract d ()I - -
 method public b (I)V - -
 method protected b ()Ljava/util/List; ()Ljava/util/List<+Lnet/minecraft/client/gui/components/events/GuiEventListener;>; -
 method protected a (IIDD)Z - -
 method protected,abstract a (I)Z - -
 method protected n ()I - -
 method protected,abstract a ()V - -
 method protected a (IIIF)V - -
 method protected,abstract a (IIIIIIF)V - -
 method protected a (IILcom/mojang/blaze3d/vertex/Tesselator;)V - -
 method protected a (II)V - -
 method protected b (II)V - -
 method public a (DD)I - -
 method protected o ()V - -
 method public p ()I - -
 method public q ()I - -
 method public b (DD)Z - -
 method public e (I)V - -
 method public a (IIF)V - -
 method protected a (DDI)V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public mouseScrolled (D)Z - -
 method public keyPressed (III)Z - -
 method public charTyped (CI)Z - -
 method public e ()I - -
 method protected a (IIIIF)V - -
 method protected f ()I - -
 method protected d (IIII)V - -
 method public f (I)V - -
 method public s ()I - -
 method protected drawContainerBackground (Lcom/mojang/blaze3d/vertex/Tesselator;)V - -
in 59
class chq 52 public,super,abstract cgm chs -
 method public <init> ()V - -
 method protected,abstract b ()Ljava/util/List; ()Ljava/util/List<+Lnet/minecraft/client/gui/components/events/GuiEventListener;>; -
 method protected,final e (Z)V - -
 method public getFocused ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method protected a (Lnet/minecraft/client/gui/components/events/GuiEventListener;)V - -
 method public mouseClicked (DDI)Z - -
 method public keyPressed (III)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public mouseReleased (DDI)Z - -
 method public b (Lnet/minecraft/client/gui/components/events/GuiEventListener;)V - -
 method public t ()V - -
in 59
class chs 52 public,interface,abstract java/lang/Object net/minecraft/client/gui/components/events/GuiEventListener -
 method public,abstract getFocused ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public mouseScrolled (D)Z - -
 method public keyPressed (III)Z - -
 method public keyReleased (III)Z - -
 method public charTyped (CI)Z - -
in 59
class ciy 52 public,super chl - -
 method public <init> (Lnet/minecraft/realms/RealmsClickableScrolledSelectionList;IIIII)V - -
 method protected d ()I - -
 method protected a (IIDD)Z - -
 method protected a (I)Z - -
 method protected a ()V - -
 method protected a (IIIIIIF)V - -
 method public c ()I - -
 method protected n ()I - -
 method protected f ()I - -
 method public mouseScrolled (D)Z - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public a (IIILnet/minecraft/realms/Tezzelator;)V - -
 method protected a (IIIIF)V - -
 method public g ()I - -
 method public h ()I - -
 method public i ()I - -
 method public j ()D - -
 method public k ()I - -
in 59
class ciz 52 public,super net/minecraft/client/gui/screens/Screen - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/realms/RealmsScreen;)V - -
 method public a ()Lnet/minecraft/realms/RealmsScreen; - -
 method public a (Lnet/minecraft/client/Minecraft;II)V - -
 method protected init ()V - -
 method public a (Ljava/lang/String;III)V - -
 method public a (Ljava/lang/String;IIIZ)V - -
 method public b (IIIIII)V - -
 method public a (IIIIII)V - -
 method public d ()V - -
 method public isPauseScreen ()Z - -
 method public c_ (I)V - -
 method public render (IIF)V - -
 method public a (Lnet/minecraft/world/item/ItemStack;II)V - -
 method public a (Ljava/lang/String;II)V - -
 method public a (Ljava/util/List;II)V (Ljava/util/List<Ljava/lang/String;>;II)V -
 method public tick ()V - -
 method public i ()I - -
 method public c (Ljava/lang/String;)I - -
 method public b (Ljava/lang/String;III)V - -
 method public a (Ljava/lang/String;I)Ljava/util/List; (Ljava/lang/String;I)Ljava/util/List<Ljava/lang/String;>; -
 method public j ()V - -
 method public a (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public b (Lnet/minecraft/realms/RealmsGuiEventListener;)V - -
 method public c (Lnet/minecraft/realms/RealmsGuiEventListener;)Z - -
 method public a (Lnet/minecraft/realms/RealmsButton;)V - -
 method public k ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/realms/RealmsButton;>; -
 method public m ()V - -
 method public b (Lnet/minecraft/realms/RealmsButton;)V - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
 method public keyPressed (III)Z - -
 method public charTyped (CI)Z - -
 method public confirmResult (ZI)V - -
 method public removed ()V - -
 method public b (Ljava/lang/String;IIIZ)I - -
in 59
class cja 52 public,super chl - -
 method public <init> (Lnet/minecraft/realms/RealmsScrolledSelectionList;IIIII)V - -
 method protected d ()I - -
 method protected a (IIDD)Z - -
 method protected a (I)Z - -
 method protected a ()V - -
 method protected a (IIIIIIF)V - -
 method public c ()I - -
 method protected n ()I - -
 method protected f ()I - -
 method public mouseScrolled (D)Z - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
in 59
class cjb 52 public,super chl - -
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 method public <init> (Lnet/minecraft/realms/RealmsSimpleScrolledSelectionList;IIIII)V - -
 method protected d ()I - -
 method protected a (IIDD)Z - -
 method protected a (I)Z - -
 method protected a ()V - -
 method protected a (IIIIIIF)V - -
 method public c ()I - -
 method protected n ()I - -
 method protected f ()I - -
 method public a (IIF)V - -
 method public mouseScrolled (D)Z - -
 method public mouseClicked (DDI)Z - -
 method public mouseReleased (DDI)Z - -
 method public mouseDragged (DDIDD)Z - -
in 59
class cji 52 public,interface,abstract java/lang/Object - -
 method public,abstract confirmResult (ZI)V - -
in 59
class cjt 52 public,super net/minecraft/client/gui/screens/Screen - -
 method public <init> (Ljava/lang/String;)V - -
 method public shouldCloseOnEsc ()Z - -
 method public render (IIF)V - -
in 59
class cjw 52 public,super net/minecraft/client/gui/screens/Screen - -
 method public <init> ()V - -
 method protected init ()V - -
 method public removed ()V - -
 method public render (IIF)V - -
in 59
class cjy 52 public,super net/minecraft/client/gui/screens/Screen - -
 method public <init> ()V - -
 method protected init ()V - -
 method public shouldCloseOnEsc ()Z - -
 method public render (IIF)V - -
in 59
class cjz 52 public,super net/minecraft/client/gui/screens/Screen - -
 method public <init> ()V - -
 method protected init ()V - -
 method public tick ()V - -
 method public render (IIF)V - -
in 59
class ckc 52 public,super net/minecraft/client/gui/screens/Screen - -
 method public <init> ()V - -
 method public shouldCloseOnEsc ()Z - -
 method public render (IIF)V - -
 method public isPauseScreen ()Z - -
in 59
class ckg 52 public,super net/minecraft/client/gui/screens/Screen - -
 inner ckg$a ckg a -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 inner net/minecraft/client/Options$a net/minecraft/client/Options a public,static,final,enum
 method public <init> (Lnet/minecraft/client/gui/screens/Screen;Lnet/minecraft/client/Options;)V - -
 method public getFocused ()Lnet/minecraft/client/gui/components/events/GuiEventListener; - -
 method protected init ()V - -
 method public render (IIF)V - -
in 59
class ckg$a 52 super chl - -
 inner ckg$a ckg a -
 method public <init> (Lckg;)V - -
 method protected d ()I - -
 method protected a (I)Z - -
 method protected a ()V - -
 method protected a (IIIIIIF)V - -
 method protected f ()I - -
in 59
class clb 52 public,super net/minecraft/client/gui/screens/Screen - -
 inner clb$a clb a static,abstract
 inner net/minecraft/network/chat/Component$Serializer net/minecraft/network/chat/Component Serializer public,static
 inner net/minecraft/network/chat/ClickEvent$Action net/minecraft/network/chat/ClickEvent Action public,static,final,enum
 method public <init> (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/item/ItemStack;ZLnet/minecraft/world/InteractionHand;)V - -
 method public tick ()V - -
 method protected init ()V - -
 method public removed ()V - -
 method public keyPressed (III)Z - -
 method public charTyped (CI)Z - -
 method public render (IIF)V - -
 method public mouseClicked (DDI)Z - -
 method public d (Lnet/minecraft/network/chat/Component;)Z - -
 method public a (DD)Lnet/minecraft/network/chat/Component; - -
in 59
class clb$a 52 super,abstract cgu - -
 inner clb$a clb a static,abstract
 method public <init> (IIIZ)V - -
 method public a (IIF)V - -
in 59
class cmn 52 public,super net/minecraft/client/gui/screens/recipebook/RecipeBookComponent - -
 method public <init> ()V - -
 method protected updateFiltering ()Z - -
 method public isVisible ()Z - -
 method protected setVisible (Z)V - -
 method protected initFilterButtonTextures ()V - -
 method protected getFilterButtonTooltip ()Ljava/lang/String; - -
 method public slotClicked (Lnet/minecraft/world/inventory/Slot;)V - -
 method public setupGhostRecipe (Lnet/minecraft/world/item/crafting/Recipe;Ljava/util/List;)V (Lnet/minecraft/world/item/crafting/Recipe;Ljava/util/List<Lnet/minecraft/world/inventory/Slot;>;)V -
 method public renderGhostRecipe (IIZF)V - -
in 59
class cmq 52 public,super chg$a - Lchg$a<Lcmq;>;
 inner chg$a chg a public,static,abstract
 inner net/minecraft/server/packs/repository/UnopenedPack$Position net/minecraft/server/packs/repository/UnopenedPack Position public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field protected,final c Lnet/minecraft/client/Minecraft; -
 field protected,final d Lnet/minecraft/client/gui/screens/resourcepacks/ResourcePackSelectScreen; -
 method public <init> (Lnet/minecraft/client/gui/screens/resourcepacks/ResourcePackSelectScreen;Lnet/minecraft/client/resources/UnopenedResourcePack;)V - -
 method public a (Lcmu;)V - -
 method protected e ()V - -
 method protected f ()Lnet/minecraft/server/packs/repository/PackCompatibility; - -
 method protected g ()Ljava/lang/String; - -
 method protected h ()Ljava/lang/String; - -
 method public i ()Lnet/minecraft/client/resources/UnopenedResourcePack; - -
 method public a (IIIIZF)V - -
 method protected j ()Z - -
 method protected k ()Z - -
 method protected m ()Z - -
 method protected n ()Z - -
 method protected o ()Z - -
 method public mouseClicked (DDI)Z - -
 method public p ()Lnet/minecraft/client/gui/screens/resourcepacks/ResourcePackSelectScreen; - -
in 59
class cms 52 public,super net/minecraft/client/gui/screens/resourcepacks/lists/ResourcePackList - -
 method public <init> (Lnet/minecraft/client/Minecraft;II)V - -
 method protected g ()Ljava/lang/String; - -
in 59
class cmu 52 public,super net/minecraft/client/gui/screens/resourcepacks/lists/ResourcePackList - -
 method public <init> (Lnet/minecraft/client/Minecraft;II)V - -
 method protected g ()Ljava/lang/String; - -
in 59
class cnc 52 public,final,super chg$a java/lang/AutoCloseable Lchg$a<Lcnc;>;Ljava/lang/AutoCloseable;
 inner chg$a chg a public,static,abstract
 inner net/minecraft/client/gui/screens/BackupConfirmScreen$Listener net/minecraft/client/gui/screens/BackupConfirmScreen Listener public,static,interface,abstract
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/client/gui/screens/worldselection/WorldSelectionList;Lnet/minecraft/world/level/storage/LevelSummary;Lnet/minecraft/world/level/storage/LevelStorageSource;)V - -
 method public a (IIIIZF)V - -
 method public mouseClicked (DDI)Z - -
 method public e ()V - -
 method public f ()V - -
 method public g ()V - -
 method public h ()V - -
 method public close ()V - -
 method public a (F)V - -
in 59
class cnv 52 public,super net/minecraft/client/model/Model - -
 field protected a Lnet/minecraft/client/model/geom/ModelPart; -
 field protected b Lnet/minecraft/client/model/geom/ModelPart; -
 method public <init> ()V - -
 method protected addEarModels (Lnet/minecraft/client/model/geom/ModelPart;)V - -
 method public render (Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public a (Lnet/minecraft/world/entity/LivingEntity;FFF)V - -
in 59
class cnw 52 public,super net/minecraft/client/model/HumanoidModel - -
 method public <init> ()V - -
 method public <init> (F)V - -
 method protected <init> (FII)V - -
 method public a (FFFFFFLnet/minecraft/world/entity/Entity;)V - -
in 59
class cok 52 public,super cqp - -
 inner net/minecraft/client/model/HumanoidModel$ArmPose net/minecraft/client/model/HumanoidModel ArmPose public,static,final,enum
 method public <init> (FFII)V - -
 method public <init> (FZ)V - -
 method public a (Lnet/minecraft/world/entity/LivingEntity;FFF)V - -
 method public a (FFFFFFLnet/minecraft/world/entity/Entity;)V - -
in 59
class cow 52 public,super net/minecraft/client/model/ChestModel - -
 method public <init> ()V - -
in 59
class cpg 52 public,super net/minecraft/client/model/QuadrupedModel - -
 method public <init> ()V - -
 method public <init> (F)V - -
in 59
class cpi 52 public,super net/minecraft/client/model/QuadrupedModel - -
 method public <init> ()V - -
 method public render (Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public a (FFFFFFLnet/minecraft/world/entity/Entity;)V - -
in 59
class cpx 52 public,super net/minecraft/client/model/Model - -
 field protected a Lnet/minecraft/client/model/geom/ModelPart; -
 method public <init> ()V - -
 method public <init> (IIII)V - -
 method public render (Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public a (FFFFFFLnet/minecraft/world/entity/Entity;)V - -
in 59
class cpy 52 public,super net/minecraft/client/model/HumanoidModel - -
 inner net/minecraft/client/model/HumanoidModel$ArmPose net/minecraft/client/model/HumanoidModel ArmPose public,static,final,enum
 method public <init> ()V - -
 method public <init> (FZ)V - -
 method public a (Lnet/minecraft/world/entity/LivingEntity;FFF)V - -
 method public a (FFFFFFLnet/minecraft/world/entity/Entity;)V - -
 method public translateToHand (FLnet/minecraft/world/entity/HumanoidArm;)V - -
in 59
class cqh 52 public,interface,abstract java/lang/Object - -
 method public,abstract renderSecondPass (Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
in 59
class cql 52 public,super net/minecraft/client/model/HumanoidModel - -
 method public <init> ()V - -
 method public <init> (FFZ)V - -
 method public a (FFFFFFLnet/minecraft/world/entity/Entity;)V - -
in 59
class cqp 52 public,super net/minecraft/client/model/HumanoidModel - -
 method public <init> ()V - -
 method protected <init> (FFII)V - -
 method public <init> (FZ)V - -
 method public a (FFFFFFLnet/minecraft/world/entity/Entity;)V - -
in 59
class cqx 52 public,super java/lang/Object - -
 field public,final a I -
 field public,final b I -
 method public <init> (II)V - -
in 59
class cro 52 public,super net/minecraft/client/particle/Particle - -
 inner cro$a cro a public,static
 method protected <init> (Lnet/minecraft/client/renderer/texture/TextureManager;Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public getLightColor (F)I - -
 method public tick ()V - -
 method public b ()I - -
in 59
class cro$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner cro$a cro a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crp 52 public,super net/minecraft/client/particle/Particle - -
 inner crp$a crp a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDLnet/minecraft/world/level/ItemLike;)V - -
 method public b ()I - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
in 59
class crp$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner crp$a crp a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crq 52 public,super net/minecraft/client/particle/Particle - -
 inner crq$c crq c public,static
 inner crq$b crq b public,static
 inner crq$a crq a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDDLnet/minecraft/world/item/ItemStack;)V - -
 method protected <init> (Lnet/minecraft/world/level/Level;DDDLnet/minecraft/world/item/ItemStack;)V - -
 method public b ()I - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
in 59
class crq$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/ItemParticleOption;>;
 inner crq$a crq a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/ItemParticleOption;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crq$b 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner crq$b crq b public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crq$c 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner crq$c crq c public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crr 52 public,super net/minecraft/client/particle/Particle - -
 inner crr$a crr a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public tick ()V - -
in 59
class crr$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner crr$a crr a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crs 52 public,super net/minecraft/client/particle/Particle - -
 inner crs$a crs a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public tick ()V - -
in 59
class crs$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner crs$a crs a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crt 52 public,super net/minecraft/client/particle/Particle - -
 inner crt$a crt a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public tick ()V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public a (I)V - -
in 59
class crt$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner crt$a crt a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class cru 52 public,super net/minecraft/client/particle/Particle - -
 inner cru$a cru a public,static
 inner cru$b cru b public,static
 inner cru$c cru c public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDDF)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public tick ()V - -
in 59
class cru$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner cru$a cru a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class cru$b 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner cru$b cru b public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class cru$c 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner cru$c cru c public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crx 52 public,super net/minecraft/client/particle/Particle - -
 inner crx$a crx a public,static
 method public <init> (Lnet/minecraft/world/level/Level;DDDDDDLnet/minecraft/core/particles/DustParticleOptions;)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public tick ()V - -
in 59
class crx$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/DustParticleOptions;>;
 inner crx$a crx a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/DustParticleOptions;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class crz 52 public,super net/minecraft/client/particle/SimpleAnimatedParticle - -
 inner crz$a crz a public,static
 method public <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public move (DDD)V - -
in 59
class crz$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner crz$a crz a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csa 52 public,super net/minecraft/client/particle/Particle - -
 inner csa$a csa a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public tick ()V - -
in 59
class csa$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csa$a csa a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csc 52 public,super java/lang/Object - -
 inner csc$b csc b public,static
 inner csc$a csc a public,static
 inner net/minecraft/client/particle/FireworkParticles$SparkParticle csc SparkParticle public,static
 inner net/minecraft/client/particle/FireworkParticles$Starter csc Starter public,static
in 59
class csc$a 52 public,super net/minecraft/client/particle/Particle - -
 inner csc$a csc a public,static
 method public <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
in 59
class csc$b 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csc$b csc b public,static
 inner net/minecraft/client/particle/FireworkParticles$SparkParticle csc SparkParticle public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csd 52 public,super net/minecraft/client/particle/Particle - -
 inner csd$a csd a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public move (DDD)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public getLightColor (F)I - -
 method public tick ()V - -
in 59
class csd$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csd$a csd a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class cse 52 public,super net/minecraft/client/particle/Particle - -
 inner cse$a cse a public,static
 inner cse$b cse b public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDDF)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public tick ()V - -
in 59
class cse$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner cse$a cse a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class cse$b 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner cse$b cse b public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csf 52 public,super net/minecraft/client/particle/Particle - -
 inner csf$a csf a public,static
 method protected <init> (Lnet/minecraft/client/renderer/texture/TextureManager;Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public getLightColor (F)I - -
 method public tick ()V - -
 method public b ()I - -
in 59
class csf$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csf$a csf a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csi 52 public,super css - -
 inner csi$a csi a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
in 59
class csi$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csi$a csi a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csj 52 public,super net/minecraft/client/particle/Particle - -
 inner csj$a csj a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method public getLightColor (F)I - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public tick ()V - -
in 59
class csj$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csj$a csj a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csl 52 public,super net/minecraft/client/particle/Particle - -
 inner csl$a csl a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDDF)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public tick ()V - -
in 59
class csl$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csl$a csl a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csp 52 public,super net/minecraft/client/particle/Particle - -
 inner csp$a csp a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public tick ()V - -
in 59
class csp$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csp$a csp a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class css 52 public,super net/minecraft/client/particle/Particle - -
 inner css$a css a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDDF)V - -
 method public render (Lcom/mojang/blaze3d/vertex/BufferBuilder;Lnet/minecraft/world/entity/Entity;FFFFFF)V - -
 method public tick ()V - -
in 59
class css$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner css$a css a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csu 52 public,super csa - -
 inner csu$a csu a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public tick ()V - -
in 59
class csu$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csu$a csu a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csv 52 public,super cte - -
 inner csv$a csv a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
in 59
class csv$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csv$a csv a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csw 52 public,super net/minecraft/client/particle/SimpleAnimatedParticle - -
 inner csw$a csw a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public tick ()V - -
in 59
class csw$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csw$a csw a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csx 52 public,super net/minecraft/client/particle/Particle - -
 inner csx$a csx a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public tick ()V - -
in 59
class csx$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csx$a csx a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csy 52 public,super net/minecraft/client/particle/Particle - -
 inner csy$a csy a public,static
 inner csy$b csy b public,static
 inner csy$c csy c public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public move (DDD)V - -
 method public tick ()V - -
in 59
class csy$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csy$a csy a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csy$b 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csy$b csy b public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class csy$c 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner csy$c csy c public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class cta 52 public,super net/minecraft/client/particle/SimpleAnimatedParticle - -
 inner cta$a cta a public,static
 method public <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
in 59
class cta$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner cta$a cta a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class ctc 52 public,super net/minecraft/client/particle/Particle - -
 inner ctc$a ctc a public,static
 method protected <init> (Lnet/minecraft/world/level/Level;DDDDDD)V - -
 method public tick ()V - -
in 59
class ctc$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner ctc$a ctc a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class cte 52 public,super net/minecraft/client/particle/Particle - -
 inner cte$a cte a public,static
 inner net/minecraft/core/Direction$Axis net/minecraft/core/Direction Axis public,static,abstract,enum
 method protected <init> (Lnet/minecraft/world/level/Level;DDD)V - -
 method public tick ()V - -
in 59
class cte$a 52 public,super java/lang/Object net/minecraft/client/particle/ParticleProvider Ljava/lang/Object;Lnet/minecraft/client/particle/ParticleProvider<Lnet/minecraft/core/particles/SimpleParticleType;>;
 inner cte$a cte a public,static
 method public <init> ()V - -
 method public createParticle (Lnet/minecraft/core/particles/SimpleParticleType;Lnet/minecraft/world/level/Level;DDDDDD)Lnet/minecraft/client/particle/Particle; - -
in 59
class ctk 52 public,super net/minecraft/client/player/AbstractClientPlayer - -
 method public <init> (Lnet/minecraft/world/level/Level;Lcom/mojang/authlib/GameProfile;)V - -
 method public shouldRenderAtSqrDistance (D)Z - -
 method public hurt (Lnet/minecraft/world/damagesource/DamageSource;F)Z - -
 method public tick ()V - -
 method public aiStep ()V - -
 method public sendMessage (Lnet/minecraft/network/chat/Component;)V - -
in 59
class ctm 52 public,super java/lang/Object adl -
 method public <init> (Ljava/lang/String;Lnet/minecraft/network/chat/Component;)V - -
 method public a (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/inventory/AbstractContainerMenu; - -
 method public getName ()Lnet/minecraft/network/chat/Component; - -
 method public hasCustomName ()Z - -
 method public l ()Ljava/lang/String; - -
 method public getCustomName ()Lnet/minecraft/network/chat/Component; - -
in 59
class ctn 52 public,super net/minecraft/world/SimpleContainer adq -
 method public <init> (Ljava/lang/String;Lnet/minecraft/network/chat/Component;I)V - -
 method public c (I)I - -
 method public b (II)V - -
 method public h ()I - -
 method public V_ ()Z - -
 method public a (Lnet/minecraft/world/LockCode;)V - -
 method public j ()Lnet/minecraft/world/LockCode; - -
 method public l ()Ljava/lang/String; - -
 method public a (Lnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/inventory/AbstractContainerMenu; - -
in 59
class cwu 52 public,interface,abstract java/lang/Object - -
 method public,abstract create (Lnet/minecraft/world/level/Level;Lnet/minecraft/client/renderer/LevelRenderer;)Lnet/minecraft/client/renderer/chunk/RenderChunk; - -
in 59
class cxs 52 public,super net/minecraft/client/renderer/entity/EntityRenderer - Lnet/minecraft/client/renderer/entity/EntityRenderer<Lnet/minecraft/world/entity/AreaEffectCloud;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/AreaEffectCloud;)Lnet/minecraft/resources/ResourceLocation; - -
in 59
class cxu 52 public,super,abstract net/minecraft/client/renderer/entity/EntityRenderer - <T:Lnet/minecraft/world/entity/projectile/AbstractArrow;>Lnet/minecraft/client/renderer/entity/EntityRenderer<TT;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public render (Lnet/minecraft/world/entity/projectile/AbstractArrow;DDDFF)V (TT;DDDFF)V -
in 59
class cye 52 public,super net/minecraft/client/renderer/entity/EntityRenderer - Lnet/minecraft/client/renderer/entity/EntityRenderer<Lnet/minecraft/world/entity/Entity;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public render (Lnet/minecraft/world/entity/Entity;DDDFF)V - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/Entity;)Lnet/minecraft/resources/ResourceLocation; - -
in 59
class cyt 52 public,super net/minecraft/client/renderer/entity/EntityRenderer - Lnet/minecraft/client/renderer/entity/EntityRenderer<Lnet/minecraft/world/entity/item/FallingBlockEntity;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public render (Lnet/minecraft/world/entity/item/FallingBlockEntity;DDDFF)V - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/item/FallingBlockEntity;)Lnet/minecraft/resources/ResourceLocation; - -
in 59
class cyu 52 public,super net/minecraft/client/renderer/entity/EntityRenderer - Lnet/minecraft/client/renderer/entity/EntityRenderer<Lnet/minecraft/world/entity/projectile/AbstractHurtingProjectile;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;F)V - -
 method public render (Lnet/minecraft/world/entity/projectile/AbstractHurtingProjectile;DDDFF)V - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/projectile/AbstractHurtingProjectile;)Lnet/minecraft/resources/ResourceLocation; - -
in 59
class cyv 52 public,super net/minecraft/client/renderer/entity/EntityRenderer - Lnet/minecraft/client/renderer/entity/EntityRenderer<Lnet/minecraft/world/entity/fishing/FishingHook;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public render (Lnet/minecraft/world/entity/fishing/FishingHook;DDDFF)V - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/fishing/FishingHook;)Lnet/minecraft/resources/ResourceLocation; - -
in 59
class czj 52 public,super net/minecraft/client/renderer/entity/EntityRenderer - Lnet/minecraft/client/renderer/entity/EntityRenderer<Lnet/minecraft/world/entity/global/LightningBolt;>;
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public render (Lnet/minecraft/world/entity/global/LightningBolt;DDDFF)V - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/global/LightningBolt;)Lnet/minecraft/resources/ResourceLocation; - -
in 59
class czo 52 public,super net/minecraft/client/renderer/entity/MinecartRenderer - Lnet/minecraft/client/renderer/entity/MinecartRenderer<Lnet/minecraft/world/entity/vehicle/MinecartSpawner;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
in 59
class czq 52 public,super net/minecraft/client/renderer/entity/MobRenderer - Lnet/minecraft/client/renderer/entity/MobRenderer<Lajx;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public c ()Lnet/minecraft/client/model/CowModel; - -
 method protected getTextureLocation (Lajx;)Lnet/minecraft/resources/ResourceLocation; - -
in 59
class dan 52 public,super net/minecraft/client/renderer/entity/ThrownItemRenderer - Lnet/minecraft/client/renderer/entity/ThrownItemRenderer<Lnet/minecraft/world/entity/projectile/ThrownPotion;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;Lnet/minecraft/client/renderer/entity/ItemRenderer;)V - -
 method public a (Lnet/minecraft/world/entity/projectile/ThrownPotion;)Lnet/minecraft/world/item/ItemStack; - -
in 59
class daq 52 public,super net/minecraft/client/renderer/entity/MinecartRenderer - Lnet/minecraft/client/renderer/entity/MinecartRenderer<Lnet/minecraft/world/entity/vehicle/MinecartTNT;>;
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method protected renderMinecartContents (Lnet/minecraft/world/entity/vehicle/MinecartTNT;FLnet/minecraft/world/level/block/state/BlockState;)V - -
in 59
class dar 52 public,super net/minecraft/client/renderer/entity/EntityRenderer - Lnet/minecraft/client/renderer/entity/EntityRenderer<Lnet/minecraft/world/entity/item/PrimedTnt;>;
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public render (Lnet/minecraft/world/entity/item/PrimedTnt;DDDFF)V - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/item/PrimedTnt;)Lnet/minecraft/resources/ResourceLocation; - -
in 131
class daw 52 public,super net/minecraft/client/renderer/entity/MobRenderer - Lnet/minecraft/client/renderer/entity/MobRenderer<Lnet/minecraft/world/entity/npc/Villager;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public c ()Lnet/minecraft/client/model/VillagerModel; - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/npc/Villager;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected scale (Lnet/minecraft/world/entity/npc/Villager;F)V - -
in 135
class daw 52 public,super net/minecraft/client/renderer/entity/MobRenderer - Lnet/minecraft/client/renderer/entity/MobRenderer<Lnet/minecraft/world/entity/npc/Villager;>;
 inner net/minecraftforge/fml/common/registry/VillagerRegistry$VillagerProfession net/minecraftforge/fml/common/registry/VillagerRegistry VillagerProfession public,static
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public c ()Lnet/minecraft/client/model/VillagerModel; - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/npc/Villager;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected scale (Lnet/minecraft/world/entity/npc/Villager;F)V - -
in 59
class dbd 52 public,super net/minecraft/client/renderer/entity/HumanoidMobRenderer - Lnet/minecraft/client/renderer/entity/HumanoidMobRenderer<Lnet/minecraft/world/entity/monster/Zombie;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;Lnet/minecraft/client/model/HumanoidModel;)V - -
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method protected c ()Ldbt; - -
 method protected getTextureLocation (Lnet/minecraft/world/entity/monster/Zombie;)Lnet/minecraft/resources/ResourceLocation; - -
 method protected setupRotations (Lnet/minecraft/world/entity/monster/Zombie;FFF)V - -
in 59
class dbg 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/world/entity/LivingEntity;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;)V (Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<*>;)V -
 method public a (Lnet/minecraft/world/entity/LivingEntity;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dbh 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/client/player/AbstractClientPlayer;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/player/PlayerRenderer;)V - -
 method public a (Lnet/minecraft/client/player/AbstractClientPlayer;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dbi 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/world/entity/monster/EnderMan;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EndermanRenderer;)V - -
 method public a (Lnet/minecraft/world/entity/monster/EnderMan;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dbk 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/world/entity/LivingEntity;>;
 inner net/minecraft/world/level/block/SkullBlock$a net/minecraft/world/level/block/SkullBlock a public,static,interface,abstract
 inner net/minecraft/client/renderer/block/model/ItemTransforms$TransformType net/minecraft/client/renderer/block/model/ItemTransforms TransformType public,static,final,enum
 method public <init> (Lnet/minecraft/client/model/geom/ModelPart;)V - -
 method public a (Lnet/minecraft/world/entity/LivingEntity;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dbl 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/client/player/AbstractClientPlayer;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/player/PlayerRenderer;)V - -
 method public a (Lnet/minecraft/client/player/AbstractClientPlayer;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dbp 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/world/entity/boss/enderdragon/EnderDragon;>;
 inner com/mojang/blaze3d/platform/GlStateManager$SourceFactor com/mojang/blaze3d/platform/GlStateManager SourceFactor public,static,final,enum
 inner com/mojang/blaze3d/platform/GlStateManager$l com/mojang/blaze3d/platform/GlStateManager l public,static,final,enum
 method public <init> ()V - -
 method public a (Lnet/minecraft/world/entity/boss/enderdragon/EnderDragon;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dbs 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/world/entity/player/Player;>;
 inner dbs$a dbs a -
 field protected a Lnet/minecraft/client/renderer/entity/LivingEntityRenderer; Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<+Lnet/minecraft/world/entity/LivingEntity;>;
 field protected b Lnet/minecraft/client/renderer/entity/LivingEntityRenderer; Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<+Lnet/minecraft/world/entity/LivingEntity;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/EntityRenderDispatcher;)V - -
 method public a (Lnet/minecraft/world/entity/player/Player;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dbs$a 52 super java/lang/Object - -
 inner dbs$a dbs a -
 field public a Ljava/util/UUID; -
 field public b Lnet/minecraft/client/renderer/entity/LivingEntityRenderer; Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<+Lnet/minecraft/world/entity/LivingEntity;>;
 field public c Lnet/minecraft/client/model/Model; -
 field public d Lnet/minecraft/resources/ResourceLocation; -
 field public e Lnet/minecraft/world/entity/EntityType; Lnet/minecraft/world/entity/EntityType<*>;
 method public <init> (Ldbs;Ljava/util/UUID;Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;Lnet/minecraft/client/model/Model;Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/world/entity/EntityType;)V (Ljava/util/UUID;Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<+Lnet/minecraft/world/entity/LivingEntity;>;Lnet/minecraft/client/model/Model;Lnet/minecraft/resources/ResourceLocation;Lnet/minecraft/world/entity/EntityType<*>;)V -
in 131
class dbt 52 public,super net/minecraft/client/renderer/entity/layers/AbstractArmorLayer - Lnet/minecraft/client/renderer/entity/layers/AbstractArmorLayer<Lnet/minecraft/client/model/HumanoidModel;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;)V (Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<*>;)V -
 method protected am_ ()V - -
 method protected setPartVisibility (Lnet/minecraft/client/model/HumanoidModel;Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method protected hideAllArmor (Lnet/minecraft/client/model/HumanoidModel;)V - -
in 135
class dbt 52 public,super net/minecraft/client/renderer/entity/layers/AbstractArmorLayer - Lnet/minecraft/client/renderer/entity/layers/AbstractArmorLayer<Lnet/minecraft/client/model/HumanoidModel;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;)V (Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<*>;)V -
 method protected am_ ()V - -
 method protected setPartVisibility (Lnet/minecraft/client/model/HumanoidModel;Lnet/minecraft/world/entity/EquipmentSlot;)V - -
 method protected hideAllArmor (Lnet/minecraft/client/model/HumanoidModel;)V - -
 method protected getArmorModelHook (Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/entity/EquipmentSlot;Lnet/minecraft/client/model/HumanoidModel;)Lnet/minecraft/client/model/HumanoidModel; - -
in 59
class dbu 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/world/entity/animal/IronGolem;>;
 method public <init> (Lnet/minecraft/client/renderer/entity/IronGolemRenderer;)V - -
 method public a (Lnet/minecraft/world/entity/animal/IronGolem;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dbx 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lajx;>;
 inner com/mojang/blaze3d/platform/GlStateManager$CullFace com/mojang/blaze3d/platform/GlStateManager CullFace public,static,final,enum
 method public <init> (Lczq;)V - -
 method public a (Lajx;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dcd 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/world/entity/animal/SnowGolem;>;
 inner net/minecraft/client/renderer/block/model/ItemTransforms$TransformType net/minecraft/client/renderer/block/model/ItemTransforms TransformType public,static,final,enum
 method public <init> (Lnet/minecraft/client/renderer/entity/SnowGolemRenderer;)V - -
 method public a (Lnet/minecraft/world/entity/animal/SnowGolem;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dci 52 public,super dbt - -
 method public <init> (Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;)V (Lnet/minecraft/client/renderer/entity/LivingEntityRenderer<*>;)V -
 method protected am_ ()V - -
in 59
class dcj 52 public,super java/lang/Object net/minecraft/client/renderer/entity/layers/RenderLayer Ljava/lang/Object;Lnet/minecraft/client/renderer/entity/layers/RenderLayer<Lnet/minecraft/world/entity/monster/Witch;>;
 inner net/minecraft/client/renderer/block/model/ItemTransforms$TransformType net/minecraft/client/renderer/block/model/ItemTransforms TransformType public,static,final,enum
 method public <init> (Lnet/minecraft/client/renderer/entity/WitchRenderer;)V - -
 method public a (Lnet/minecraft/world/entity/monster/Witch;FFFFFFF)V - -
 method public colorsOnDamage ()Z - -
in 59
class dcs 52 public,super java/lang/Object java/lang/AutoCloseable -
 inner com/mojang/blaze3d/shaders/Program$Type com/mojang/blaze3d/shaders/Program Type public,static,final,enum
 method public <init> (Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/lang/String;)V - java/io/IOException
 method public close ()V - -
 method public a ()V - -
 method public b ()V - -
 method public markDirty ()V - -
 method public a (Ljava/lang/String;)Lcom/mojang/blaze3d/shaders/Uniform; - -
 method public b (Ljava/lang/String;)Lcom/mojang/blaze3d/shaders/AbstractUniform; - -
 method public a (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getVertexProgram ()Lcom/mojang/blaze3d/shaders/Program; - -
 method public getFragmentProgram ()Lcom/mojang/blaze3d/shaders/Program; - -
 method public getId ()I - -
in 131
class ddp 52 public,super java/lang/Object - -
 inner com/mojang/blaze3d/platform/NativeImage$InternalGlFormat com/mojang/blaze3d/platform/NativeImage InternalGlFormat public,static,final,enum
 method public,static a ()I - -
 method public,static a (I)V - -
 method public,static a (III)V - -
 method public,static a (Lcom/mojang/blaze3d/platform/NativeImage$InternalGlFormat;III)V - -
 method public,static a (IIII)V - -
 method public,static a (Lcom/mojang/blaze3d/platform/NativeImage$InternalGlFormat;IIII)V - -
 method public,static a (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/resources/ResourceLocation;)[I - java/io/IOException
 method public,static a (Ljava/io/InputStream;)Ljava/nio/ByteBuffer; - java/io/IOException
in 135
class ddp 52 public,super java/lang/Object - -
 inner com/mojang/blaze3d/platform/NativeImage$InternalGlFormat com/mojang/blaze3d/platform/NativeImage InternalGlFormat public,static,final,enum
 method public <init> ()V - -
 method public,static a ()I - -
 method public,static a (I)V - -
 method public,static a (III)V - -
 method public,static a (Lcom/mojang/blaze3d/platform/NativeImage$InternalGlFormat;III)V - -
 method public,static a (IIII)V - -
 method public,static a (Lcom/mojang/blaze3d/platform/NativeImage$InternalGlFormat;IIII)V - -
 method public,static,deprecated a (Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/resources/ResourceLocation;)[I - java/io/IOException
 method public,static a (Ljava/io/InputStream;)Ljava/nio/ByteBuffer; - java/io/IOException
in 59
class dgo 52 public,super paulscode/sound/Channel - -
 field public a Ljava/nio/IntBuffer; -
 field public b I -
 field public c I -
 field public d F -
 method public <init> (ILjava/nio/IntBuffer;)V - -
 method public cleanup ()V - -
 method public a (Ljava/nio/IntBuffer;)Z - -
 method public setAudioFormat (Ljavax/sound/sampled/AudioFormat;)V - -
 method public a (II)V - -
 method public preLoadBuffers (Ljava/util/LinkedList;)Z (Ljava/util/LinkedList<[B>;)Z -
 method public queueBuffer ([B)Z - -
 method public feedRawAudioData ([B)I - -
 method public a (I)F - -
 method public millisecondsPlayed ()F - -
 method public buffersProcessed ()I - -
 method public flush ()V - -
 method public close ()V - -
 method public play ()V - -
 method public pause ()V - -
 method public stop ()V - -
 method public rewind ()V - -
 method public playing ()Z - -
in 59
class dgp 52 public,super paulscode/sound/Library - -
 inner dgp$a dgp a public,static
 method public <init> ()V - paulscode/sound/SoundSystemException
 method public init ()V - paulscode/sound/SoundSystemException
 method protected createChannel (I)Lpaulscode/sound/Channel; - -
 method public cleanup ()V - -
 method public loadSound (Lpaulscode/sound/FilenameURL;)Z - -
 method public loadSound (Lpaulscode/sound/SoundBuffer;Ljava/lang/String;)Z - -
 method public unloadSound (Ljava/lang/String;)V - -
 method public setMasterVolume (F)V - -
 method public newSource (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;FFFIF)V - -
 method public rawDataStream (Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public quickPlay (ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;FFFIFZ)V - -
 method public copySources (Ljava/util/HashMap;)V (Ljava/util/HashMap<Ljava/lang/String;Lpaulscode/sound/Source;>;)V -
 method public setListenerPosition (FFF)V - -
 method public setListenerAngle (F)V - -
 method public setListenerOrientation (FFFFFF)V - -
 method public setListenerData (Lpaulscode/sound/ListenerData;)V - -
 method public setListenerVelocity (FFF)V - -
 method public dopplerChanged ()V - -
 method public,static a ()Z - -
 method public getClassName ()Ljava/lang/String; - -
in 59
class dgp$a 52 public,super paulscode/sound/SoundSystemException - -
 inner dgp$a dgp a public,static
 method public <init> (Ljava/lang/String;)V - -
 method public <init> (Ljava/lang/String;I)V - -
in 59
class dgu 52 public,super paulscode/sound/Source - -
 method public <init> (Ljava/nio/FloatBuffer;Ljava/nio/IntBuffer;ZZZLjava/lang/String;Lpaulscode/sound/FilenameURL;Lpaulscode/sound/SoundBuffer;FFFIFZ)V - -
 method public <init> (Ljava/nio/FloatBuffer;Ljava/nio/IntBuffer;Lpaulscode/sound/Source;Lpaulscode/sound/SoundBuffer;)V - -
 method public <init> (Ljava/nio/FloatBuffer;Ljavax/sound/sampled/AudioFormat;ZLjava/lang/String;FFFIF)V - -
 method public incrementSoundSequence ()Z - -
 method public listenerMoved ()V - -
 method public setPosition (FFF)V - -
 method public positionChanged ()V - -
 method public setLooping (Z)V - -
 method public setAttenuation (I)V - -
 method public setDistOrRoll (F)V - -
 method public setVelocity (FFF)V - -
 method public setPitch (F)V - -
 method public play (Lpaulscode/sound/Channel;)V - -
 method public preLoad ()Z - -
in 59
class ed 52 public,super java/lang/Object net/minecraft/commands/synchronization/ArgumentSerializer Ljava/lang/Object;Lnet/minecraft/commands/synchronization/ArgumentSerializer<Lcom/mojang/brigadier/arguments/DoubleArgumentType;>;
 method public <init> ()V - -
 method public serializeToNetwork (Lcom/mojang/brigadier/arguments/DoubleArgumentType;Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public deserializeFromNetwork (Lnet/minecraft/network/FriendlyByteBuf;)Lcom/mojang/brigadier/arguments/DoubleArgumentType; - -
 method public serializeToJson (Lcom/mojang/brigadier/arguments/DoubleArgumentType;Lcom/google/gson/JsonObject;)V - -
in 59
class ee 52 public,super java/lang/Object net/minecraft/commands/synchronization/ArgumentSerializer Ljava/lang/Object;Lnet/minecraft/commands/synchronization/ArgumentSerializer<Lcom/mojang/brigadier/arguments/FloatArgumentType;>;
 method public <init> ()V - -
 method public serializeToNetwork (Lcom/mojang/brigadier/arguments/FloatArgumentType;Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public deserializeFromNetwork (Lnet/minecraft/network/FriendlyByteBuf;)Lcom/mojang/brigadier/arguments/FloatArgumentType; - -
 method public serializeToJson (Lcom/mojang/brigadier/arguments/FloatArgumentType;Lcom/google/gson/JsonObject;)V - -
in 59
class ef 52 public,super java/lang/Object net/minecraft/commands/synchronization/ArgumentSerializer Ljava/lang/Object;Lnet/minecraft/commands/synchronization/ArgumentSerializer<Lcom/mojang/brigadier/arguments/IntegerArgumentType;>;
 method public <init> ()V - -
 method public serializeToNetwork (Lcom/mojang/brigadier/arguments/IntegerArgumentType;Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public deserializeFromNetwork (Lnet/minecraft/network/FriendlyByteBuf;)Lcom/mojang/brigadier/arguments/IntegerArgumentType; - -
 method public serializeToJson (Lcom/mojang/brigadier/arguments/IntegerArgumentType;Lcom/google/gson/JsonObject;)V - -
in 59
class eg 52 public,super java/lang/Object net/minecraft/commands/synchronization/ArgumentSerializer Ljava/lang/Object;Lnet/minecraft/commands/synchronization/ArgumentSerializer<Lcom/mojang/brigadier/arguments/StringArgumentType;>;
 inner com/mojang/brigadier/arguments/StringArgumentType$StringType com/mojang/brigadier/arguments/StringArgumentType StringType public,static,final,enum
 method public <init> ()V - -
 method public serializeToNetwork (Lcom/mojang/brigadier/arguments/StringArgumentType;Lnet/minecraft/network/FriendlyByteBuf;)V - -
 method public deserializeFromNetwork (Lnet/minecraft/network/FriendlyByteBuf;)Lcom/mojang/brigadier/arguments/StringArgumentType; - -
 method public serializeToJson (Lcom/mojang/brigadier/arguments/StringArgumentType;Lcom/google/gson/JsonObject;)V - -
in 59
class es 52 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final NOOP Les; -
 method public,abstract dispense (Lnet/minecraft/core/BlockSource;Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/ItemStack; - -
in 59
class gb 52 public,super java/lang/Object net/minecraft/data/DataProvider -
 method public <init> (Lnet/minecraft/data/DataGenerator;)V - -
 method public run (Lnet/minecraft/data/HashCache;)V - java/io/IOException
 method public getName ()Ljava/lang/String; - -
in 59
class gi 52 public,super java/lang/Object - -
 inner gi$a gi a public,static
 inner net/minecraft/advancements/Advancement$Builder net/minecraft/advancements/Advancement Builder public,static
 inner net/minecraft/advancements/critereon/RecipeUnlockedTrigger$TriggerInstance net/minecraft/advancements/critereon/RecipeUnlockedTrigger TriggerInstance public,static
 inner net/minecraft/advancements/AdvancementRewards$Builder net/minecraft/advancements/AdvancementRewards Builder public,static
 method public <init> (Lnet/minecraft/world/item/crafting/Ingredient;Lnet/minecraft/world/level/ItemLike;FI)V - -
 method public,static a (Lnet/minecraft/world/item/crafting/Ingredient;Lnet/minecraft/world/level/ItemLike;FI)Lgi; - -
 method public a (Ljava/lang/String;Lnet/minecraft/advancements/CriterionTriggerInstance;)Lgi; - -
 method public a (Ljava/util/function/Consumer;)V (Ljava/util/function/Consumer<Lnet/minecraft/data/recipes/FinishedRecipe;>;)V -
 method public a (Ljava/util/function/Consumer;Ljava/lang/String;)V (Ljava/util/function/Consumer<Lnet/minecraft/data/recipes/FinishedRecipe;>;Ljava/lang/String;)V -
 method public a (Ljava/util/function/Consumer;Lnet/minecraft/resources/ResourceLocation;)V (Ljava/util/function/Consumer<Lnet/minecraft/data/recipes/FinishedRecipe;>;Lnet/minecraft/resources/ResourceLocation;)V -
in 59
class gi$a 52 public,super java/lang/Object net/minecraft/data/recipes/FinishedRecipe -
 inner net/minecraft/advancements/Advancement$Builder net/minecraft/advancements/Advancement Builder public,static
 inner gi$a gi a public,static
 method public <init> (Lnet/minecraft/resources/ResourceLocation;Ljava/lang/String;Lnet/minecraft/world/item/crafting/Ingredient;Lnet/minecraft/world/item/Item;FILnet/minecraft/advancements/Advancement$Builder;Lnet/minecraft/resources/ResourceLocation;)V - -
 method public serializeRecipe ()Lcom/google/gson/JsonObject; - -
 method public getId ()Lnet/minecraft/resources/ResourceLocation; - -
 method public serializeAdvancement ()Lcom/google/gson/JsonObject; - -
 method public getAdvancementId ()Lnet/minecraft/resources/ResourceLocation; - -
in 59
class gx 52 public,super,abstract java/util/AbstractList net/minecraft/nbt/Tag <T::Lnet/minecraft/nbt/Tag;>Ljava/util/AbstractList<TT;>;Lnet/minecraft/nbt/Tag;
 method public <init> ()V - -
 method public,abstract size ()I - -
 method public d (I)Lnet/minecraft/nbt/Tag; (I)TT; -
 method public b (ILnet/minecraft/nbt/Tag;)Lnet/minecraft/nbt/Tag; (ITT;)TT; -
 method public,abstract c (I)Lnet/minecraft/nbt/Tag; (I)TT; -
 method public,abstract a (ILnet/minecraft/nbt/Tag;)V - -
 method public,abstract b (I)V - -
in 59
class ha 52 public,super java/lang/Object net/minecraft/nbt/Tag -
 method public <init> ()V - -
 method public load (Ljava/io/DataInput;ILnet/minecraft/nbt/NbtAccounter;)V - java/io/IOException
 method public write (Ljava/io/DataOutput;)V - java/io/IOException
 method public getId ()B - -
 method public toString ()Ljava/lang/String; - -
 method public copy ()Lha; - -
 method public getPrettyDisplay (Ljava/lang/String;I)Lnet/minecraft/network/chat/Component; - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
in 59
class hl 52 public,super,abstract java/lang/Object net/minecraft/nbt/Tag -
 method protected <init> ()V - -
 method public,abstract getAsLong ()J - -
 method public,abstract getAsInt ()I - -
 method public,abstract getAsShort ()S - -
 method public,abstract getAsByte ()B - -
 method public,abstract getAsDouble ()D - -
 method public,abstract getAsFloat ()F - -
 method public,abstract getAsNumber ()Ljava/lang/Number; - -
in 196
class hp 52 public,super java/lang/Object net/minecraft/data/DataProvider -
 inner hp$a hp a static
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Lnet/minecraft/data/DataGenerator;)V - -
 method public run (Lnet/minecraft/data/HashCache;)V - java/io/IOException
 method public getName ()Ljava/lang/String; - -
in 196
class hp$a 52 super java/lang/RuntimeException - -
 inner hp$a hp a static
 method public <init> (Ljava/nio/file/Path;Ljava/lang/Throwable;)V - -
in 59
class is 52 public,super java/lang/IllegalArgumentException - -
 method public <init> (Lnet/minecraft/network/chat/TranslatableComponent;Ljava/lang/String;)V - -
 method public <init> (Lnet/minecraft/network/chat/TranslatableComponent;I)V - -
 method public <init> (Lnet/minecraft/network/chat/TranslatableComponent;Ljava/lang/Throwable;)V - -
in 59
class iv 52 public,interface,abstract java/lang/Object - <T::Lnet/minecraft/network/PacketListener;>Ljava/lang/Object;
 method public,abstract read (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public,abstract write (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public,abstract handle (Lnet/minecraft/network/PacketListener;)V (TT;)V -
 method public isSkippable ()Z - -
in 59
class iy 52 public,interface,abstract java/lang/Object net/minecraft/network/PacketListener -
 method public,abstract handleAddEntity (Lnet/minecraft/network/protocol/game/ClientboundAddEntityPacket;)V - -
 method public,abstract handleAddExperienceOrb (Lnet/minecraft/network/protocol/game/ClientboundAddExperienceOrbPacket;)V - -
 method public,abstract handleAddGlobalEntity (Lnet/minecraft/network/protocol/game/ClientboundAddGlobalEntityPacket;)V - -
 method public,abstract handleAddMob (Lnet/minecraft/network/protocol/game/ClientboundAddMobPacket;)V - -
 method public,abstract handleAddObjective (Lnet/minecraft/network/protocol/game/ClientboundSetObjectivePacket;)V - -
 method public,abstract handleAddPainting (Lnet/minecraft/network/protocol/game/ClientboundAddPaintingPacket;)V - -
 method public,abstract handleAddPlayer (Lnet/minecraft/network/protocol/game/ClientboundAddPlayerPacket;)V - -
 method public,abstract handleAnimate (Lnet/minecraft/network/protocol/game/ClientboundAnimatePacket;)V - -
 method public,abstract handleAwardStats (Lnet/minecraft/network/protocol/game/ClientboundAwardStatsPacket;)V - -
 method public,abstract handleAddOrRemoveRecipes (Lnet/minecraft/network/protocol/game/ClientboundRecipePacket;)V - -
 method public,abstract handleBlockDestruction (Lnet/minecraft/network/protocol/game/ClientboundBlockDestructionPacket;)V - -
 method public,abstract handleOpenSignEditor (Lnet/minecraft/network/protocol/game/ClientboundOpenSignEditorPacket;)V - -
 method public,abstract handleBlockEntityData (Lnet/minecraft/network/protocol/game/ClientboundBlockEntityDataPacket;)V - -
 method public,abstract handleBlockEvent (Lnet/minecraft/network/protocol/game/ClientboundBlockEventPacket;)V - -
 method public,abstract handleBlockUpdate (Lnet/minecraft/network/protocol/game/ClientboundBlockUpdatePacket;)V - -
 method public,abstract handleChat (Lnet/minecraft/network/protocol/game/ClientboundChatPacket;)V - -
 method public,abstract handleChunkBlocksUpdate (Lnet/minecraft/network/protocol/game/ClientboundChunkBlocksUpdatePacket;)V - -
 method public,abstract handleMapItemData (Lnet/minecraft/network/protocol/game/ClientboundMapItemDataPacket;)V - -
 method public,abstract handleContainerAck (Lnet/minecraft/network/protocol/game/ClientboundContainerAckPacket;)V - -
 method public,abstract handleContainerClose (Lnet/minecraft/network/protocol/game/ClientboundContainerClosePacket;)V - -
 method public,abstract handleContainerContent (Lnet/minecraft/network/protocol/game/ClientboundContainerSetContentPacket;)V - -
 method public,abstract a (Ljt;)V - -
 method public,abstract handleContainerSetData (Lnet/minecraft/network/protocol/game/ClientboundContainerSetDataPacket;)V - -
 method public,abstract handleContainerSetSlot (Lnet/minecraft/network/protocol/game/ClientboundContainerSetSlotPacket;)V - -
 method public,abstract handleCustomPayload (Lnet/minecraft/network/protocol/game/ClientboundCustomPayloadPacket;)V - -
 method public,abstract handleDisconnect (Lnet/minecraft/network/protocol/game/ClientboundDisconnectPacket;)V - -
 method public,abstract a (Lku;)V - -
 method public,abstract handleEntityEvent (Lnet/minecraft/network/protocol/game/ClientboundEntityEventPacket;)V - -
 method public,abstract handleEntityLinkPacket (Lnet/minecraft/network/protocol/game/ClientboundSetEntityLinkPacket;)V - -
 method public,abstract handleSetEntityPassengersPacket (Lnet/minecraft/network/protocol/game/ClientboundSetPassengersPacket;)V - -
 method public,abstract handleExplosion (Lnet/minecraft/network/protocol/game/ClientboundExplodePacket;)V - -
 method public,abstract handleGameEvent (Lnet/minecraft/network/protocol/game/ClientboundGameEventPacket;)V - -
 method public,abstract handleKeepAlive (Lnet/minecraft/network/protocol/game/ClientboundKeepAlivePacket;)V - -
 method public,abstract handleLevelChunk (Lnet/minecraft/network/protocol/game/ClientboundLevelChunkPacket;)V - -
 method public,abstract handleForgetLevelChunk (Lnet/minecraft/network/protocol/game/ClientboundForgetLevelChunkPacket;)V - -
 method public,abstract handleLevelEvent (Lnet/minecraft/network/protocol/game/ClientboundLevelEventPacket;)V - -
 method public,abstract handleLogin (Lnet/minecraft/network/protocol/game/ClientboundLoginPacket;)V - -
 method public,abstract handleMoveEntity (Lnet/minecraft/network/protocol/game/ClientboundMoveEntityPacket;)V - -
 method public,abstract handleMovePlayer (Lnet/minecraft/network/protocol/game/ClientboundPlayerPositionPacket;)V - -
 method public,abstract handleParticleEvent (Lnet/minecraft/network/protocol/game/ClientboundLevelParticlesPacket;)V - -
 method public,abstract handlePlayerAbilities (Lnet/minecraft/network/protocol/game/ClientboundPlayerAbilitiesPacket;)V - -
 method public,abstract handlePlayerInfo (Lnet/minecraft/network/protocol/game/ClientboundPlayerInfoPacket;)V - -
 method public,abstract handleRemoveEntity (Lnet/minecraft/network/protocol/game/ClientboundRemoveEntitiesPacket;)V - -
 method public,abstract handleRemoveMobEffect (Lnet/minecraft/network/protocol/game/ClientboundRemoveMobEffectPacket;)V - -
 method public,abstract handleRespawn (Lnet/minecraft/network/protocol/game/ClientboundRespawnPacket;)V - -
 method public,abstract handleRotateMob (Lnet/minecraft/network/protocol/game/ClientboundRotateHeadPacket;)V - -
 method public,abstract handleSetCarriedItem (Lnet/minecraft/network/protocol/game/ClientboundSetCarriedItemPacket;)V - -
 method public,abstract handleSetDisplayObjective (Lnet/minecraft/network/protocol/game/ClientboundSetDisplayObjectivePacket;)V - -
 method public,abstract handleSetEntityData (Lnet/minecraft/network/protocol/game/ClientboundSetEntityDataPacket;)V - -
 method public,abstract handleSetEntityMotion (Lnet/minecraft/network/protocol/game/ClientboundSetEntityMotionPacket;)V - -
 method public,abstract handleSetEquippedItem (Lnet/minecraft/network/protocol/game/ClientboundSetEquippedItemPacket;)V - -
 method public,abstract handleSetExperience (Lnet/minecraft/network/protocol/game/ClientboundSetExperiencePacket;)V - -
 method public,abstract handleSetHealth (Lnet/minecraft/network/protocol/game/ClientboundSetHealthPacket;)V - -
 method public,abstract handleSetPlayerTeamPacket (Lnet/minecraft/network/protocol/game/ClientboundSetPlayerTeamPacket;)V - -
 method public,abstract handleSetScore (Lnet/minecraft/network/protocol/game/ClientboundSetScorePacket;)V - -
 method public,abstract handleSetSpawn (Lnet/minecraft/network/protocol/game/ClientboundSetSpawnPositionPacket;)V - -
 method public,abstract handleSetTime (Lnet/minecraft/network/protocol/game/ClientboundSetTimePacket;)V - -
 method public,abstract handleSoundEvent (Lnet/minecraft/network/protocol/game/ClientboundSoundPacket;)V - -
 method public,abstract handleCustomSoundEvent (Lnet/minecraft/network/protocol/game/ClientboundCustomSoundPacket;)V - -
 method public,abstract handleTakeItemEntity (Lnet/minecraft/network/protocol/game/ClientboundTakeItemEntityPacket;)V - -
 method public,abstract handleTeleportEntity (Lnet/minecraft/network/protocol/game/ClientboundTeleportEntityPacket;)V - -
 method public,abstract handleUpdateAttributes (Lnet/minecraft/network/protocol/game/ClientboundUpdateAttributesPacket;)V - -
 method public,abstract handleUpdateMobEffect (Lnet/minecraft/network/protocol/game/ClientboundUpdateMobEffectPacket;)V - -
 method public,abstract handleUpdateTags (Lnet/minecraft/network/protocol/game/ClientboundUpdateTagsPacket;)V - -
 method public,abstract handlePlayerCombat (Lnet/minecraft/network/protocol/game/ClientboundPlayerCombatPacket;)V - -
 method public,abstract handleChangeDifficulty (Lnet/minecraft/network/protocol/game/ClientboundChangeDifficultyPacket;)V - -
 method public,abstract handleSetCamera (Lnet/minecraft/network/protocol/game/ClientboundSetCameraPacket;)V - -
 method public,abstract handleSetBorder (Lnet/minecraft/network/protocol/game/ClientboundSetBorderPacket;)V - -
 method public,abstract handleSetTitles (Lnet/minecraft/network/protocol/game/ClientboundSetTitlesPacket;)V - -
 method public,abstract handleTabListCustomisation (Lnet/minecraft/network/protocol/game/ClientboundTabListPacket;)V - -
 method public,abstract handleResourcePack (Lnet/minecraft/network/protocol/game/ClientboundResourcePackPacket;)V - -
 method public,abstract handleBossUpdate (Lnet/minecraft/network/protocol/game/ClientboundBossEventPacket;)V - -
 method public,abstract handleItemCooldown (Lnet/minecraft/network/protocol/game/ClientboundCooldownPacket;)V - -
 method public,abstract handleMoveVehicle (Lnet/minecraft/network/protocol/game/ClientboundMoveVehiclePacket;)V - -
 method public,abstract handleUpdateAdvancementsPacket (Lnet/minecraft/network/protocol/game/ClientboundUpdateAdvancementsPacket;)V - -
 method public,abstract handleSelectAdvancementsTab (Lnet/minecraft/network/protocol/game/ClientboundSelectAdvancementsTabPacket;)V - -
 method public,abstract handlePlaceRecipe (Lnet/minecraft/network/protocol/game/ClientboundPlaceGhostRecipePacket;)V - -
 method public,abstract handleCommands (Lnet/minecraft/network/protocol/game/ClientboundCommandsPacket;)V - -
 method public,abstract handleStopSoundEvent (Lnet/minecraft/network/protocol/game/ClientboundStopSoundPacket;)V - -
 method public,abstract handleCommandSuggestions (Lnet/minecraft/network/protocol/game/ClientboundCommandSuggestionsPacket;)V - -
 method public,abstract handleUpdateRecipes (Lnet/minecraft/network/protocol/game/ClientboundUpdateRecipesPacket;)V - -
 method public,abstract handleLookAt (Lnet/minecraft/network/protocol/game/ClientboundPlayerLookAtPacket;)V - -
 method public,abstract handleTagQueryPacket (Lnet/minecraft/network/protocol/game/ClientboundTagQueryPacket;)V - -
in 131
class jt 52 public,super java/lang/Object iv Ljava/lang/Object;Liv<Liy;>;
 method public b ()I - -
 method public c ()Ljava/lang/String; - -
 method public d ()Lnet/minecraft/network/chat/Component; - -
 method public e ()I - -
 method public f ()I - -
 method public g ()Z - -
 method public <init> ()V - -
 method public <init> (ILjava/lang/String;Lnet/minecraft/network/chat/Component;)V - -
 method public <init> (ILjava/lang/String;Lnet/minecraft/network/chat/Component;I)V - -
 method public <init> (ILjava/lang/String;Lnet/minecraft/network/chat/Component;II)V - -
 method public handle (Liy;)V - -
 method public read (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
in 135
class jt 52 public,super java/lang/Object iv Ljava/lang/Object;Liv<Liy;>;
 method public <init> ()V - -
 method public <init> (ILjava/lang/String;Lnet/minecraft/network/chat/Component;)V - -
 method public <init> (ILjava/lang/String;Lnet/minecraft/network/chat/Component;I)V - -
 method public <init> (ILjava/lang/String;Lnet/minecraft/network/chat/Component;II)V - -
 method public handle (Liy;)V - -
 method public read (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public b ()I - -
 method public c ()Ljava/lang/String; - -
 method public d ()Lnet/minecraft/network/chat/Component; - -
 method public e ()I - -
 method public f ()I - -
 method public g ()Z - -
in 131
class ku 52 public,super java/lang/Object iv Ljava/lang/Object;Liv<Liy;>;
 method public a (Lnet/minecraft/world/level/Level;)Lnet/minecraft/world/entity/player/Player; - -
 method public b ()Lnet/minecraft/core/BlockPos; - -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;)V - -
 method public read (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public handle (Liy;)V - -
in 135
class ku 52 public,super java/lang/Object iv Ljava/lang/Object;Liv<Liy;>;
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;)V - -
 method public read (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public handle (Liy;)V - -
 method public a (Lnet/minecraft/world/level/Level;)Lnet/minecraft/world/entity/player/Player; - -
 method public b ()Lnet/minecraft/core/BlockPos; - -
in 59
class me 52 public,interface,abstract java/lang/Object net/minecraft/network/PacketListener -
 method public,abstract handleAnimate (Lnet/minecraft/network/protocol/game/ServerboundSwingPacket;)V - -
 method public,abstract handleChat (Lnet/minecraft/network/protocol/game/ServerboundChatPacket;)V - -
 method public,abstract handleClientCommand (Lnet/minecraft/network/protocol/game/ServerboundClientCommandPacket;)V - -
 method public,abstract handleClientInformation (Lnet/minecraft/network/protocol/game/ServerboundClientInformationPacket;)V - -
 method public,abstract handleContainerAck (Lnet/minecraft/network/protocol/game/ServerboundContainerAckPacket;)V - -
 method public,abstract handleContainerButtonClick (Lnet/minecraft/network/protocol/game/ServerboundContainerButtonClickPacket;)V - -
 method public,abstract handleContainerClick (Lnet/minecraft/network/protocol/game/ServerboundContainerClickPacket;)V - -
 method public,abstract handlePlaceRecipe (Lnet/minecraft/network/protocol/game/ServerboundPlaceRecipePacket;)V - -
 method public,abstract handleContainerClose (Lnet/minecraft/network/protocol/game/ServerboundContainerClosePacket;)V - -
 method public,abstract handleCustomPayload (Lnet/minecraft/network/protocol/game/ServerboundCustomPayloadPacket;)V - -
 method public,abstract handleInteract (Lnet/minecraft/network/protocol/game/ServerboundInteractPacket;)V - -
 method public,abstract handleKeepAlive (Lnet/minecraft/network/protocol/game/ServerboundKeepAlivePacket;)V - -
 method public,abstract handleMovePlayer (Lnet/minecraft/network/protocol/game/ServerboundMovePlayerPacket;)V - -
 method public,abstract handlePlayerAbilities (Lnet/minecraft/network/protocol/game/ServerboundPlayerAbilitiesPacket;)V - -
 method public,abstract handlePlayerAction (Lnet/minecraft/network/protocol/game/ServerboundPlayerActionPacket;)V - -
 method public,abstract handlePlayerCommand (Lnet/minecraft/network/protocol/game/ServerboundPlayerCommandPacket;)V - -
 method public,abstract handlePlayerInput (Lnet/minecraft/network/protocol/game/ServerboundPlayerInputPacket;)V - -
 method public,abstract handleSetCarriedItem (Lnet/minecraft/network/protocol/game/ServerboundSetCarriedItemPacket;)V - -
 method public,abstract handleSetCreativeModeSlot (Lnet/minecraft/network/protocol/game/ServerboundSetCreativeModeSlotPacket;)V - -
 method public,abstract handleSignUpdate (Lnet/minecraft/network/protocol/game/ServerboundSignUpdatePacket;)V - -
 method public,abstract handleUseItemOn (Lnet/minecraft/network/protocol/game/ServerboundUseItemOnPacket;)V - -
 method public,abstract handleUseItem (Lnet/minecraft/network/protocol/game/ServerboundUseItemPacket;)V - -
 method public,abstract handleTeleportToEntityPacket (Lnet/minecraft/network/protocol/game/ServerboundTeleportToEntityPacket;)V - -
 method public,abstract handleResourcePackResponse (Lnet/minecraft/network/protocol/game/ServerboundResourcePackPacket;)V - -
 method public,abstract handlePaddleBoat (Lnet/minecraft/network/protocol/game/ServerboundPaddleBoatPacket;)V - -
 method public,abstract handleMoveVehicle (Lnet/minecraft/network/protocol/game/ServerboundMoveVehiclePacket;)V - -
 method public,abstract handleAcceptTeleportPacket (Lnet/minecraft/network/protocol/game/ServerboundAcceptTeleportationPacket;)V - -
 method public,abstract handleRecipeBookUpdatePacket (Lnet/minecraft/network/protocol/game/ServerboundRecipeBookUpdatePacket;)V - -
 method public,abstract handleSeenAdvancements (Lnet/minecraft/network/protocol/game/ServerboundSeenAdvancementsPacket;)V - -
 method public,abstract handleCustomCommandSuggestions (Lnet/minecraft/network/protocol/game/ServerboundCommandSuggestionPacket;)V - -
 method public,abstract handleSetCommandBlock (Lnet/minecraft/network/protocol/game/ServerboundSetCommandBlockPacket;)V - -
 method public,abstract handleSetCommandMinecart (Lnet/minecraft/network/protocol/game/ServerboundSetCommandMinecartPacket;)V - -
 method public,abstract handlePickItem (Lnet/minecraft/network/protocol/game/ServerboundPickItemPacket;)V - -
 method public,abstract handleRenameItem (Lnet/minecraft/network/protocol/game/ServerboundRenameItemPacket;)V - -
 method public,abstract handleSetBeaconPacket (Lnet/minecraft/network/protocol/game/ServerboundSetBeaconPacket;)V - -
 method public,abstract handleSetStructureBlock (Lnet/minecraft/network/protocol/game/ServerboundSetStructureBlockPacket;)V - -
 method public,abstract handleSelectTrade (Lnet/minecraft/network/protocol/game/ServerboundSelectTradePacket;)V - -
 method public,abstract handleEditBook (Lnet/minecraft/network/protocol/game/ServerboundEditBookPacket;)V - -
 method public,abstract handleEntityTagQuery (Lnet/minecraft/network/protocol/game/ServerboundEntityTagQuery;)V - -
 method public,abstract handleBlockEntityTagQuery (Lnet/minecraft/network/protocol/game/ServerboundBlockEntityTagQuery;)V - -
in 59
class nv 52 public,interface,abstract java/lang/Object net/minecraft/network/PacketListener -
 method public,abstract handleIntention (Lnet/minecraft/network/protocol/handshake/ClientIntentionPacket;)V - -
in 59
class nx 52 public,interface,abstract java/lang/Object net/minecraft/network/PacketListener -
 method public,abstract handleHello (Lnet/minecraft/network/protocol/login/ClientboundHelloPacket;)V - -
 method public,abstract handleGameProfile (Lnet/minecraft/network/protocol/login/ClientboundGameProfilePacket;)V - -
 method public,abstract handleDisconnect (Lnet/minecraft/network/protocol/login/ClientboundLoginDisconnectPacket;)V - -
 method public,abstract handleCompression (Lnet/minecraft/network/protocol/login/ClientboundLoginCompressionPacket;)V - -
 method public,abstract handleCustomQuery (Lnet/minecraft/network/protocol/login/ClientboundCustomQueryPacket;)V - -
in 59
class od 52 public,interface,abstract java/lang/Object net/minecraft/network/PacketListener -
 method public,abstract handleHello (Lnet/minecraft/network/protocol/login/ServerboundHelloPacket;)V - -
 method public,abstract handleKey (Lnet/minecraft/network/protocol/login/ServerboundKeyPacket;)V - -
 method public,abstract handleCustomQueryPacket (Lnet/minecraft/network/protocol/login/ServerboundCustomQueryPacket;)V - -
in 59
class oj 52 public,interface,abstract java/lang/Object net/minecraft/network/PacketListener -
 method public,abstract handleStatusResponse (Lnet/minecraft/network/protocol/status/ClientboundStatusResponsePacket;)V - -
 method public,abstract handlePongResponse (Lnet/minecraft/network/protocol/status/ClientboundPongResponsePacket;)V - -
in 59
class on 52 public,interface,abstract java/lang/Object net/minecraft/network/PacketListener -
 method public,abstract handlePingRequest (Lnet/minecraft/network/protocol/status/ServerboundPingRequestPacket;)V - -
 method public,abstract handleStatusRequest (Lop;)V - -
in 59
class op 52 public,super java/lang/Object iv Ljava/lang/Object;Liv<Lon;>;
 method public <init> ()V - -
 method public read (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public write (Lnet/minecraft/network/FriendlyByteBuf;)V - java/io/IOException
 method public handle (Lon;)V - -
in 59
class pe 52 public,super,abstract net/minecraft/core/dispenser/DefaultDispenseItemBehavior - -
 method public <init> ()V - -
 method public execute (Lnet/minecraft/core/BlockSource;Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/ItemStack; - -
 method protected playSound (Lnet/minecraft/core/BlockSource;)V - -
 method protected,abstract getProjectile (Lnet/minecraft/world/level/Level;Lnet/minecraft/core/Position;Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/entity/projectile/Projectile; - -
 method protected getUncertainty ()F - -
 method protected getPower ()F - -
in 59
class pt 52 public,interface,abstract java/lang/Object - -
 method public,abstract tick ()V - -
in 59
class sw 52 public,super td - -
 field public,static,final a Lnet/minecraft/world/level/LevelSettings; -
 method public <init> (Lnet/minecraft/server/MinecraftServer;Lccc;Lcck;Lnet/minecraft/world/level/storage/LevelData;Lnet/minecraft/world/level/dimension/DimensionType;Lnet/minecraft/util/profiling/ActiveProfiler;)V - -
in 131
class sz 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public,static a (Lnet/minecraft/world/entity/Entity;DDD)V - -
 method public <init> (Ltd;)V - -
 method public,static a (D)J - -
 method public a (Lnet/minecraft/world/entity/Entity;)V - -
 method public a (Lnet/minecraft/world/entity/Entity;II)V - -
 method public a (Lnet/minecraft/world/entity/Entity;IIZ)V - -
 method public b (Lnet/minecraft/world/entity/Entity;)V - -
 method public a ()V - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public a (Lnet/minecraft/world/entity/Entity;Liv;)V (Lnet/minecraft/world/entity/Entity;Liv<*>;)V -
 method public b (Lnet/minecraft/world/entity/Entity;Liv;)V (Lnet/minecraft/world/entity/Entity;Liv<*>;)V -
 method public b (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/chunk/LevelChunk;)V - -
 method public a (I)V - -
in 135
class sz 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ltd;)V - -
 method public,static a (D)J - -
 method public,static a (Lnet/minecraft/world/entity/Entity;DDD)V - -
 method public a (Lnet/minecraft/world/entity/Entity;)V - -
 method public a (Lnet/minecraft/world/entity/Entity;II)V - -
 method public a (Lnet/minecraft/world/entity/Entity;IIZ)V - -
 method public b (Lnet/minecraft/world/entity/Entity;)V - -
 method public a ()V - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public a (Lnet/minecraft/world/entity/Entity;Liv;)V (Lnet/minecraft/world/entity/Entity;Liv<*>;)V -
 method public b (Lnet/minecraft/world/entity/Entity;Liv;)V (Lnet/minecraft/world/entity/Entity;Liv<*>;)V -
 method public b (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/world/level/chunk/LevelChunk;)V - -
 method public a (I)V - -
 method public getTrackingPlayers (Lnet/minecraft/world/entity/Entity;)Ljava/util/Set; (Lnet/minecraft/world/entity/Entity;)Ljava/util/Set<+Lnet/minecraft/world/entity/player/Player;>; -
in 59
class ta 52 public,super it/unimi/dsi/fastutil/longs/Long2ObjectOpenHashMap - Lit/unimi/dsi/fastutil/longs/Long2ObjectOpenHashMap<Lnet/minecraft/world/level/chunk/LevelChunk;>;
 method public <init> (I)V - -
 method public a (JLnet/minecraft/world/level/chunk/LevelChunk;)Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method public a (Ljava/lang/Long;Lnet/minecraft/world/level/chunk/LevelChunk;)Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method public a (J)Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method public a (Ljava/lang/Object;)Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method public putAll (Ljava/util/Map;)V (Ljava/util/Map<+Ljava/lang/Long;+Lnet/minecraft/world/level/chunk/LevelChunk;>;)V -
 method public remove (Ljava/lang/Object;Ljava/lang/Object;)Z - -
in 131
class td 52 public,super net/minecraft/world/level/Level acv -
 inner net/minecraft/world/level/biome/Biome$SpawnerData net/minecraft/world/level/biome/Biome SpawnerData public,static
 inner net/minecraft/util/WeighedRandom$WeighedRandomItem net/minecraft/util/WeighedRandom WeighedRandomItem public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/level/biome/Biome$Precipitation net/minecraft/world/level/biome/Biome Precipitation public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public noSave Z -
 field protected,final c Lnet/minecraft/world/entity/ai/village/VillageSiege; -
 method public validateSpawn ()V - -
 method public <init> (Lnet/minecraft/server/MinecraftServer;Lccc;Lcck;Lnet/minecraft/world/level/storage/LevelData;Lnet/minecraft/world/level/dimension/DimensionType;Lnet/minecraft/util/profiling/ActiveProfiler;)V - -
 method public i_ ()Ltd; - -
 method public tick (Ljava/util/function/BooleanSupplier;)V - -
 method public isHandlingTick ()Z - -
 method public a (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/biome/Biome$SpawnerData; - -
 method public a (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/world/level/biome/Biome$SpawnerData;Lnet/minecraft/core/BlockPos;)Z - -
 method public updateSleepingPlayerList ()V - -
 method public getScoreboard ()Lnet/minecraft/server/ServerScoreboard; - -
 method protected i ()V - -
 method public j ()Z - -
 method public a (IIZ)Z - -
 method public a (II)Z - -
 method protected l ()V - -
 method protected n_ ()V - -
 method protected findLightingTargetAround (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public o_ ()V - -
 method protected p_ ()V - -
 method public resetEmptyTime ()V - -
 method public q ()V - -
 method public a (Lnet/minecraft/world/entity/Entity;Z)V - -
 method protected r ()Lbnc; - -
 method public mayInteract (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;)Z - -
 method public a (Lnet/minecraft/world/level/LevelSettings;)V - -
 method protected generateBonusItemsNearSpawn ()V - -
 method public getDimensionSpecificSpawn ()Lnet/minecraft/core/BlockPos; - -
 method public a (ZLnet/minecraft/util/ProgressListener;)V - net/minecraft/world/level/LevelConflictException
 method public u ()V - -
 method protected saveLevelData ()V - net/minecraft/world/level/LevelConflictException
 method public addEntity (Lnet/minecraft/world/entity/Entity;)Z - -
 method public a (Ljava/util/stream/Stream;)V (Ljava/util/stream/Stream<Lnet/minecraft/world/entity/Entity;>;)V -
 method protected b (Lnet/minecraft/world/entity/Entity;)V - -
 method protected c (Lnet/minecraft/world/entity/Entity;)V - -
 method public d (Lnet/minecraft/world/entity/Entity;)Z - -
 method public broadcastEntityEvent (Lnet/minecraft/world/entity/Entity;B)V - -
 method public getChunkSource ()Lnet/minecraft/server/level/ServerChunkCache; - -
 method public a (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;DDDFZZ)Lnet/minecraft/world/level/Explosion; - -
 method public blockEvent (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;II)V - -
 method public close ()V - -
 method protected w ()V - -
 method public getBlockTicks ()Lnet/minecraft/world/level/ServerTickList; ()Lnet/minecraft/world/level/ServerTickList<Lnet/minecraft/world/level/block/Block;>; -
 method public getLiquidTicks ()Lnet/minecraft/world/level/ServerTickList; ()Lnet/minecraft/world/level/ServerTickList<Lnet/minecraft/world/level/material/Fluid;>; -
 method public getServer ()Lnet/minecraft/server/MinecraftServer; - -
 method public A ()Lsz; - -
 method public B ()Ltl; - -
 method public getPortalForcer ()Lnet/minecraft/world/level/PortalForcer; - -
 method public getStructureManager ()Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureManager; - -
 method public sendParticles (Lnet/minecraft/core/particles/ParticleOptions;DDDIDDDD)I <T::Lnet/minecraft/core/particles/ParticleOptions;>(TT;DDDIDDDD)I -
 method public sendParticles (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/core/particles/ParticleOptions;ZDDDIDDDD)Z <T::Lnet/minecraft/core/particles/ParticleOptions;>(Lnet/minecraft/server/level/ServerPlayer;TT;ZDDDIDDDD)Z -
 method public a (Ljava/util/UUID;)Lnet/minecraft/world/entity/Entity; - -
 method public a (Ljava/lang/Runnable;)Lcom/google/common/util/concurrent/ListenableFuture; (Ljava/lang/Runnable;)Lcom/google/common/util/concurrent/ListenableFuture<Ljava/lang/Object;>; -
 method public av ()Z - -
 method public findNearestMapFeature (Ljava/lang/String;Lnet/minecraft/core/BlockPos;IZ)Lnet/minecraft/core/BlockPos; - -
 method public getRecipeManager ()Lnet/minecraft/world/item/crafting/RecipeManager; - -
 method public getTagManager ()Lnet/minecraft/tags/TagManager; - -
in 135
class td 52 public,super net/minecraft/world/level/Level acv,net/minecraftforge/common/extensions/IForgeWorldServer -
 inner net/minecraft/world/level/biome/Biome$SpawnerData net/minecraft/world/level/biome/Biome SpawnerData public,static
 inner net/minecraftforge/event/world/WorldEvent$Save net/minecraftforge/event/world/WorldEvent Save public,static
 inner net/minecraft/util/WeighedRandom$WeighedRandomItem net/minecraft/util/WeighedRandom WeighedRandomItem public,static
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/level/biome/Biome$Precipitation net/minecraft/world/level/biome/Biome Precipitation public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public noSave Z -
 field protected,final c Lnet/minecraft/world/entity/ai/village/VillageSiege; -
 field protected doneChunks Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/world/level/ChunkPos;>;
 field public customTeleporters Ljava/util/List; Ljava/util/List<Lnet/minecraft/world/level/PortalForcer;>;
 method public <init> (Lnet/minecraft/server/MinecraftServer;Lccc;Lcck;Lnet/minecraft/world/level/storage/LevelData;Lnet/minecraft/world/level/dimension/DimensionType;Lnet/minecraft/util/profiling/ActiveProfiler;)V - -
 method public i_ ()Ltd; - -
 method public tick (Ljava/util/function/BooleanSupplier;)V - -
 method public isHandlingTick ()Z - -
 method public a (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/core/BlockPos;)Lnet/minecraft/world/level/biome/Biome$SpawnerData; - -
 method public a (Lnet/minecraft/world/entity/MobCategory;Lnet/minecraft/world/level/biome/Biome$SpawnerData;Lnet/minecraft/core/BlockPos;)Z - -
 method public updateSleepingPlayerList ()V - -
 method public getScoreboard ()Lnet/minecraft/server/ServerScoreboard; - -
 method protected i ()V - -
 method public j ()Z - -
 method public validateSpawn ()V - -
 method public a (IIZ)Z - -
 method public a (II)Z - -
 method protected l ()V - -
 method protected n_ ()V - -
 method protected findLightingTargetAround (Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/BlockPos; - -
 method public o_ ()V - -
 method protected p_ ()V - -
 method public resetEmptyTime ()V - -
 method public q ()V - -
 method public a (Lnet/minecraft/world/entity/Entity;Z)V - -
 method protected r ()Lbnc; - -
 method public mayInteract (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;)Z - -
 method public canMineBlockBody (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/core/BlockPos;)Z - -
 method public a (Lnet/minecraft/world/level/LevelSettings;)V - -
 method protected generateBonusItemsNearSpawn ()V - -
 method public getDimensionSpecificSpawn ()Lnet/minecraft/core/BlockPos; - -
 method public a (ZLnet/minecraft/util/ProgressListener;)V - net/minecraft/world/level/LevelConflictException
 method public u ()V - -
 method protected saveLevelData ()V - net/minecraft/world/level/LevelConflictException
 method public addEntity (Lnet/minecraft/world/entity/Entity;)Z - -
 method public a (Ljava/util/stream/Stream;)V (Ljava/util/stream/Stream<Lnet/minecraft/world/entity/Entity;>;)V -
 method public b (Lnet/minecraft/world/entity/Entity;)V - -
 method public c (Lnet/minecraft/world/entity/Entity;)V - -
 method public d (Lnet/minecraft/world/entity/Entity;)Z - -
 method public broadcastEntityEvent (Lnet/minecraft/world/entity/Entity;B)V - -
 method public getChunkSource ()Lnet/minecraft/server/level/ServerChunkCache; - -
 method public a (Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;DDDFZZ)Lnet/minecraft/world/level/Explosion; - -
 method public blockEvent (Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Block;II)V - -
 method public close ()V - -
 method protected w ()V - -
 method public getBlockTicks ()Lnet/minecraft/world/level/ServerTickList; ()Lnet/minecraft/world/level/ServerTickList<Lnet/minecraft/world/level/block/Block;>; -
 method public getLiquidTicks ()Lnet/minecraft/world/level/ServerTickList; ()Lnet/minecraft/world/level/ServerTickList<Lnet/minecraft/world/level/material/Fluid;>; -
 method public getServer ()Lnet/minecraft/server/MinecraftServer; - -
 method public A ()Lsz; - -
 method public B ()Ltl; - -
 method public getPortalForcer ()Lnet/minecraft/world/level/PortalForcer; - -
 method public getStructureManager ()Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureManager; - -
 method public sendParticles (Lnet/minecraft/core/particles/ParticleOptions;DDDIDDDD)I <T::Lnet/minecraft/core/particles/ParticleOptions;>(TT;DDDIDDDD)I -
 method public sendParticles (Lnet/minecraft/server/level/ServerPlayer;Lnet/minecraft/core/particles/ParticleOptions;ZDDDIDDDD)Z <T::Lnet/minecraft/core/particles/ParticleOptions;>(Lnet/minecraft/server/level/ServerPlayer;TT;ZDDDIDDDD)Z -
 method public a (Ljava/util/UUID;)Lnet/minecraft/world/entity/Entity; - -
 method public a (Ljava/lang/Runnable;)Lcom/google/common/util/concurrent/ListenableFuture; (Ljava/lang/Runnable;)Lcom/google/common/util/concurrent/ListenableFuture<Ljava/lang/Object;>; -
 method public av ()Z - -
 method public findNearestMapFeature (Ljava/lang/String;Lnet/minecraft/core/BlockPos;IZ)Lnet/minecraft/core/BlockPos; - -
 method public getRecipeManager ()Lnet/minecraft/world/item/crafting/RecipeManager; - -
 method public getTagManager ()Lnet/minecraft/tags/TagManager; - -
 method public getChunkSaveLocation ()Ljava/io/File; - -
in 59
class te 52 public,super java/lang/Object ayb -
 method public <init> (Lnet/minecraft/server/MinecraftServer;Ltd;)V - -
 method public addParticle (Lnet/minecraft/core/particles/ParticleOptions;ZDDDDDD)V - -
 method public addParticle (Lnet/minecraft/core/particles/ParticleOptions;ZZDDDDDD)V - -
 method public a (Lnet/minecraft/world/entity/Entity;)V - -
 method public b (Lnet/minecraft/world/entity/Entity;)V - -
 method public a (Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;DDDFF)V - -
 method public setBlocksDirty (IIIIII)V - -
 method public blockChanged (Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;I)V - -
 method public a (Lnet/minecraft/core/BlockPos;)V - -
 method public playStreamingMusic (Lnet/minecraft/sounds/SoundEvent;Lnet/minecraft/core/BlockPos;)V - -
 method public levelEvent (Lnet/minecraft/world/entity/player/Player;ILnet/minecraft/core/BlockPos;I)V - -
 method public globalLevelEvent (ILnet/minecraft/core/BlockPos;I)V - -
 method public destroyBlockProgress (ILnet/minecraft/core/BlockPos;I)V - -
in 131
class th 52 public,super java/lang/Object - -
 inner net/minecraft/network/protocol/game/ClientboundMoveEntityPacket$c net/minecraft/network/protocol/game/ClientboundMoveEntityPacket c public,static
 inner net/minecraft/network/protocol/game/ClientboundMoveEntityPacket$b net/minecraft/network/protocol/game/ClientboundMoveEntityPacket b public,static
 inner net/minecraft/network/protocol/game/ClientboundMoveEntityPacket$a net/minecraft/network/protocol/game/ClientboundMoveEntityPacket a public,static
 inner net/minecraft/world/entity/vehicle/AbstractMinecart$Type net/minecraft/world/entity/vehicle/AbstractMinecart Type public,static,final,enum
 field public a I -
 field public b Z -
 method public <init> (Lnet/minecraft/world/entity/Entity;IIIZ)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public a (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/world/entity/player/Player;>;)V -
 method public a (Liv;)V (Liv<*>;)V -
 method public b (Liv;)V (Liv<*>;)V -
 method public a ()V - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public b (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public c (Lnet/minecraft/server/level/ServerPlayer;)Z - -
 method public b (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/world/entity/player/Player;>;)V -
 method public d (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public b ()Lnet/minecraft/world/entity/Entity; - -
 method public a (I)V - -
 method public c ()V - -
in 135
class th 52 public,super java/lang/Object - -
 inner net/minecraft/network/protocol/game/ClientboundMoveEntityPacket$c net/minecraft/network/protocol/game/ClientboundMoveEntityPacket c public,static
 inner net/minecraft/network/protocol/game/ClientboundMoveEntityPacket$a net/minecraft/network/protocol/game/ClientboundMoveEntityPacket a public,static
 inner net/minecraft/network/protocol/game/ClientboundMoveEntityPacket$b net/minecraft/network/protocol/game/ClientboundMoveEntityPacket b public,static
 inner net/minecraft/world/entity/vehicle/AbstractMinecart$Type net/minecraft/world/entity/vehicle/AbstractMinecart Type public,static,final,enum
 field public a I -
 field public b Z -
 field public,final z Ljava/util/Set; Ljava/util/Set<Lnet/minecraft/server/level/ServerPlayer;>;
 method public <init> (Lnet/minecraft/world/entity/Entity;IIIZ)V - -
 method public equals (Ljava/lang/Object;)Z - -
 method public hashCode ()I - -
 method public a (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/world/entity/player/Player;>;)V -
 method public a (Liv;)V (Liv<*>;)V -
 method public b (Liv;)V (Liv<*>;)V -
 method public a ()V - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public b (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public c (Lnet/minecraft/server/level/ServerPlayer;)Z - -
 method public b (Ljava/util/List;)V (Ljava/util/List<Lnet/minecraft/world/entity/player/Player;>;)V -
 method public d (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public b ()Lnet/minecraft/world/entity/Entity; - -
 method public a (I)V - -
 method public c ()V - -
in 131
class tk 52 public,super java/lang/Object - -
 method public <init> (Ltl;II)V - -
 method public a ()Lnet/minecraft/world/level/ChunkPos; - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public b (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public a (Z)Z - -
 method public b ()Z - -
 method public c (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public c ()V - -
 method public a (III)V - -
 method public a (Liv;)V (Liv<*>;)V -
 method public d ()V - -
 method public d (Lnet/minecraft/server/level/ServerPlayer;)Z - -
 method public a (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<Lnet/minecraft/server/level/ServerPlayer;>;)Z -
 method public a (DLjava/util/function/Predicate;)Z (DLjava/util/function/Predicate<Lnet/minecraft/server/level/ServerPlayer;>;)Z -
 method public e ()Z - -
 method public f ()Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method public g ()D - -
in 135
class tk 52 public,super java/lang/Object - -
 inner net/minecraftforge/event/world/ChunkWatchEvent$Watch net/minecraftforge/event/world/ChunkWatchEvent Watch public,static
 inner net/minecraftforge/event/world/ChunkWatchEvent$UnWatch net/minecraftforge/event/world/ChunkWatchEvent UnWatch public,static
 inner net/minecraftforge/common/ForgeConfig$Server net/minecraftforge/common/ForgeConfig Server public,static
 inner net/minecraftforge/common/ForgeConfigSpec$IntValue net/minecraftforge/common/ForgeConfigSpec IntValue public,static
 method public <init> (Ltl;II)V - -
 method public a ()Lnet/minecraft/world/level/ChunkPos; - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public b (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public a (Z)Z - -
 method public b ()Z - -
 method public c (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public c ()V - -
 method public a (III)V - -
 method public a (Liv;)V (Liv<*>;)V -
 method public d ()V - -
 method public d (Lnet/minecraft/server/level/ServerPlayer;)Z - -
 method public a (Ljava/util/function/Predicate;)Z (Ljava/util/function/Predicate<Lnet/minecraft/server/level/ServerPlayer;>;)Z -
 method public a (DLjava/util/function/Predicate;)Z (DLjava/util/function/Predicate<Lnet/minecraft/server/level/ServerPlayer;>;)Z -
 method public e ()Z - -
 method public f ()Lnet/minecraft/world/level/chunk/LevelChunk; - -
 method public g ()D - -
 method public getWatchingPlayers ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/server/level/ServerPlayer;>; -
in 59
class tl 52 public,super java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (Ltd;)V - -
 method public a ()Ltd; - -
 method public b ()Ljava/util/Iterator; ()Ljava/util/Iterator<Lnet/minecraft/world/level/chunk/LevelChunk;>; -
 method public c ()V - -
 method public a (II)Z - -
 method public b (II)Ltk; - -
 method public a (Lnet/minecraft/core/BlockPos;)V - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public b (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public c (Lnet/minecraft/server/level/ServerPlayer;)V - -
 method public a (Lnet/minecraft/server/level/ServerPlayer;II)Z - -
 method public a (I)V - -
 method public,static b (I)I - -
 method public a (Ltk;)V - -
 method public b (Ltk;)V - -
in 59
class to 52 public,super tq - -
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 59
class tp 52 public,super tq - -
 inner net/minecraft/world/level/levelgen/GenerationStep$Carving net/minecraft/world/level/levelgen/GenerationStep Carving public,static,final,enum
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 59
class tq 52 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;IILjava/util/Map;)[Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;IILjava/util/Map<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ProtoChunk;>;)[Lnet/minecraft/world/level/chunk/ProtoChunk; -
 method public a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;Ljava/util/Map;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;Ljava/util/Map<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ProtoChunk;>;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
 method protected,abstract a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 59
class tr 52 public,super tq - -
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 59
class ts 52 public,super tq - -
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 59
class tt 52 public,super tq - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 59
class tu 52 public,super tq - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 59
class tv 52 public,super tq - -
 inner net/minecraft/world/level/levelgen/Heightmap$Types net/minecraft/world/level/levelgen/Heightmap Types public,static,final,enum
 inner net/minecraft/world/level/levelgen/GenerationStep$Carving net/minecraft/world/level/levelgen/GenerationStep Carving public,static,final,enum
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 59
class tw 52 public,super tq - -
 method public <init> ()V - -
 method protected a (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;[Lnet/minecraft/world/level/chunk/ProtoChunk;II)Lnet/minecraft/world/level/chunk/ProtoChunk; -
in 131
class tx 52 public,super acu - Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>;
 inner acu$a acu a public,final
 inner net/minecraft/world/level/chunk/ChunkStatus$ChunkType net/minecraft/world/level/chunk/ChunkStatus ChunkType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;Lbnw;Lacv;)V (ILnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;Lbnw;Lacv;)V -
 method protected a (Lnet/minecraft/world/level/ChunkPos;Z)Lacu$a; (Lnet/minecraft/world/level/ChunkPos;Z)Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>.acu$a; -
 method protected a (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Ljava/util/Map;)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Ljava/util/Map<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ProtoChunk;>;)Lnet/minecraft/world/level/chunk/ProtoChunk; -
 method protected a (Lnet/minecraft/world/level/ChunkPos;Lacu$a;)Lacu$a; (Lnet/minecraft/world/level/ChunkPos;Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>.acu$a;)Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>.acu$a; -
 method protected b (Lnet/minecraft/world/level/ChunkPos;Lacu$a;)V (Lnet/minecraft/world/level/ChunkPos;Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>.acu$a;)V -
 method public a (Ljava/util/function/BooleanSupplier;)V - -
in 135
class tx 52 public,super acu - Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>;
 inner acu$a acu a public,final
 inner net/minecraft/world/level/chunk/ChunkStatus$ChunkType net/minecraft/world/level/chunk/ChunkStatus ChunkType public,static,final,enum
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 method public <init> (ILnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator;Lbnw;Lacv;)V (ILnet/minecraft/world/level/Level;Lnet/minecraft/world/level/chunk/ChunkGenerator<*>;Lbnw;Lacv;)V -
 method protected a (Lnet/minecraft/world/level/ChunkPos;Z)Lacu$a; (Lnet/minecraft/world/level/ChunkPos;Z)Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>.a; -
 method protected a (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Ljava/util/Map;)Lnet/minecraft/world/level/chunk/ProtoChunk; (Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Ljava/util/Map<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ProtoChunk;>;)Lnet/minecraft/world/level/chunk/ProtoChunk; -
 method protected a (Lnet/minecraft/world/level/ChunkPos;Lacu$a;)Lacu$a; (Lnet/minecraft/world/level/ChunkPos;Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>.a;)Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>.a; -
 method protected b (Lnet/minecraft/world/level/ChunkPos;Lacu$a;)V (Lnet/minecraft/world/level/ChunkPos;Lacu<Lnet/minecraft/world/level/ChunkPos;Lnet/minecraft/world/level/chunk/ChunkStatus;Lnet/minecraft/world/level/chunk/ProtoChunk;>.a;)V -
 method public a (Ljava/util/function/BooleanSupplier;)V - -
in 59
class wq 52 public,interface,abstract java/lang/Object - -
 inner java/lang/invoke/MethodHandles$Lookup java/lang/invoke/MethodHandles Lookup public,static,final
 field public,static,final DECIMAL_FORMAT Ljava/text/DecimalFormat; -
 field public,static,final DEFAULT Lwq; -
 field public,static,final DIVIDE_BY_TEN Lwq; -
 field public,static,final DISTANCE Lwq; -
 field public,static,final TIME Lwq; -
 method public,abstract format (I)Ljava/lang/String; - -
in 59
class xm 52 public,super java/lang/Object - <V:Ljava/lang/Object;>Ljava/lang/Object;
 inner xm$a xm a static
 method public <init> ()V - -
 method public a (I)Ljava/lang/Object; (I)TV; -
 method public b (I)Z - -
 method public a (ILjava/lang/Object;)V (ITV;)V -
 method public d (I)Ljava/lang/Object; (I)TV; -
 method public c ()V - -
in 59
class xm$a 52 super java/lang/Object - <V:Ljava/lang/Object;>Ljava/lang/Object;
 inner xm$a xm a static
 method public,final a ()I - -
 method public,final b ()Ljava/lang/Object; ()TV; -
 method public,final equals (Ljava/lang/Object;)Z - -
 method public,final hashCode ()I - -
 method public,final toString ()Ljava/lang/String; - -
