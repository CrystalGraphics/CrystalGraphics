cg-stub-db 1
in 326
class net/minecraft/tileentity/BannerPattern 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/tileentity/BannerPattern;>;
 inner net/minecraft/block/BlockFlower$EnumFlowerType net/minecraft/block/BlockFlower EnumFlowerType public,static,final,enum
 field public,static,final,enum BASE Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum SQUARE_BOTTOM_LEFT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum SQUARE_BOTTOM_RIGHT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum SQUARE_TOP_LEFT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum SQUARE_TOP_RIGHT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_BOTTOM Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_TOP Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_LEFT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_RIGHT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_CENTER Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_MIDDLE Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_DOWNRIGHT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_DOWNLEFT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRIPE_SMALL Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum CROSS Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum STRAIGHT_CROSS Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum TRIANGLE_BOTTOM Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum TRIANGLE_TOP Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum TRIANGLES_BOTTOM Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum TRIANGLES_TOP Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum DIAGONAL_LEFT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum DIAGONAL_RIGHT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum DIAGONAL_LEFT_MIRROR Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum DIAGONAL_RIGHT_MIRROR Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum CIRCLE_MIDDLE Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum RHOMBUS_MIDDLE Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum HALF_VERTICAL Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum HALF_HORIZONTAL Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum HALF_VERTICAL_MIRROR Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum HALF_HORIZONTAL_MIRROR Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum BORDER Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum CURLY_BORDER Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum CREEPER Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum GRADIENT Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum GRADIENT_UP Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum BRICKS Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum SKULL Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum FLOWER Lnet/minecraft/tileentity/BannerPattern; -
 field public,static,final,enum MOJANG Lnet/minecraft/tileentity/BannerPattern; -
 method public,static values ()[Lnet/minecraft/tileentity/BannerPattern; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/tileentity/BannerPattern; - -
 method public getFileName ()Ljava/lang/String; - -
 method public getHashname ()Ljava/lang/String; - -
 method public getPatterns ()[Ljava/lang/String; - -
 method public hasPattern ()Z - -
 method public hasPatternItem ()Z - -
 method public getPatternItem ()Lnet/minecraft/item/ItemStack; - -
 method public,static byHash (Ljava/lang/String;)Lnet/minecraft/tileentity/BannerPattern; - -
in 91
class net/minecraft/tileentity/CommandBlockBaseLogic 50 public,super,abstract java/lang/Object net/minecraft/command/ICommandSender -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 method public,abstract getCommandBlockType ()I - -
 method public,abstract fillInInfo (Lio/netty/buffer/ByteBuf;)V - -
 method public <init> ()V - -
 method public getSuccessCount ()I - -
 method public setSuccessCount (I)V - -
 method public getLastOutput ()Lnet/minecraft/util/text/ITextComponent; - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readDataFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canUseCommand (ILjava/lang/String;)Z - -
 method public setCommand (Ljava/lang/String;)V - -
 method public getCommand ()Ljava/lang/String; - -
 method public trigger (Lnet/minecraft/world/World;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public setName (Ljava/lang/String;)V - -
 method public sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public sendCommandFeedback ()Z - -
 method public setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public,abstract updateCommand ()V - -
 method public setLastOutput (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public setTrackOutput (Z)V - -
 method public shouldTrackOutput ()Z - -
 method public tryOpenEditCommandBlock (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getCommandResultStats ()Lnet/minecraft/command/CommandResultStats; - -
in 326
class net/minecraft/tileentity/CommandBlockBaseLogic 52 public,super,abstract java/lang/Object net/minecraft/command/ICommandSender -
 inner net/minecraft/command/CommandResultStats$Type net/minecraft/command/CommandResultStats Type public,static,final,enum
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 method public <init> ()V - -
 method public getSuccessCount ()I - -
 method public setSuccessCount (I)V - -
 method public getLastOutput ()Lnet/minecraft/util/text/ITextComponent; - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readDataFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public canUseCommand (ILjava/lang/String;)Z - -
 method public setCommand (Ljava/lang/String;)V - -
 method public getCommand ()Ljava/lang/String; - -
 method public trigger (Lnet/minecraft/world/World;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public sendMessage (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public sendCommandFeedback ()Z - -
 method public setCommandStat (Lnet/minecraft/command/CommandResultStats$Type;I)V - -
 method public,abstract updateCommand ()V - -
 method public,abstract getCommandBlockType ()I - -
 method public,abstract fillInInfo (Lio/netty/buffer/ByteBuf;)V - -
 method public setLastOutput (Lnet/minecraft/util/text/ITextComponent;)V - -
 method public setTrackOutput (Z)V - -
 method public shouldTrackOutput ()Z - -
 method public tryOpenEditCommandBlock (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getCommandResultStats ()Lnet/minecraft/command/CommandResultStats; - -
in 24
class net/minecraft/tileentity/IHopper 50 public,interface,abstract java/lang/Object net/minecraft/inventory/IInventory -
 method public,abstract getWorld ()Lnet/minecraft/world/World; - -
 method public,abstract getXPos ()D - -
 method public,abstract getYPos ()D - -
 method public,abstract getZPos ()D - -
in 326
class net/minecraft/tileentity/IHopper 52 public,interface,abstract java/lang/Object net/minecraft/inventory/IInventory -
 method public,abstract getWorld ()Lnet/minecraft/world/World; - -
 method public,abstract getXPos ()D - -
 method public,abstract getYPos ()D - -
 method public,abstract getZPos ()D - -
in 90
class net/minecraft/tileentity/MobSpawnerBaseLogic 50 public,super,abstract java/lang/Object - -
 inner net/minecraft/tileentity/MobSpawnerBaseLogic$WeightedRandomMinecart net/minecraft/tileentity/MobSpawnerBaseLogic WeightedRandomMinecart public
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 method public func_180612_a (Lnet/minecraft/world/World;)Lnet/minecraft/entity/Entity; - -
 method public getMobRotation ()D - -
 method public getPrevMobRotation ()D - -
 method public <init> ()V - -
 method public setEntityName (Ljava/lang/String;)V - -
 method public updateSpawner ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public setDelayToMin (I)Z - -
 method public setRandomEntity (Lnet/minecraft/tileentity/MobSpawnerBaseLogic$WeightedRandomMinecart;)V - -
 method public,abstract func_98267_a (I)V - -
 method public,abstract getSpawnerWorld ()Lnet/minecraft/world/World; - -
 method public,abstract getSpawnerPosition ()Lnet/minecraft/util/BlockPos; - -
in 91
class net/minecraft/tileentity/MobSpawnerBaseLogic 50 public,super,abstract java/lang/Object - -
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 method public <init> ()V - -
 method public setEntityName (Ljava/lang/String;)V - -
 method public updateSpawner ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public setDelayToMin (I)Z - -
 method public getCachedEntity ()Lnet/minecraft/entity/Entity; - -
 method public setNextSpawnData (Lnet/minecraft/util/WeightedSpawnerEntity;)V - -
 method public,abstract broadcastEvent (I)V - -
 method public,abstract getSpawnerWorld ()Lnet/minecraft/world/World; - -
 method public,abstract getSpawnerPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getMobRotation ()D - -
 method public getPrevMobRotation ()D - -
in 326
class net/minecraft/tileentity/MobSpawnerBaseLogic 52 public,super,abstract java/lang/Object - -
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 method public <init> ()V - -
 method public setEntityId (Lnet/minecraft/util/ResourceLocation;)V - -
 method public updateSpawner ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public setDelayToMin (I)Z - -
 method public getCachedEntity ()Lnet/minecraft/entity/Entity; - -
 method public setNextSpawnData (Lnet/minecraft/util/WeightedSpawnerEntity;)V - -
 method public,abstract broadcastEvent (I)V - -
 method public,abstract getSpawnerWorld ()Lnet/minecraft/world/World; - -
 method public,abstract getSpawnerPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getMobRotation ()D - -
 method public getPrevMobRotation ()D - -
 method public getSpawnerEntity ()Lnet/minecraft/entity/Entity; - -
in 90
class net/minecraft/tileentity/MobSpawnerBaseLogic$WeightedRandomMinecart 50 public,super net/minecraft/util/WeightedRandom$Item - -
 inner net/minecraft/tileentity/MobSpawnerBaseLogic$WeightedRandomMinecart net/minecraft/tileentity/MobSpawnerBaseLogic WeightedRandomMinecart public
 inner net/minecraft/util/WeightedRandom$Item net/minecraft/util/WeightedRandom Item public,static
 inner net/minecraft/entity/item/EntityMinecart$EnumMinecartType net/minecraft/entity/item/EntityMinecart EnumMinecartType public,static,final,enum
 method public <init> (Lnet/minecraft/tileentity/MobSpawnerBaseLogic;Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public <init> (Lnet/minecraft/tileentity/MobSpawnerBaseLogic;Lnet/minecraft/nbt/NBTTagCompound;Ljava/lang/String;)V - -
 method public toNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 90
class net/minecraft/tileentity/TileEntity 50 public,super,abstract java/lang/Object net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner net/minecraft/block/BlockJukebox$TileEntityJukebox net/minecraft/block/BlockJukebox TileEntityJukebox public,static
 field protected worldObj Lnet/minecraft/world/World; -
 field protected pos Lnet/minecraft/util/BlockPos; -
 field protected tileEntityInvalid Z -
 field protected blockType Lnet/minecraft/block/Block; -
 field public,static,final INFINITE_EXTENT_AABB Lnet/minecraft/util/AxisAlignedBB; -
 method public,static addMapping (Ljava/lang/Class;Ljava/lang/String;)V (Ljava/lang/Class<+Lnet/minecraft/tileentity/TileEntity;>;Ljava/lang/String;)V -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public setWorldObj (Lnet/minecraft/world/World;)V - -
 method public hasWorldObj ()Z - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static createAndLoadEntity (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/tileentity/TileEntity; - -
 method public getBlockMetadata ()I - -
 method public markDirty ()V - -
 method public getDistanceSq (DDD)D - -
 method public getMaxRenderDistanceSquared ()D - -
 method public getPos ()Lnet/minecraft/util/BlockPos; - -
 method public getBlockType ()Lnet/minecraft/block/Block; - -
 method public getDescriptionPacket ()Lnet/minecraft/network/Packet; - -
 method public isInvalid ()Z - -
 method public invalidate ()V - -
 method public validate ()V - -
 method public receiveClientEvent (II)Z - -
 method public updateContainingBlockInfo ()V - -
 method public addInfoToCrashReport (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public setPos (Lnet/minecraft/util/BlockPos;)V - -
 method public func_183000_F ()Z - -
 method public onDataPacket (Lnet/minecraft/network/NetworkManager;Lnet/minecraft/network/play/server/S35PacketUpdateTileEntity;)V - -
 method public onChunkUnload ()V - -
 method public shouldRefresh (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/block/state/IBlockState;)Z - -
 method public shouldRenderInPass (I)Z - -
 method public getRenderBoundingBox ()Lnet/minecraft/util/AxisAlignedBB; - -
 method public canRenderBreaking ()Z - -
 method public getTileData ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public restrictNBTCopy ()Z - -
 method public onLoad ()V - -
 method public hasFastRenderer ()Z - -
 method public <init> ()V - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 91
class net/minecraft/tileentity/TileEntity 50 public,super,abstract java/lang/Object net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 inner net/minecraft/util/math/BlockPos$PooledMutableBlockPos net/minecraft/util/math/BlockPos PooledMutableBlockPos public,static,final
 inner net/minecraft/block/BlockJukebox$TileEntityJukebox net/minecraft/block/BlockJukebox TileEntityJukebox public,static
 field protected world Lnet/minecraft/world/World; -
 field protected pos Lnet/minecraft/util/math/BlockPos; -
 field protected tileEntityInvalid Z -
 field protected blockType Lnet/minecraft/block/Block; -
 field public,static,final INFINITE_EXTENT_AABB Lnet/minecraft/util/math/AxisAlignedBB; -
 method public,static addMapping (Ljava/lang/Class;Ljava/lang/String;)V (Ljava/lang/Class<+Lnet/minecraft/tileentity/TileEntity;>;Ljava/lang/String;)V -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public setWorld (Lnet/minecraft/world/World;)V - -
 method public hasWorld ()Z - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static create (Lnet/minecraft/world/World;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/tileentity/TileEntity; - -
 method protected setWorldCreate (Lnet/minecraft/world/World;)V - -
 method public getBlockMetadata ()I - -
 method public markDirty ()V - -
 method public getDistanceSq (DDD)D - -
 method public getMaxRenderDistanceSquared ()D - -
 method public getPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getBlockType ()Lnet/minecraft/block/Block; - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public isInvalid ()Z - -
 method public invalidate ()V - -
 method public validate ()V - -
 method public receiveClientEvent (II)Z - -
 method public updateContainingBlockInfo ()V - -
 method public addInfoToCrashReport (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public setPos (Lnet/minecraft/util/math/BlockPos;)V - -
 method public onlyOpsCanSetNbt ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public rotate (Lnet/minecraft/util/Rotation;)V - -
 method public mirror (Lnet/minecraft/util/Mirror;)V - -
 method public onDataPacket (Lnet/minecraft/network/NetworkManager;Lnet/minecraft/network/play/server/SPacketUpdateTileEntity;)V - -
 method public handleUpdateTag (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onChunkUnload ()V - -
 method public shouldRefresh (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/block/state/IBlockState;)Z - -
 method public shouldRenderInPass (I)Z - -
 method public getRenderBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public canRenderBreaking ()Z - -
 method public getTileData ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public restrictNBTCopy ()Z - -
 method public onLoad ()V - -
 method public hasFastRenderer ()Z - -
 method public <init> ()V - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 326
class net/minecraft/tileentity/TileEntity 52 public,super,abstract java/lang/Object net/minecraftforge/common/capabilities/ICapabilitySerializable Ljava/lang/Object;Lnet/minecraftforge/common/capabilities/ICapabilitySerializable<Lnet/minecraft/nbt/NBTTagCompound;>;
 inner net/minecraft/block/BlockJukebox$TileEntityJukebox net/minecraft/block/BlockJukebox TileEntityJukebox public,static
 field protected world Lnet/minecraft/world/World; -
 field protected pos Lnet/minecraft/util/math/BlockPos; -
 field protected tileEntityInvalid Z -
 field protected blockType Lnet/minecraft/block/Block; -
 field public,static,final INFINITE_EXTENT_AABB Lnet/minecraft/util/math/AxisAlignedBB; -
 method public,static register (Ljava/lang/String;Ljava/lang/Class;)V (Ljava/lang/String;Ljava/lang/Class<+Lnet/minecraft/tileentity/TileEntity;>;)V -
 method public,static getKey (Ljava/lang/Class;)Lnet/minecraft/util/ResourceLocation; (Ljava/lang/Class<+Lnet/minecraft/tileentity/TileEntity;>;)Lnet/minecraft/util/ResourceLocation; -
 method public getWorld ()Lnet/minecraft/world/World; - -
 method public setWorld (Lnet/minecraft/world/World;)V - -
 method public hasWorld ()Z - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static create (Lnet/minecraft/world/World;Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/tileentity/TileEntity; - -
 method protected setWorldCreate (Lnet/minecraft/world/World;)V - -
 method public getBlockMetadata ()I - -
 method public markDirty ()V - -
 method public getDistanceSq (DDD)D - -
 method public getMaxRenderDistanceSquared ()D - -
 method public getPos ()Lnet/minecraft/util/math/BlockPos; - -
 method public getBlockType ()Lnet/minecraft/block/Block; - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public isInvalid ()Z - -
 method public invalidate ()V - -
 method public validate ()V - -
 method public receiveClientEvent (II)Z - -
 method public updateContainingBlockInfo ()V - -
 method public addInfoToCrashReport (Lnet/minecraft/crash/CrashReportCategory;)V - -
 method public setPos (Lnet/minecraft/util/math/BlockPos;)V - -
 method public onlyOpsCanSetNbt ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public rotate (Lnet/minecraft/util/Rotation;)V - -
 method public mirror (Lnet/minecraft/util/Mirror;)V - -
 method public onDataPacket (Lnet/minecraft/network/NetworkManager;Lnet/minecraft/network/play/server/SPacketUpdateTileEntity;)V - -
 method public handleUpdateTag (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public onChunkUnload ()V - -
 method public shouldRefresh (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/block/state/IBlockState;)Z - -
 method public shouldRenderInPass (I)Z - -
 method public getRenderBoundingBox ()Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public canRenderBreaking ()Z - -
 method public getTileData ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public restrictNBTCopy ()Z - -
 method public onLoad ()V - -
 method public hasFastRenderer ()Z - -
 method public <init> ()V - -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public deserializeNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public serializeNBT ()Lnet/minecraft/nbt/NBTTagCompound; - -
in 90
class net/minecraft/tileentity/TileEntityBanner 50 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/tileentity/TileEntityBanner$EnumBannerPattern net/minecraft/tileentity/TileEntityBanner EnumBannerPattern public,static,final,enum
 method public getPatternList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern;>; -
 method public getColorList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/EnumDyeColor;>; -
 method public getPatternResourceLocation ()Ljava/lang/String; - -
 method public <init> ()V - -
 method public setItemValues (Lnet/minecraft/item/ItemStack;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public,static setBaseColorAndPatterns (Lnet/minecraft/nbt/NBTTagCompound;ILnet/minecraft/nbt/NBTTagList;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getDescriptionPacket ()Lnet/minecraft/network/Packet; - -
 method public getBaseColor ()I - -
 method public,static getBaseColor (Lnet/minecraft/item/ItemStack;)I - -
 method public,static getPatterns (Lnet/minecraft/item/ItemStack;)I - -
 method public getPatterns ()Lnet/minecraft/nbt/NBTTagList; - -
 method public,static removeBannerData (Lnet/minecraft/item/ItemStack;)V - -
in 91
class net/minecraft/tileentity/TileEntityBanner 50 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/tileentity/TileEntityBanner$EnumBannerPattern net/minecraft/tileentity/TileEntityBanner EnumBannerPattern public,static,final,enum
 method public getPatternList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern;>; -
 method public getColorList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/EnumDyeColor;>; -
 method public getPatternResourceLocation ()Ljava/lang/String; - -
 method public <init> ()V - -
 method public setItemValues (Lnet/minecraft/item/ItemStack;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static setBaseColorAndPatterns (Lnet/minecraft/nbt/NBTTagCompound;ILnet/minecraft/nbt/NBTTagList;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getBaseColor ()I - -
 method public,static getBaseColor (Lnet/minecraft/item/ItemStack;)I - -
 method public,static getPatterns (Lnet/minecraft/item/ItemStack;)I - -
 method public getPatterns ()Lnet/minecraft/nbt/NBTTagList; - -
 method public,static addBaseColorTag (Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/EnumDyeColor;)V - -
 method public,static removeBannerData (Lnet/minecraft/item/ItemStack;)V - -
in 326
class net/minecraft/tileentity/TileEntityBanner 52 public,super net/minecraft/tileentity/TileEntity net/minecraft/world/IWorldNameable -
 method public <init> ()V - -
 method public setItemValues (Lnet/minecraft/item/ItemStack;Z)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public,static getPatterns (Lnet/minecraft/item/ItemStack;)I - -
 method public getPatternList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/tileentity/BannerPattern;>; -
 method public getColorList ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/item/EnumDyeColor;>; -
 method public getPatternResourceLocation ()Ljava/lang/String; - -
 method public,static removeBannerData (Lnet/minecraft/item/ItemStack;)V - -
 method public getItem ()Lnet/minecraft/item/ItemStack; - -
 method public,static getColor (Lnet/minecraft/item/ItemStack;)Lnet/minecraft/item/EnumDyeColor; - -
in 24
class net/minecraft/tileentity/TileEntityBanner$EnumBannerPattern 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern;>;
 inner net/minecraft/tileentity/TileEntityBanner$EnumBannerPattern net/minecraft/tileentity/TileEntityBanner EnumBannerPattern public,static,final,enum
 inner net/minecraft/block/BlockFlower$EnumFlowerType net/minecraft/block/BlockFlower EnumFlowerType public,static,final,enum
 field public,static,final,enum BASE Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum SQUARE_BOTTOM_LEFT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum SQUARE_BOTTOM_RIGHT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum SQUARE_TOP_LEFT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum SQUARE_TOP_RIGHT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_BOTTOM Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_TOP Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_LEFT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_RIGHT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_CENTER Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_MIDDLE Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_DOWNRIGHT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_DOWNLEFT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRIPE_SMALL Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum CROSS Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum STRAIGHT_CROSS Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum TRIANGLE_BOTTOM Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum TRIANGLE_TOP Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum TRIANGLES_BOTTOM Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum TRIANGLES_TOP Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum DIAGONAL_LEFT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum DIAGONAL_RIGHT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum DIAGONAL_LEFT_MIRROR Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum DIAGONAL_RIGHT_MIRROR Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum CIRCLE_MIDDLE Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum RHOMBUS_MIDDLE Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum HALF_VERTICAL Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum HALF_HORIZONTAL Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum HALF_VERTICAL_MIRROR Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum HALF_HORIZONTAL_MIRROR Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum BORDER Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum CURLY_BORDER Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum CREEPER Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum GRADIENT Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum GRADIENT_UP Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum BRICKS Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum SKULL Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum FLOWER Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 field public,static,final,enum MOJANG Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; -
 method public getPatternName ()Ljava/lang/String; - -
 method public,static getPatternByID (Ljava/lang/String;)Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; - -
 method public,static values ()[Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/tileentity/TileEntityBanner$EnumBannerPattern; - -
 method public getPatternID ()Ljava/lang/String; - -
 method public getCraftingLayers ()[Ljava/lang/String; - -
 method public hasValidCrafting ()Z - -
 method public hasCraftingStack ()Z - -
 method public getCraftingStack ()Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/tileentity/TileEntityBeacon 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/IInventory -
 inner net/minecraft/tileentity/TileEntityBeacon$BeamSegment net/minecraft/tileentity/TileEntityBeacon BeamSegment public,static
 inner net/minecraft/util/BlockPos$MutableBlockPos net/minecraft/util/BlockPos MutableBlockPos public,static,final
 field public,static,final effectsList [[Lnet/minecraft/potion/Potion; -
 method public <init> ()V - -
 method public update ()V - -
 method public updateBeacon ()V - -
 method public getBeamSegments ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/tileentity/TileEntityBeacon$BeamSegment;>; -
 method public shouldBeamRender ()F - -
 method public getDescriptionPacket ()Lnet/minecraft/network/Packet; - -
 method public getMaxRenderDistanceSquared ()D - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setName (Ljava/lang/String;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public receiveClientEvent (II)Z - -
in 91
class net/minecraft/tileentity/TileEntityBeacon 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 inner net/minecraft/tileentity/TileEntityBeacon$BeamSegment net/minecraft/tileentity/TileEntityBeacon BeamSegment public,static
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 field public,static,final EFFECTS_LIST [[Lnet/minecraft/potion/Potion; -
 method public <init> ()V - -
 method public update ()V - -
 method public updateBeacon ()V - -
 method public getBeamSegments ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/tileentity/TileEntityBeacon$BeamSegment;>; -
 method public shouldBeamRender ()F - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getMaxRenderDistanceSquared ()D - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setName (Ljava/lang/String;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public receiveClientEvent (II)Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
in 326
class net/minecraft/tileentity/TileEntityBeacon 52 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 inner net/minecraft/tileentity/TileEntityBeacon$BeamSegment net/minecraft/tileentity/TileEntityBeacon BeamSegment public,static
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 field public,static,final EFFECTS_LIST [[Lnet/minecraft/potion/Potion; -
 method public <init> ()V - -
 method public update ()V - -
 method public updateBeacon ()V - -
 method public getBeamSegments ()Ljava/util/List; ()Ljava/util/List<Lnet/minecraft/tileentity/TileEntityBeacon$BeamSegment;>; -
 method public shouldBeamRender ()F - -
 method public getLevels ()I - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getMaxRenderDistanceSquared ()D - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setName (Ljava/lang/String;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public receiveClientEvent (II)Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
in 24
class net/minecraft/tileentity/TileEntityBeacon$BeamSegment 50 public,super java/lang/Object - -
 inner net/minecraft/tileentity/TileEntityBeacon$BeamSegment net/minecraft/tileentity/TileEntityBeacon BeamSegment public,static
 method public <init> ([F)V - -
 method protected incrementHeight ()V - -
 method public getColors ()[F - -
 method public getHeight ()I - -
in 326
class net/minecraft/tileentity/TileEntityBeacon$BeamSegment 52 public,super java/lang/Object - -
 inner net/minecraft/tileentity/TileEntityBeacon$BeamSegment net/minecraft/tileentity/TileEntityBeacon BeamSegment public,static
 method public <init> ([F)V - -
 method protected incrementHeight ()V - -
 method public getColors ()[F - -
 method public getHeight ()I - -
in 326
class net/minecraft/tileentity/TileEntityBed 52 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public setItemValues (Lnet/minecraft/item/ItemStack;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public setColor (Lnet/minecraft/item/EnumDyeColor;)V - -
 method public isHeadPiece ()Z - -
 method public getItemStack ()Lnet/minecraft/item/ItemStack; - -
in 90
class net/minecraft/tileentity/TileEntityBrewingStand 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setName (Ljava/lang/String;)V - -
 method public getSizeInventory ()I - -
 method public update ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public func_174902_m ()[Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
in 91
class net/minecraft/tileentity/TileEntityBrewingStand 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setName (Ljava/lang/String;)V - -
 method public getSizeInventory ()I - -
 method public update ()V - -
 method public createFilledSlotsArray ()[Z - -
 method public,static registerFixesBrewingStand (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 326
class net/minecraft/tileentity/TileEntityBrewingStand 52 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setName (Ljava/lang/String;)V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public update ()V - -
 method public createFilledSlotsArray ()[Z - -
 method public,static registerFixesBrewingStand (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 90
class net/minecraft/tileentity/TileEntityChest 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/IInventory -
 field public adjacentChestChecked Z -
 field public adjacentChestZNeg Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestXPos Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestXNeg Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestZPos Lnet/minecraft/tileentity/TileEntityChest; -
 field public lidAngle F -
 field public prevLidAngle F -
 field public numPlayersUsing I -
 field public doubleChestHandler Lnet/minecraftforge/items/VanillaDoubleChestItemHandler; -
 method public <init> ()V - -
 method public <init> (I)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public updateContainingBlockInfo ()V - -
 method public checkForAdjacentChests ()V - -
 method protected getAdjacentChest (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/tileentity/TileEntityChest; - -
 method public update ()V - -
 method public receiveClientEvent (II)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public invalidate ()V - -
 method public getChestType ()I - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public getSingleChestHandler ()Lnet/minecraftforge/items/IItemHandler; - -
in 91
class net/minecraft/tileentity/TileEntityChest 50 public,super net/minecraft/tileentity/TileEntityLockableLoot net/minecraft/util/ITickable,net/minecraft/inventory/IInventory -
 inner net/minecraft/block/BlockChest$Type net/minecraft/block/BlockChest Type public,static,final,enum
 field public adjacentChestChecked Z -
 field public adjacentChestZNeg Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestXPos Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestXNeg Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestZPos Lnet/minecraft/tileentity/TileEntityChest; -
 field public lidAngle F -
 field public prevLidAngle F -
 field public numPlayersUsing I -
 field public doubleChestHandler Lnet/minecraftforge/items/VanillaDoubleChestItemHandler; -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/block/BlockChest$Type;)V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public,static registerFixesChest (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public updateContainingBlockInfo ()V - -
 method public checkForAdjacentChests ()V - -
 method protected getAdjacentChest (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/tileentity/TileEntityChest; - -
 method public update ()V - -
 method public receiveClientEvent (II)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public invalidate ()V - -
 method public getChestType ()Lnet/minecraft/block/BlockChest$Type; - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public getSingleChestHandler ()Lnet/minecraftforge/items/IItemHandler; - -
in 326
class net/minecraft/tileentity/TileEntityChest 52 public,super net/minecraft/tileentity/TileEntityLockableLoot net/minecraft/util/ITickable -
 inner net/minecraft/block/BlockChest$Type net/minecraft/block/BlockChest Type public,static,final,enum
 field public adjacentChestChecked Z -
 field public adjacentChestZNeg Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestXPos Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestXNeg Lnet/minecraft/tileentity/TileEntityChest; -
 field public adjacentChestZPos Lnet/minecraft/tileentity/TileEntityChest; -
 field public lidAngle F -
 field public prevLidAngle F -
 field public numPlayersUsing I -
 field public doubleChestHandler Lnet/minecraftforge/items/VanillaDoubleChestItemHandler; -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/block/BlockChest$Type;)V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getName ()Ljava/lang/String; - -
 method public,static registerFixesChest (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getInventoryStackLimit ()I - -
 method public updateContainingBlockInfo ()V - -
 method public checkForAdjacentChests ()V - -
 method protected getAdjacentChest (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/tileentity/TileEntityChest; - -
 method public update ()V - -
 method public receiveClientEvent (II)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public getSingleChestHandler ()Lnet/minecraftforge/items/IItemHandler; - -
 method public invalidate ()V - -
 method public getChestType ()Lnet/minecraft/block/BlockChest$Type; - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method protected getItems ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/tileentity/TileEntityCommandBlock 50 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getDescriptionPacket ()Lnet/minecraft/network/Packet; - -
 method public func_183000_F ()Z - -
 method public getCommandBlockLogic ()Lnet/minecraft/command/server/CommandBlockLogic; - -
 method public getCommandResultStats ()Lnet/minecraft/command/CommandResultStats; - -
in 91
class net/minecraft/tileentity/TileEntityCommandBlock 50 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/tileentity/TileEntityCommandBlock$Mode net/minecraft/tileentity/TileEntityCommandBlock Mode public,static,final,enum
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public onlyOpsCanSetNbt ()Z - -
 method public getCommandBlockLogic ()Lnet/minecraft/tileentity/CommandBlockBaseLogic; - -
 method public getCommandResultStats ()Lnet/minecraft/command/CommandResultStats; - -
 method public setPowered (Z)V - -
 method public isPowered ()Z - -
 method public isAuto ()Z - -
 method public setAuto (Z)V - -
 method public isConditionMet ()Z - -
 method public setConditionMet (Z)V - -
 method public isSendToClient ()Z - -
 method public setSendToClient (Z)V - -
 method public getMode ()Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; - -
 method public isConditional ()Z - -
 method public validate ()V - -
in 326
class net/minecraft/tileentity/TileEntityCommandBlock 52 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/tileentity/TileEntityCommandBlock$Mode net/minecraft/tileentity/TileEntityCommandBlock Mode public,static,final,enum
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public onlyOpsCanSetNbt ()Z - -
 method public getCommandBlockLogic ()Lnet/minecraft/tileentity/CommandBlockBaseLogic; - -
 method public getCommandResultStats ()Lnet/minecraft/command/CommandResultStats; - -
 method public setPowered (Z)V - -
 method public isPowered ()Z - -
 method public isAuto ()Z - -
 method public setAuto (Z)V - -
 method public isConditionMet ()Z - -
 method public setConditionMet ()Z - -
 method public isSendToClient ()Z - -
 method public setSendToClient (Z)V - -
 method public getMode ()Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; - -
 method public isConditional ()Z - -
 method public validate ()V - -
in 91
class net/minecraft/tileentity/TileEntityCommandBlock$Mode 50 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode;>;
 inner net/minecraft/tileentity/TileEntityCommandBlock$Mode net/minecraft/tileentity/TileEntityCommandBlock Mode public,static,final,enum
 field public,static,final,enum SEQUENCE Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; -
 field public,static,final,enum AUTO Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; -
 field public,static,final,enum REDSTONE Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; -
 method public,static values ()[Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; - -
in 326
class net/minecraft/tileentity/TileEntityCommandBlock$Mode 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode;>;
 inner net/minecraft/tileentity/TileEntityCommandBlock$Mode net/minecraft/tileentity/TileEntityCommandBlock Mode public,static,final,enum
 field public,static,final,enum SEQUENCE Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; -
 field public,static,final,enum AUTO Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; -
 field public,static,final,enum REDSTONE Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; -
 method public,static values ()[Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/tileentity/TileEntityCommandBlock$Mode; - -
in 90
class net/minecraft/tileentity/TileEntityComparator 50 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getOutputSignal ()I - -
 method public setOutputSignal (I)V - -
in 91
class net/minecraft/tileentity/TileEntityComparator 50 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getOutputSignal ()I - -
 method public setOutputSignal (I)V - -
in 326
class net/minecraft/tileentity/TileEntityComparator 52 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getOutputSignal ()I - -
 method public setOutputSignal (I)V - -
in 24
class net/minecraft/tileentity/TileEntityDaylightDetector 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public update ()V - -
in 326
class net/minecraft/tileentity/TileEntityDaylightDetector 52 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public update ()V - -
in 90
class net/minecraft/tileentity/TileEntityDispenser 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/inventory/IInventory -
 field protected customName Ljava/lang/String; -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getDispenseSlot ()I - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public addItemStack (Lnet/minecraft/item/ItemStack;)I - -
 method public getName ()Ljava/lang/String; - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public hasCustomName ()Z - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 91
class net/minecraft/tileentity/TileEntityDispenser 50 public,super net/minecraft/tileentity/TileEntityLockableLoot net/minecraft/inventory/IInventory -
 field protected customName Ljava/lang/String; -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public getDispenseSlot ()I - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public addItemStack (Lnet/minecraft/item/ItemStack;)I - -
 method public getName ()Ljava/lang/String; - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public hasCustomName ()Z - -
 method public,static registerFixes (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
in 326
class net/minecraft/tileentity/TileEntityDispenser 52 public,super net/minecraft/tileentity/TileEntityLockableLoot - -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getDispenseSlot ()I - -
 method public addItemStack (Lnet/minecraft/item/ItemStack;)I - -
 method public getName ()Ljava/lang/String; - -
 method public,static registerFixes (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getInventoryStackLimit ()I - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method protected getItems ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/tileentity/TileEntityDropper 50 public,super net/minecraft/tileentity/TileEntityDispenser - -
 method public <init> ()V - -
 method public getName ()Ljava/lang/String; - -
 method public getGuiID ()Ljava/lang/String; - -
in 91
class net/minecraft/tileentity/TileEntityDropper 50 public,super net/minecraft/tileentity/TileEntityDispenser - -
 method public <init> ()V - -
 method public,static registerFixesDropper (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getGuiID ()Ljava/lang/String; - -
in 326
class net/minecraft/tileentity/TileEntityDropper 52 public,super net/minecraft/tileentity/TileEntityDispenser - -
 method public <init> ()V - -
 method public,static registerFixesDropper (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getGuiID ()Ljava/lang/String; - -
in 90
class net/minecraft/tileentity/TileEntityEnchantmentTable 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable,net/minecraft/world/IInteractionObject -
 field public tickCount I -
 field public pageFlip F -
 field public pageFlipPrev F -
 field public field_145932_k F -
 field public field_145929_l F -
 field public bookSpread F -
 field public bookSpreadPrev F -
 field public bookRotation F -
 field public bookRotationPrev F -
 field public field_145924_q F -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public update ()V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getGuiID ()Ljava/lang/String; - -
in 91
class net/minecraft/tileentity/TileEntityEnchantmentTable 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable,net/minecraft/world/IInteractionObject -
 field public tickCount I -
 field public pageFlip F -
 field public pageFlipPrev F -
 field public flipT F -
 field public flipA F -
 field public bookSpread F -
 field public bookSpreadPrev F -
 field public bookRotation F -
 field public bookRotationPrev F -
 field public tRot F -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public update ()V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getGuiID ()Ljava/lang/String; - -
in 326
class net/minecraft/tileentity/TileEntityEnchantmentTable 52 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable,net/minecraft/world/IInteractionObject -
 field public tickCount I -
 field public pageFlip F -
 field public pageFlipPrev F -
 field public flipT F -
 field public flipA F -
 field public bookSpread F -
 field public bookSpreadPrev F -
 field public bookRotation F -
 field public bookRotationPrev F -
 field public tRot F -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public update ()V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getGuiID ()Ljava/lang/String; - -
in 91
class net/minecraft/tileentity/TileEntityEndGateway 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 method public getMaxRenderDistanceSquared ()D - -
 method public getSpawnPercent ()F - -
 method public getCooldownPercent ()F - -
 method public shouldRenderFace (Lnet/minecraft/util/EnumFacing;)Z - -
 method public getParticleAmount ()I - -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public update ()V - -
 method public isSpawning ()Z - -
 method public isCoolingDown ()Z - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public triggerCooldown ()V - -
 method public receiveClientEvent (II)Z - -
 method public teleportEntity (Lnet/minecraft/entity/Entity;)V - -
in 326
class net/minecraft/tileentity/TileEntityEndGateway 52 public,super net/minecraft/tileentity/TileEntityEndPortal net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getMaxRenderDistanceSquared ()D - -
 method public update ()V - -
 method public isSpawning ()Z - -
 method public isCoolingDown ()Z - -
 method public getSpawnPercent (F)F - -
 method public getCooldownPercent (F)F - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public triggerCooldown ()V - -
 method public receiveClientEvent (II)Z - -
 method public teleportEntity (Lnet/minecraft/entity/Entity;)V - -
 method public shouldRenderFace (Lnet/minecraft/util/EnumFacing;)Z - -
 method public getParticleAmount ()I - -
 method public setExactPosition (Lnet/minecraft/util/math/BlockPos;)V - -
in 24
class net/minecraft/tileentity/TileEntityEndPortal 50 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
in 326
class net/minecraft/tileentity/TileEntityEndPortal 52 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public shouldRenderFace (Lnet/minecraft/util/EnumFacing;)Z - -
in 24
class net/minecraft/tileentity/TileEntityEnderChest 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 field public lidAngle F -
 field public prevLidAngle F -
 field public numPlayersUsing I -
 method public <init> ()V - -
 method public update ()V - -
 method public receiveClientEvent (II)Z - -
 method public invalidate ()V - -
 method public openChest ()V - -
 method public closeChest ()V - -
 method public canBeUsed (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 326
class net/minecraft/tileentity/TileEntityEnderChest 52 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 field public lidAngle F -
 field public prevLidAngle F -
 field public numPlayersUsing I -
 method public <init> ()V - -
 method public update ()V - -
 method public receiveClientEvent (II)Z - -
 method public invalidate ()V - -
 method public openChest ()V - -
 method public closeChest ()V - -
 method public canBeUsed (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
in 90
class net/minecraft/tileentity/TileEntityFlowerPot 50 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/item/Item;I)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getDescriptionPacket ()Lnet/minecraft/network/Packet; - -
 method public setFlowerPotData (Lnet/minecraft/item/Item;I)V - -
 method public getFlowerPotItem ()Lnet/minecraft/item/Item; - -
 method public getFlowerPotData ()I - -
in 91
class net/minecraft/tileentity/TileEntityFlowerPot 50 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/item/Item;I)V - -
 method public,static registerFixesFlowerPot (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public setFlowerPotData (Lnet/minecraft/item/Item;I)V - -
 method public getFlowerItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public getFlowerPotItem ()Lnet/minecraft/item/Item; - -
 method public getFlowerPotData ()I - -
in 326
class net/minecraft/tileentity/TileEntityFlowerPot 52 public,super net/minecraft/tileentity/TileEntity - -
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/item/Item;I)V - -
 method public,static registerFixesFlowerPot (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public setItemStack (Lnet/minecraft/item/ItemStack;)V - -
 method public getFlowerItemStack ()Lnet/minecraft/item/ItemStack; - -
 method public getFlowerPotItem ()Lnet/minecraft/item/Item; - -
 method public getFlowerPotData ()I - -
in 90
class net/minecraft/tileentity/TileEntityFurnace 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomInventoryName (Ljava/lang/String;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getInventoryStackLimit ()I - -
 method public isBurning ()Z - -
 method public,static isBurning (Lnet/minecraft/inventory/IInventory;)Z - -
 method public update ()V - -
 method public getCookTime (Lnet/minecraft/item/ItemStack;)I - -
 method public smeltItem ()V - -
 method public,static getItemBurnTime (Lnet/minecraft/item/ItemStack;)I - -
 method public,static isItemFuel (Lnet/minecraft/item/ItemStack;)Z - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
in 91
class net/minecraft/tileentity/TileEntityFurnace 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomInventoryName (Ljava/lang/String;)V - -
 method public,static registerFixesFurnace (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getInventoryStackLimit ()I - -
 method public isBurning ()Z - -
 method public,static isBurning (Lnet/minecraft/inventory/IInventory;)Z - -
 method public update ()V - -
 method public getCookTime (Lnet/minecraft/item/ItemStack;)I - -
 method public smeltItem ()V - -
 method public,static getItemBurnTime (Lnet/minecraft/item/ItemStack;)I - -
 method public,static isItemFuel (Lnet/minecraft/item/ItemStack;)Z - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
in 326
class net/minecraft/tileentity/TileEntityFurnace 52 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 method public <init> ()V - -
 method public getSizeInventory ()I - -
 method public isEmpty ()Z - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomInventoryName (Ljava/lang/String;)V - -
 method public,static registerFixesFurnace (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getInventoryStackLimit ()I - -
 method public isBurning ()Z - -
 method public,static isBurning (Lnet/minecraft/inventory/IInventory;)Z - -
 method public update ()V - -
 method public getCookTime (Lnet/minecraft/item/ItemStack;)I - -
 method public smeltItem ()V - -
 method public,static getItemBurnTime (Lnet/minecraft/item/ItemStack;)I - -
 method public,static isItemFuel (Lnet/minecraft/item/ItemStack;)Z - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
in 90
class net/minecraft/tileentity/TileEntityHopper 50 public,super net/minecraft/tileentity/TileEntityLockable net/minecraft/tileentity/IHopper,net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public markDirty ()V - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUseableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public update ()V - -
 method public updateHopper ()Z - -
 method public,static captureDroppedItems (Lnet/minecraft/tileentity/IHopper;)Z - -
 method public,static putDropInInventoryAllSlots (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/item/EntityItem;)Z - -
 method public,static putStackInInventoryAllSlots (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/item/ItemStack; - -
 method public,static getHopperInventory (Lnet/minecraft/tileentity/IHopper;)Lnet/minecraft/inventory/IInventory; - -
 method public,static func_181556_a (Lnet/minecraft/world/World;DDD)Ljava/util/List; (Lnet/minecraft/world/World;DDD)Ljava/util/List<Lnet/minecraft/entity/item/EntityItem;>; -
 method public,static getInventoryAtPosition (Lnet/minecraft/world/World;DDD)Lnet/minecraft/inventory/IInventory; - -
 method public getXPos ()D - -
 method public getYPos ()D - -
 method public getZPos ()D - -
 method public setTransferCooldown (I)V - -
 method public isOnTransferCooldown ()Z - -
 method public mayTransfer ()Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method protected createUnSidedHandler ()Lnet/minecraftforge/items/IItemHandler; - -
in 91
class net/minecraft/tileentity/TileEntityHopper 50 public,super net/minecraft/tileentity/TileEntityLockableLoot net/minecraft/tileentity/IHopper,net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public,static registerFixesHopper (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getSizeInventory ()I - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getInventoryStackLimit ()I - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public update ()V - -
 method public updateHopper ()Z - -
 method public,static captureDroppedItems (Lnet/minecraft/tileentity/IHopper;)Z - -
 method public,static putDropInInventoryAllSlots (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/item/EntityItem;)Z - -
 method public,static putStackInInventoryAllSlots (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/item/ItemStack; - -
 method public,static getHopperInventory (Lnet/minecraft/tileentity/IHopper;)Lnet/minecraft/inventory/IInventory; - -
 method public,static getCaptureItems (Lnet/minecraft/world/World;DDD)Ljava/util/List; (Lnet/minecraft/world/World;DDD)Ljava/util/List<Lnet/minecraft/entity/item/EntityItem;>; -
 method public,static getInventoryAtPosition (Lnet/minecraft/world/World;DDD)Lnet/minecraft/inventory/IInventory; - -
 method public getXPos ()D - -
 method public getYPos ()D - -
 method public getZPos ()D - -
 method public setTransferCooldown (I)V - -
 method public isOnTransferCooldown ()Z - -
 method public mayTransfer ()Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method protected createUnSidedHandler ()Lnet/minecraftforge/items/IItemHandler; - -
in 326
class net/minecraft/tileentity/TileEntityHopper 52 public,super net/minecraft/tileentity/TileEntityLockableLoot net/minecraft/tileentity/IHopper,net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public,static registerFixesHopper (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getSizeInventory ()I - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public getName ()Ljava/lang/String; - -
 method public getInventoryStackLimit ()I - -
 method public update ()V - -
 method protected updateHopper ()Z - -
 method public isEmpty ()Z - -
 method public,static pullItems (Lnet/minecraft/tileentity/IHopper;)Z - -
 method public,static putDropInInventoryAllSlots (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/entity/item/EntityItem;)Z - -
 method protected createUnSidedHandler ()Lnet/minecraftforge/items/IItemHandler; - -
 method public,static putStackInInventoryAllSlots (Lnet/minecraft/inventory/IInventory;Lnet/minecraft/inventory/IInventory;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/item/ItemStack; - -
 method public,static getSourceInventory (Lnet/minecraft/tileentity/IHopper;)Lnet/minecraft/inventory/IInventory; - -
 method public,static getCaptureItems (Lnet/minecraft/world/World;DDD)Ljava/util/List; (Lnet/minecraft/world/World;DDD)Ljava/util/List<Lnet/minecraft/entity/item/EntityItem;>; -
 method public,static getInventoryAtPosition (Lnet/minecraft/world/World;DDD)Lnet/minecraft/inventory/IInventory; - -
 method public getXPos ()D - -
 method public getYPos ()D - -
 method public getZPos ()D - -
 method public setTransferCooldown (I)V - -
 method public mayTransfer ()Z - -
 method public getGuiID ()Ljava/lang/String; - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method protected getItems ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public getLastUpdateTime ()J - -
in 90
class net/minecraft/tileentity/TileEntityLockable 50 public,super,abstract net/minecraft/tileentity/TileEntity net/minecraft/world/IInteractionObject,net/minecraft/world/ILockableContainer -
 method public <init> ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public isLocked ()Z - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getDisplayName ()Lnet/minecraft/util/IChatComponent; - -
 method protected createUnSidedHandler ()Lnet/minecraftforge/items/IItemHandler; - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
in 91
class net/minecraft/tileentity/TileEntityLockable 50 public,super,abstract net/minecraft/tileentity/TileEntity net/minecraft/world/IInteractionObject,net/minecraft/world/ILockableContainer -
 method public <init> ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public isLocked ()Z - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method protected createUnSidedHandler ()Lnet/minecraftforge/items/IItemHandler; - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
in 326
class net/minecraft/tileentity/TileEntityLockable 52 public,super,abstract net/minecraft/tileentity/TileEntity net/minecraft/world/ILockableContainer -
 method public <init> ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public isLocked ()Z - -
 method public getLockCode ()Lnet/minecraft/world/LockCode; - -
 method public setLockCode (Lnet/minecraft/world/LockCode;)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
 method protected createUnSidedHandler ()Lnet/minecraftforge/items/IItemHandler; - -
 method public getCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Ljava/lang/Object; <T:Ljava/lang/Object;>(Lnet/minecraftforge/common/capabilities/Capability<TT;>;Lnet/minecraft/util/EnumFacing;)TT; -
 method public hasCapability (Lnet/minecraftforge/common/capabilities/Capability;Lnet/minecraft/util/EnumFacing;)Z (Lnet/minecraftforge/common/capabilities/Capability<*>;Lnet/minecraft/util/EnumFacing;)Z -
in 91
class net/minecraft/tileentity/TileEntityLockableLoot 50 public,super,abstract net/minecraft/tileentity/TileEntityLockable net/minecraft/world/storage/loot/ILootContainer -
 inner net/minecraft/world/storage/loot/LootContext$Builder net/minecraft/world/storage/loot/LootContext Builder public,static
 field protected lootTable Lnet/minecraft/util/ResourceLocation; -
 field protected lootTableSeed J -
 method public <init> ()V - -
 method protected checkLootAndRead (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method protected checkLootAndWrite (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method protected fillWithLoot (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public setLootTable (Lnet/minecraft/util/ResourceLocation;J)V - -
in 326
class net/minecraft/tileentity/TileEntityLockableLoot 52 public,super,abstract net/minecraft/tileentity/TileEntityLockable net/minecraft/world/storage/loot/ILootContainer -
 inner net/minecraft/world/storage/loot/LootContext$Builder net/minecraft/world/storage/loot/LootContext Builder public,static
 field protected lootTable Lnet/minecraft/util/ResourceLocation; -
 field protected lootTableSeed J -
 field protected customName Ljava/lang/String; -
 method public <init> ()V - -
 method protected checkLootAndRead (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method protected checkLootAndWrite (Lnet/minecraft/nbt/NBTTagCompound;)Z - -
 method public fillWithLoot (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getLootTable ()Lnet/minecraft/util/ResourceLocation; - -
 method public setLootTable (Lnet/minecraft/util/ResourceLocation;J)V - -
 method public hasCustomName ()Z - -
 method public setCustomName (Ljava/lang/String;)V - -
 method public getStackInSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public decrStackSize (II)Lnet/minecraft/item/ItemStack; - -
 method public removeStackFromSlot (I)Lnet/minecraft/item/ItemStack; - -
 method public setInventorySlotContents (ILnet/minecraft/item/ItemStack;)V - -
 method public isUsableByPlayer (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public isItemValidForSlot (ILnet/minecraft/item/ItemStack;)Z - -
 method public getField (I)I - -
 method public setField (II)V - -
 method public getFieldCount ()I - -
 method public clear ()V - -
 method protected,abstract getItems ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
in 90
class net/minecraft/tileentity/TileEntityMobSpawner 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public update ()V - -
 method public getDescriptionPacket ()Lnet/minecraft/network/Packet; - -
 method public receiveClientEvent (II)Z - -
 method public func_183000_F ()Z - -
 method public getSpawnerBaseLogic ()Lnet/minecraft/tileentity/MobSpawnerBaseLogic; - -
in 91
class net/minecraft/tileentity/TileEntityMobSpawner 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public,static registerFixesMobSpawner (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public update ()V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public receiveClientEvent (II)Z - -
 method public onlyOpsCanSetNbt ()Z - -
 method public getSpawnerBaseLogic ()Lnet/minecraft/tileentity/MobSpawnerBaseLogic; - -
in 326
class net/minecraft/tileentity/TileEntityMobSpawner 52 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public,static registerFixesMobSpawner (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public update ()V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public receiveClientEvent (II)Z - -
 method public onlyOpsCanSetNbt ()Z - -
 method public getSpawnerBaseLogic ()Lnet/minecraft/tileentity/MobSpawnerBaseLogic; - -
in 90
class net/minecraft/tileentity/TileEntityNote 50 public,super net/minecraft/tileentity/TileEntity - -
 field public note B -
 field public previousRedstoneState Z -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public changePitch ()V - -
 method public triggerNote (Lnet/minecraft/world/World;Lnet/minecraft/util/BlockPos;)V - -
in 91
class net/minecraft/tileentity/TileEntityNote 50 public,super net/minecraft/tileentity/TileEntity - -
 field public note B -
 field public previousRedstoneState Z -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public changePitch ()V - -
 method public triggerNote (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
in 326
class net/minecraft/tileentity/TileEntityNote 52 public,super net/minecraft/tileentity/TileEntity - -
 field public note B -
 field public previousRedstoneState Z -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public changePitch ()V - -
 method public triggerNote (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)V - -
in 90
class net/minecraft/tileentity/TileEntityPiston 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 inner net/minecraftforge/event/world/BlockEvent$NeighborNotifyEvent net/minecraftforge/event/world/BlockEvent NeighborNotifyEvent public,static
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/EnumFacing;ZZ)V - -
 method public getPistonState ()Lnet/minecraft/block/state/IBlockState; - -
 method public getBlockMetadata ()I - -
 method public isExtending ()Z - -
 method public getFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public shouldPistonHeadBeRendered ()Z - -
 method public getProgress (F)F - -
 method public getOffsetX (F)F - -
 method public getOffsetY (F)F - -
 method public getOffsetZ (F)F - -
 method public clearPistonTileEntity ()V - -
 method public update ()V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
in 91
class net/minecraft/tileentity/TileEntityPiston 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 inner net/minecraft/util/EnumFacing$AxisDirection net/minecraft/util/EnumFacing AxisDirection public,static,final,enum
 inner net/minecraftforge/event/world/BlockEvent$NeighborNotifyEvent net/minecraftforge/event/world/BlockEvent NeighborNotifyEvent public,static
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/EnumFacing;ZZ)V - -
 method public getPistonState ()Lnet/minecraft/block/state/IBlockState; - -
 method public getBlockMetadata ()I - -
 method public isExtending ()Z - -
 method public getFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public shouldPistonHeadBeRendered ()Z - -
 method public getProgress (F)F - -
 method public getOffsetX (F)F - -
 method public getOffsetY (F)F - -
 method public getOffsetZ (F)F - -
 method public getAABB (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getAABB (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;F)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public clearPistonTileEntity ()V - -
 method public update ()V - -
 method public,static registerFixesPiston (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
in 326
class net/minecraft/tileentity/TileEntityPiston 52 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 inner net/minecraft/block/BlockPistonExtension$EnumPistonType net/minecraft/block/BlockPistonExtension EnumPistonType public,static,final,enum
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 inner net/minecraft/util/EnumFacing$AxisDirection net/minecraft/util/EnumFacing AxisDirection public,static,final,enum
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/block/state/IBlockState;Lnet/minecraft/util/EnumFacing;ZZ)V - -
 method public getPistonState ()Lnet/minecraft/block/state/IBlockState; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public getBlockMetadata ()I - -
 method public isExtending ()Z - -
 method public getFacing ()Lnet/minecraft/util/EnumFacing; - -
 method public shouldPistonHeadBeRendered ()Z - -
 method public getProgress (F)F - -
 method public getOffsetX (F)F - -
 method public getOffsetY (F)F - -
 method public getOffsetZ (F)F - -
 method public getAABB (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getAABB (Lnet/minecraft/world/IBlockAccess;Lnet/minecraft/util/math/BlockPos;F)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public clearPistonTileEntity ()V - -
 method public update ()V - -
 method public,static registerFixesPiston (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public addCollissionAABBs (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/AxisAlignedBB;Ljava/util/List;Lnet/minecraft/entity/Entity;)V (Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/AxisAlignedBB;Ljava/util/List<Lnet/minecraft/util/math/AxisAlignedBB;>;Lnet/minecraft/entity/Entity;)V -
in 326
class net/minecraft/tileentity/TileEntityShulkerBox 52 public,super net/minecraft/tileentity/TileEntityLockableLoot net/minecraft/util/ITickable,net/minecraft/inventory/ISidedInventory -
 inner net/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus net/minecraft/tileentity/TileEntityShulkerBox AnimationStatus public,static,final,enum
 inner net/minecraft/util/EnumFacing$Axis net/minecraft/util/EnumFacing Axis public,static,final,enum
 inner net/minecraft/util/EnumFacing$AxisDirection net/minecraft/util/EnumFacing AxisDirection public,static,final,enum
 method public <init> ()V - -
 method public <init> (Lnet/minecraft/item/EnumDyeColor;)V - -
 method public update ()V - -
 method protected updateAnimation ()V - -
 method public getAnimationStatus ()Lnet/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus; - -
 method public getBoundingBox (Lnet/minecraft/block/state/IBlockState;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getBoundingBox (Lnet/minecraft/util/EnumFacing;)Lnet/minecraft/util/math/AxisAlignedBB; - -
 method public getSizeInventory ()I - -
 method public getInventoryStackLimit ()I - -
 method public receiveClientEvent (II)Z - -
 method public openInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public closeInventory (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public createContainer (Lnet/minecraft/entity/player/InventoryPlayer;Lnet/minecraft/entity/player/EntityPlayer;)Lnet/minecraft/inventory/Container; - -
 method public getGuiID ()Ljava/lang/String; - -
 method public getName ()Ljava/lang/String; - -
 method public,static registerFixesShulkerBox (Lnet/minecraft/util/datafix/DataFixer;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public loadFromNbt (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public saveToNbt (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method protected getItems ()Lnet/minecraft/util/NonNullList; ()Lnet/minecraft/util/NonNullList<Lnet/minecraft/item/ItemStack;>; -
 method public isEmpty ()Z - -
 method public getSlotsForFace (Lnet/minecraft/util/EnumFacing;)[I - -
 method public canInsertItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public canExtractItem (ILnet/minecraft/item/ItemStack;Lnet/minecraft/util/EnumFacing;)Z - -
 method public clear ()V - -
 method public isCleared ()Z - -
 method public getProgress (F)F - -
 method public getColor ()Lnet/minecraft/item/EnumDyeColor; - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public isDestroyedByCreativePlayer ()Z - -
 method public setDestroyedByCreativePlayer (Z)V - -
 method public shouldDrop ()Z - -
 method protected createUnSidedHandler ()Lnet/minecraftforge/items/IItemHandler; - -
in 326
class net/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus 52 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus;>;
 inner net/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus net/minecraft/tileentity/TileEntityShulkerBox AnimationStatus public,static,final,enum
 field public,static,final,enum CLOSED Lnet/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus; -
 field public,static,final,enum OPENING Lnet/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus; -
 field public,static,final,enum OPENED Lnet/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus; -
 field public,static,final,enum CLOSING Lnet/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus; -
 method public,static values ()[Lnet/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/tileentity/TileEntityShulkerBox$AnimationStatus; - -
in 90
class net/minecraft/tileentity/TileEntitySign 50 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/util/IChatComponent$Serializer net/minecraft/util/IChatComponent Serializer public,static
 inner net/minecraft/event/ClickEvent$Action net/minecraft/event/ClickEvent Action public,static,final,enum
 field public,final signText [Lnet/minecraft/util/IChatComponent; -
 field public lineBeingEdited I -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getDescriptionPacket ()Lnet/minecraft/network/Packet; - -
 method public func_183000_F ()Z - -
 method public getIsEditable ()Z - -
 method public setEditable (Z)V - -
 method public setPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getPlayer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public executeCommand (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getStats ()Lnet/minecraft/command/CommandResultStats; - -
in 91
class net/minecraft/tileentity/TileEntitySign 50 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 inner net/minecraft/util/text/event/ClickEvent$Action net/minecraft/util/text/event/ClickEvent Action public,static,final,enum
 field public,final signText [Lnet/minecraft/util/text/ITextComponent; -
 field public lineBeingEdited I -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method protected setWorldCreate (Lnet/minecraft/world/World;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public onlyOpsCanSetNbt ()Z - -
 method public getIsEditable ()Z - -
 method public setEditable (Z)V - -
 method public setPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getPlayer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public executeCommand (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getStats ()Lnet/minecraft/command/CommandResultStats; - -
in 326
class net/minecraft/tileentity/TileEntitySign 52 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/util/text/ITextComponent$Serializer net/minecraft/util/text/ITextComponent Serializer public,static
 inner net/minecraft/util/text/event/ClickEvent$Action net/minecraft/util/text/event/ClickEvent Action public,static,final,enum
 field public,final signText [Lnet/minecraft/util/text/ITextComponent; -
 field public lineBeingEdited I -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method protected setWorldCreate (Lnet/minecraft/world/World;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public onlyOpsCanSetNbt ()Z - -
 method public getIsEditable ()Z - -
 method public setEditable (Z)V - -
 method public setPlayer (Lnet/minecraft/entity/player/EntityPlayer;)V - -
 method public getPlayer ()Lnet/minecraft/entity/player/EntityPlayer; - -
 method public executeCommand (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getStats ()Lnet/minecraft/command/CommandResultStats; - -
in 90
class net/minecraft/tileentity/TileEntitySkull 50 public,super net/minecraft/tileentity/TileEntity - -
 method public getSkullRotation ()I - -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getPlayerProfile ()Lcom/mojang/authlib/GameProfile; - -
 method public getDescriptionPacket ()Lnet/minecraft/network/Packet; - -
 method public setType (I)V - -
 method public setPlayerProfile (Lcom/mojang/authlib/GameProfile;)V - -
 method public,static updateGameprofile (Lcom/mojang/authlib/GameProfile;)Lcom/mojang/authlib/GameProfile; - -
 method public getSkullType ()I - -
 method public setSkullRotation (I)V - -
in 91
class net/minecraft/tileentity/TileEntitySkull 50 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 method public getAnimationProgress (F)F - -
 method public getSkullRotation ()I - -
 method public <init> ()V - -
 method public,static setProfileCache (Lnet/minecraft/server/management/PlayerProfileCache;)V - -
 method public,static setSessionService (Lcom/mojang/authlib/minecraft/MinecraftSessionService;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public update ()V - -
 method public getPlayerProfile ()Lcom/mojang/authlib/GameProfile; - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public setType (I)V - -
 method public setPlayerProfile (Lcom/mojang/authlib/GameProfile;)V - -
 method public,static updateGameprofile (Lcom/mojang/authlib/GameProfile;)Lcom/mojang/authlib/GameProfile; - -
 method public getSkullType ()I - -
 method public setSkullRotation (I)V - -
 method public mirror (Lnet/minecraft/util/Mirror;)V - -
 method public rotate (Lnet/minecraft/util/Rotation;)V - -
in 326
class net/minecraft/tileentity/TileEntitySkull 52 public,super net/minecraft/tileentity/TileEntity net/minecraft/util/ITickable -
 method public <init> ()V - -
 method public,static setProfileCache (Lnet/minecraft/server/management/PlayerProfileCache;)V - -
 method public,static setSessionService (Lcom/mojang/authlib/minecraft/MinecraftSessionService;)V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public update ()V - -
 method public getAnimationProgress (F)F - -
 method public getPlayerProfile ()Lcom/mojang/authlib/GameProfile; - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public setType (I)V - -
 method public setPlayerProfile (Lcom/mojang/authlib/GameProfile;)V - -
 method public,static updateGameProfile (Lcom/mojang/authlib/GameProfile;)Lcom/mojang/authlib/GameProfile; - -
 method public getSkullType ()I - -
 method public getSkullRotation ()I - -
 method public setSkullRotation (I)V - -
 method public mirror (Lnet/minecraft/util/Mirror;)V - -
 method public rotate (Lnet/minecraft/util/Rotation;)V - -
in 91
class net/minecraft/tileentity/TileEntityStructure 50 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/tileentity/TileEntityStructure$Mode net/minecraft/tileentity/TileEntityStructure Mode public,static,final,enum
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public getStructureSize ()Lnet/minecraft/util/math/BlockPos; - -
 method public getMirror ()Lnet/minecraft/util/Mirror; - -
 method public getRotation ()Lnet/minecraft/util/Rotation; - -
 method public getMetadata ()Ljava/lang/String; - -
 method public nextMode ()V - -
 method public ignoresEntities ()Z - -
 method public getIntegrity ()F - -
 method public getSeed ()J - -
 method public writeCoordinates (Lio/netty/buffer/ByteBuf;)V - -
 method public showsAir ()Z - -
 method public showsBoundingBox ()Z - -
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public usedBy (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public createdBy (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public setPosition (Lnet/minecraft/util/math/BlockPos;)V - -
 method public setSize (Lnet/minecraft/util/math/BlockPos;)V - -
 method public setMirror (Lnet/minecraft/util/Mirror;)V - -
 method public setRotation (Lnet/minecraft/util/Rotation;)V - -
 method public setMetadata (Ljava/lang/String;)V - -
 method public getMode ()Lnet/minecraft/tileentity/TileEntityStructure$Mode; - -
 method public setMode (Lnet/minecraft/tileentity/TileEntityStructure$Mode;)V - -
 method public setIgnoresEntities (Z)V - -
 method public setIntegrity (F)V - -
 method public setSeed (J)V - -
 method public detectSize ()Z - -
 method public save ()Z - -
 method public save (Z)Z - -
 method public load ()Z - -
 method public load (Z)Z - -
 method public unloadStructure ()V - -
 method public isStructureLoadable ()Z - -
 method public isPowered ()Z - -
 method public setPowered (Z)V - -
 method public setShowAir (Z)V - -
 method public setShowBoundingBox (Z)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
in 326
class net/minecraft/tileentity/TileEntityStructure 52 public,super net/minecraft/tileentity/TileEntity - -
 inner net/minecraft/tileentity/TileEntityStructure$Mode net/minecraft/tileentity/TileEntityStructure Mode public,static,final,enum
 inner net/minecraft/util/math/BlockPos$MutableBlockPos net/minecraft/util/math/BlockPos MutableBlockPos public,static
 method public <init> ()V - -
 method public writeToNBT (Lnet/minecraft/nbt/NBTTagCompound;)Lnet/minecraft/nbt/NBTTagCompound; - -
 method public readFromNBT (Lnet/minecraft/nbt/NBTTagCompound;)V - -
 method public getUpdatePacket ()Lnet/minecraft/network/play/server/SPacketUpdateTileEntity; - -
 method public getUpdateTag ()Lnet/minecraft/nbt/NBTTagCompound; - -
 method public usedBy (Lnet/minecraft/entity/player/EntityPlayer;)Z - -
 method public getName ()Ljava/lang/String; - -
 method public setName (Ljava/lang/String;)V - -
 method public createdBy (Lnet/minecraft/entity/EntityLivingBase;)V - -
 method public getPosition ()Lnet/minecraft/util/math/BlockPos; - -
 method public setPosition (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getStructureSize ()Lnet/minecraft/util/math/BlockPos; - -
 method public setSize (Lnet/minecraft/util/math/BlockPos;)V - -
 method public getMirror ()Lnet/minecraft/util/Mirror; - -
 method public setMirror (Lnet/minecraft/util/Mirror;)V - -
 method public setRotation (Lnet/minecraft/util/Rotation;)V - -
 method public setMetadata (Ljava/lang/String;)V - -
 method public getRotation ()Lnet/minecraft/util/Rotation; - -
 method public getMetadata ()Ljava/lang/String; - -
 method public getMode ()Lnet/minecraft/tileentity/TileEntityStructure$Mode; - -
 method public setMode (Lnet/minecraft/tileentity/TileEntityStructure$Mode;)V - -
 method public setIgnoresEntities (Z)V - -
 method public setIntegrity (F)V - -
 method public setSeed (J)V - -
 method public nextMode ()V - -
 method public ignoresEntities ()Z - -
 method public getIntegrity ()F - -
 method public getSeed ()J - -
 method public detectSize ()Z - -
 method public writeCoordinates (Lio/netty/buffer/ByteBuf;)V - -
 method public save ()Z - -
 method public save (Z)Z - -
 method public load ()Z - -
 method public load (Z)Z - -
 method public unloadStructure ()V - -
 method public isStructureLoadable ()Z - -
 method public isPowered ()Z - -
 method public setPowered (Z)V - -
 method public showsAir ()Z - -
 method public setShowAir (Z)V - -
 method public showsBoundingBox ()Z - -
 method public setShowBoundingBox (Z)V - -
 method public getDisplayName ()Lnet/minecraft/util/text/ITextComponent; - -
in 91
class net/minecraft/tileentity/TileEntityStructure$Mode 50 public,final,super,enum java/lang/Enum net/minecraft/util/IStringSerializable Ljava/lang/Enum<Lnet/minecraft/tileentity/TileEntityStructure$Mode;>;Lnet/minecraft/util/IStringSerializable;
 inner net/minecraft/tileentity/TileEntityStructure$Mode net/minecraft/tileentity/TileEntityStructure Mode public,static,final,enum
 field public,static,final,enum SAVE Lnet/minecraft/tileentity/TileEntityStructure$Mode; -
 field public,static,final,enum LOAD Lnet/minecraft/tileentity/TileEntityStructure$Mode; -
 field public,static,final,enum CORNER Lnet/minecraft/tileentity/TileEntityStructure$Mode; -
 field public,static,final,enum DATA Lnet/minecraft/tileentity/TileEntityStructure$Mode; -
 method public,static values ()[Lnet/minecraft/tileentity/TileEntityStructure$Mode; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/tileentity/TileEntityStructure$Mode; - -
 method public getName ()Ljava/lang/String; - -
 method public getModeId ()I - -
 method public,static getById (I)Lnet/minecraft/tileentity/TileEntityStructure$Mode; - -
in 326
class net/minecraft/tileentity/TileEntityStructure$Mode 52 public,final,super,enum java/lang/Enum net/minecraft/util/IStringSerializable Ljava/lang/Enum<Lnet/minecraft/tileentity/TileEntityStructure$Mode;>;Lnet/minecraft/util/IStringSerializable;
 inner net/minecraft/tileentity/TileEntityStructure$Mode net/minecraft/tileentity/TileEntityStructure Mode public,static,final,enum
 field public,static,final,enum SAVE Lnet/minecraft/tileentity/TileEntityStructure$Mode; -
 field public,static,final,enum LOAD Lnet/minecraft/tileentity/TileEntityStructure$Mode; -
 field public,static,final,enum CORNER Lnet/minecraft/tileentity/TileEntityStructure$Mode; -
 field public,static,final,enum DATA Lnet/minecraft/tileentity/TileEntityStructure$Mode; -
 method public,static values ()[Lnet/minecraft/tileentity/TileEntityStructure$Mode; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/minecraft/tileentity/TileEntityStructure$Mode; - -
 method public getName ()Ljava/lang/String; - -
 method public getModeId ()I - -
 method public,static getById (I)Lnet/minecraft/tileentity/TileEntityStructure$Mode; - -
