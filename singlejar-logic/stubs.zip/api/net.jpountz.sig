cg-stub-db 1
in 60
class net/jpountz/lz4/LZ4BlockInputStream 51 public,super java/io/FilterInputStream - -
 method public <init> (Ljava/io/InputStream;Lnet/jpountz/lz4/LZ4FastDecompressor;Ljava/util/zip/Checksum;Z)V - -
 method public <init> (Ljava/io/InputStream;Lnet/jpountz/lz4/LZ4FastDecompressor;Ljava/util/zip/Checksum;)V - -
 method public <init> (Ljava/io/InputStream;Lnet/jpountz/lz4/LZ4FastDecompressor;)V - -
 method public <init> (Ljava/io/InputStream;Z)V - -
 method public <init> (Ljava/io/InputStream;)V - -
 method public available ()I - java/io/IOException
 method public read ()I - java/io/IOException
 method public read ([BII)I - java/io/IOException
 method public read ([B)I - java/io/IOException
 method public skip (J)J - java/io/IOException
 method public markSupported ()Z - -
 method public mark (I)V - -
 method public reset ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/lz4/LZ4BlockOutputStream 51 public,super java/io/FilterOutputStream - -
 method public <init> (Ljava/io/OutputStream;ILnet/jpountz/lz4/LZ4Compressor;Ljava/util/zip/Checksum;Z)V - -
 method public <init> (Ljava/io/OutputStream;ILnet/jpountz/lz4/LZ4Compressor;)V - -
 method public <init> (Ljava/io/OutputStream;I)V - -
 method public <init> (Ljava/io/OutputStream;)V - -
 method public write (I)V - java/io/IOException
 method public write ([BII)V - java/io/IOException
 method public write ([B)V - java/io/IOException
 method public close ()V - java/io/IOException
 method public flush ()V - java/io/IOException
 method public finish ()V - java/io/IOException
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/lz4/LZ4ByteBufferUtils 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/lz4/LZ4ByteBufferUtils;>;
 inner net/jpountz/lz4/LZ4ByteBufferUtils$Match net/jpountz/lz4/LZ4ByteBufferUtils Match static
 method public,static values ()[Lnet/jpountz/lz4/LZ4ByteBufferUtils; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/lz4/LZ4ByteBufferUtils; - -
in 60
class net/jpountz/lz4/LZ4ByteBufferUtils$Match 51 super java/lang/Object - -
 inner net/jpountz/lz4/LZ4ByteBufferUtils$Match net/jpountz/lz4/LZ4ByteBufferUtils Match static
in 60
class net/jpountz/lz4/LZ4Compressor 51 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,final maxCompressedLength (I)I - -
 method public,abstract compress ([BII[BII)I - -
 method public,abstract compress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
 method public,final compress ([BII[BI)I - -
 method public,final compress ([B[B)I - -
 method public,final compress ([BII)[B - -
 method public,final compress ([B)[B - -
 method public,final compress (Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;)V - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/lz4/LZ4CompressorWithLength 51 public,super java/lang/Object - -
 method public <init> (Lnet/jpountz/lz4/LZ4Compressor;)V - -
 method public maxCompressedLength (I)I - -
 method public compress ([B)[B - -
 method public compress ([BII)[B - -
 method public compress ([B[B)I - -
 method public compress ([BII[BI)I - -
 method public compress ([BII[BII)I - -
 method public compress (Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;)V - -
 method public compress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4Constants 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/lz4/LZ4Constants;>;
 method public,static values ()[Lnet/jpountz/lz4/LZ4Constants; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/lz4/LZ4Constants; - -
in 60
class net/jpountz/lz4/LZ4Decompressor 51 public,interface,abstract,deprecated java/lang/Object - -
 method public,abstract decompress ([BI[BII)I - -
in 60
class net/jpountz/lz4/LZ4DecompressorWithLength 51 public,super java/lang/Object - -
 method public,static getDecompressedLength ([B)I - -
 method public,static getDecompressedLength ([BI)I - -
 method public,static getDecompressedLength (Ljava/nio/ByteBuffer;)I - -
 method public,static getDecompressedLength (Ljava/nio/ByteBuffer;I)I - -
 method public <init> (Lnet/jpountz/lz4/LZ4FastDecompressor;)V - -
 method public <init> (Lnet/jpountz/lz4/LZ4SafeDecompressor;)V - -
 method public decompress ([B[B)I - -
 method public decompress ([BI[BI)I - -
 method public decompress ([BII[BI)I - -
 method public decompress ([B)[B - -
 method public decompress ([BI)[B - -
 method public decompress ([BII)[B - -
 method public decompress (Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;)V - -
 method public decompress (Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;I)I - -
 method public decompress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;I)I - -
in 60
class net/jpountz/lz4/LZ4Exception 51 public,super java/lang/RuntimeException - -
 method public <init> (Ljava/lang/String;Ljava/lang/Throwable;)V - -
 method public <init> (Ljava/lang/String;)V - -
 method public <init> ()V - -
in 95
class net/jpountz/lz4/LZ4Factory 51 public,final,super java/lang/Object - -
 method public,static,synchronized nativeInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static,synchronized safeInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static,synchronized unsafeInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static fastestJavaInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static fastestInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public fastCompressor ()Lnet/jpountz/lz4/LZ4Compressor; - -
 method public highCompressor ()Lnet/jpountz/lz4/LZ4Compressor; - -
 method public highCompressor (I)Lnet/jpountz/lz4/LZ4Compressor; - -
 method public fastDecompressor ()Lnet/jpountz/lz4/LZ4FastDecompressor; - -
 method public safeDecompressor ()Lnet/jpountz/lz4/LZ4SafeDecompressor; - -
 method public,deprecated unknownSizeDecompressor ()Lnet/jpountz/lz4/LZ4UnknownSizeDecompressor; - -
 method public,deprecated decompressor ()Lnet/jpountz/lz4/LZ4Decompressor; - -
 method public,static main ([Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
in 2
class net/jpountz/lz4/LZ4Factory 51 public,final,super java/lang/Object - -
 method public,static,synchronized nativeInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static,synchronized,deprecated nativeInsecureInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static,synchronized safeInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static,synchronized,deprecated unsafeInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static,synchronized,deprecated unsafeInsecureInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static fastestJavaInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public,static fastestInstance ()Lnet/jpountz/lz4/LZ4Factory; - -
 method public fastCompressor ()Lnet/jpountz/lz4/LZ4Compressor; - -
 method public highCompressor ()Lnet/jpountz/lz4/LZ4Compressor; - -
 method public highCompressor (I)Lnet/jpountz/lz4/LZ4Compressor; - -
 method public fastDecompressor ()Lnet/jpountz/lz4/LZ4FastDecompressor; - -
 method public safeDecompressor ()Lnet/jpountz/lz4/LZ4SafeDecompressor; - -
 method public,deprecated unknownSizeDecompressor ()Lnet/jpountz/lz4/LZ4UnknownSizeDecompressor; - -
 method public,deprecated decompressor ()Lnet/jpountz/lz4/LZ4Decompressor; - -
 method public,static main ([Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/lz4/LZ4FastDecompressor 51 public,super,abstract java/lang/Object net/jpountz/lz4/LZ4Decompressor -
 method public <init> ()V - -
 method public,abstract decompress ([BI[BII)I - -
 method public,abstract decompress (Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;II)I - -
 method public,final decompress ([B[BI)I - -
 method public,final decompress ([B[B)I - -
 method public,final decompress ([BII)[B - -
 method public,final decompress ([BI)[B - -
 method public,final decompress (Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;)V - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/lz4/LZ4FrameInputStream 51 public,super java/io/FilterInputStream - -
 inner net/jpountz/lz4/LZ4FrameOutputStream$FrameInfo net/jpountz/lz4/LZ4FrameOutputStream FrameInfo static
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG net/jpountz/lz4/LZ4FrameOutputStream FLG public,static
 inner net/jpountz/lz4/LZ4FrameOutputStream$BD net/jpountz/lz4/LZ4FrameOutputStream BD public,static
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits net/jpountz/lz4/LZ4FrameOutputStream$FLG Bits public,static,final,enum
 method public <init> (Ljava/io/InputStream;)V - java/io/IOException
 method public <init> (Ljava/io/InputStream;Z)V - java/io/IOException
 method public <init> (Ljava/io/InputStream;Lnet/jpountz/lz4/LZ4SafeDecompressor;Lnet/jpountz/xxhash/XXHash32;)V - java/io/IOException
 method public <init> (Ljava/io/InputStream;Lnet/jpountz/lz4/LZ4SafeDecompressor;Lnet/jpountz/xxhash/XXHash32;Z)V - java/io/IOException
 method public read ()I - java/io/IOException
 method public read ([BII)I - java/io/IOException
 method public skip (J)J - java/io/IOException
 method public available ()I - java/io/IOException
 method public close ()V - java/io/IOException
 method public,synchronized mark (I)V - -
 method public,synchronized reset ()V - java/io/IOException
 method public markSupported ()Z - -
 method public getExpectedContentSize ()J - java/io/IOException
 method public isExpectedContentSizeDefined ()Z - java/io/IOException
in 60
class net/jpountz/lz4/LZ4FrameOutputStream 51 public,super java/io/FilterOutputStream - -
 inner net/jpountz/lz4/LZ4FrameOutputStream$FrameInfo net/jpountz/lz4/LZ4FrameOutputStream FrameInfo static
 inner net/jpountz/lz4/LZ4FrameOutputStream$BD net/jpountz/lz4/LZ4FrameOutputStream BD public,static
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG net/jpountz/lz4/LZ4FrameOutputStream FLG public,static
 inner net/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE net/jpountz/lz4/LZ4FrameOutputStream BLOCKSIZE public,static,final,enum
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits net/jpountz/lz4/LZ4FrameOutputStream$FLG Bits public,static,final,enum
 method public,varargs <init> (Ljava/io/OutputStream;Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE;[Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits;)V - java/io/IOException
 method public,varargs <init> (Ljava/io/OutputStream;Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE;J[Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits;)V - java/io/IOException
 method public,varargs <init> (Ljava/io/OutputStream;Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE;JLnet/jpountz/lz4/LZ4Compressor;Lnet/jpountz/xxhash/XXHash32;[Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits;)V - java/io/IOException
 method public <init> (Ljava/io/OutputStream;Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE;)V - java/io/IOException
 method public <init> (Ljava/io/OutputStream;)V - java/io/IOException
 method public write (I)V - java/io/IOException
 method public write ([BII)V - java/io/IOException
 method public flush ()V - java/io/IOException
 method public close ()V - java/io/IOException
in 60
class net/jpountz/lz4/LZ4FrameOutputStream$BD 51 public,super java/lang/Object - -
 inner net/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE net/jpountz/lz4/LZ4FrameOutputStream BLOCKSIZE public,static,final,enum
 inner net/jpountz/lz4/LZ4FrameOutputStream$BD net/jpountz/lz4/LZ4FrameOutputStream BD public,static
 method public,static fromByte (B)Lnet/jpountz/lz4/LZ4FrameOutputStream$BD; - -
 method public getBlockMaximumSize ()I - -
 method public toByte ()B - -
in 60
class net/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE;>;
 inner net/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE net/jpountz/lz4/LZ4FrameOutputStream BLOCKSIZE public,static,final,enum
 field public,static,final,enum SIZE_64KB Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE; -
 field public,static,final,enum SIZE_256KB Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE; -
 field public,static,final,enum SIZE_1MB Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE; -
 field public,static,final,enum SIZE_4MB Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE; -
 method public,static values ()[Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE; - -
 method public getIndicator ()I - -
 method public,static valueOf (I)Lnet/jpountz/lz4/LZ4FrameOutputStream$BLOCKSIZE; - -
in 60
class net/jpountz/lz4/LZ4FrameOutputStream$FLG 51 public,super java/lang/Object - -
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG net/jpountz/lz4/LZ4FrameOutputStream FLG public,static
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits net/jpountz/lz4/LZ4FrameOutputStream$FLG Bits public,static,final,enum
 method public,varargs <init> (I[Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits;)V - -
 method public,static fromByte (B)Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG; - -
 method public toByte ()B - -
 method public isEnabled (Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits;)Z - -
 method public getVersion ()I - -
in 60
class net/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits;>;
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG net/jpountz/lz4/LZ4FrameOutputStream FLG public,static
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits net/jpountz/lz4/LZ4FrameOutputStream$FLG Bits public,static,final,enum
 field public,static,final,enum RESERVED_0 Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits; -
 field public,static,final,enum RESERVED_1 Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits; -
 field public,static,final,enum CONTENT_CHECKSUM Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits; -
 field public,static,final,enum CONTENT_SIZE Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits; -
 field public,static,final,enum BLOCK_CHECKSUM Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits; -
 field public,static,final,enum BLOCK_INDEPENDENCE Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits; -
 method public,static values ()[Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits; - -
in 60
class net/jpountz/lz4/LZ4FrameOutputStream$FrameInfo 51 super java/lang/Object - -
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG net/jpountz/lz4/LZ4FrameOutputStream FLG public,static
 inner net/jpountz/lz4/LZ4FrameOutputStream$BD net/jpountz/lz4/LZ4FrameOutputStream BD public,static
 inner net/jpountz/lz4/LZ4FrameOutputStream$FrameInfo net/jpountz/lz4/LZ4FrameOutputStream FrameInfo static
 inner net/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits net/jpountz/lz4/LZ4FrameOutputStream$FLG Bits public,static,final,enum
 method public <init> (Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG;Lnet/jpountz/lz4/LZ4FrameOutputStream$BD;)V - -
 method public isEnabled (Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG$Bits;)Z - -
 method public getFLG ()Lnet/jpountz/lz4/LZ4FrameOutputStream$FLG; - -
 method public getBD ()Lnet/jpountz/lz4/LZ4FrameOutputStream$BD; - -
 method public updateStreamHash ([BII)V - -
 method public currentStreamHash ()I - -
 method public finish ()V - -
 method public isFinished ()Z - -
in 60
class net/jpountz/lz4/LZ4HCJNICompressor 51 final,super net/jpountz/lz4/LZ4Compressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4HCJNICompressor; -
 method public compress ([BII[BII)I - -
 method public compress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4HCJavaSafeCompressor 51 final,super net/jpountz/lz4/LZ4Compressor - -
 inner net/jpountz/lz4/LZ4HCJavaSafeCompressor$HashTable net/jpountz/lz4/LZ4HCJavaSafeCompressor HashTable private
 inner net/jpountz/lz4/LZ4Utils$Match net/jpountz/lz4/LZ4Utils Match static
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4Compressor; -
 method public compress ([BII[BII)I - -
 method public compress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4HCJavaSafeCompressor$HashTable 51 super java/lang/Object - -
 inner net/jpountz/lz4/LZ4HCJavaSafeCompressor$HashTable net/jpountz/lz4/LZ4HCJavaSafeCompressor HashTable private
 inner net/jpountz/lz4/LZ4Utils$Match net/jpountz/lz4/LZ4Utils Match static
in 60
class net/jpountz/lz4/LZ4HCJavaUnsafeCompressor 51 final,super net/jpountz/lz4/LZ4Compressor - -
 inner net/jpountz/lz4/LZ4HCJavaUnsafeCompressor$HashTable net/jpountz/lz4/LZ4HCJavaUnsafeCompressor HashTable private
 inner net/jpountz/lz4/LZ4Utils$Match net/jpountz/lz4/LZ4Utils Match static
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4Compressor; -
 method public compress ([BII[BII)I - -
 method public compress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4HCJavaUnsafeCompressor$HashTable 51 super java/lang/Object - -
 inner net/jpountz/lz4/LZ4HCJavaUnsafeCompressor$HashTable net/jpountz/lz4/LZ4HCJavaUnsafeCompressor HashTable private
 inner net/jpountz/lz4/LZ4Utils$Match net/jpountz/lz4/LZ4Utils Match static
in 60
class net/jpountz/lz4/LZ4JNI 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/lz4/LZ4JNI;>;
 method public,static values ()[Lnet/jpountz/lz4/LZ4JNI; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/lz4/LZ4JNI; - -
in 60
class net/jpountz/lz4/LZ4JNICompressor 51 final,super net/jpountz/lz4/LZ4Compressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4Compressor; -
 method public compress ([BII[BII)I - -
 method public compress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4JNIFastDecompressor 51 final,super net/jpountz/lz4/LZ4FastDecompressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4JNIFastDecompressor; -
 method public,final decompress ([BI[BII)I - -
 method public decompress (Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4JNISafeDecompressor 51 final,super net/jpountz/lz4/LZ4SafeDecompressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4JNISafeDecompressor; -
 method public,final decompress ([BII[BII)I - -
 method public decompress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4JavaSafeCompressor 51 final,super net/jpountz/lz4/LZ4Compressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4Compressor; -
 method public compress ([BII[BII)I - -
 method public compress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4JavaSafeFastDecompressor 51 final,super net/jpountz/lz4/LZ4FastDecompressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4FastDecompressor; -
 method public decompress ([BI[BII)I - -
 method public decompress (Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4JavaSafeSafeDecompressor 51 final,super net/jpountz/lz4/LZ4SafeDecompressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4SafeDecompressor; -
 method public decompress ([BII[BII)I - -
 method public decompress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4JavaUnsafeCompressor 51 final,super net/jpountz/lz4/LZ4Compressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4Compressor; -
 method public compress ([BII[BII)I - -
 method public compress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4JavaUnsafeFastDecompressor 51 final,super net/jpountz/lz4/LZ4FastDecompressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4FastDecompressor; -
 method public decompress ([BI[BII)I - -
 method public decompress (Ljava/nio/ByteBuffer;ILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4JavaUnsafeSafeDecompressor 51 final,super net/jpountz/lz4/LZ4SafeDecompressor - -
 field public,static,final INSTANCE Lnet/jpountz/lz4/LZ4SafeDecompressor; -
 method public decompress ([BII[BII)I - -
 method public decompress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
in 60
class net/jpountz/lz4/LZ4SafeDecompressor 51 public,super,abstract java/lang/Object net/jpountz/lz4/LZ4UnknownSizeDecompressor -
 method public <init> ()V - -
 method public,abstract decompress ([BII[BII)I - -
 method public,abstract decompress (Ljava/nio/ByteBuffer;IILjava/nio/ByteBuffer;II)I - -
 method public,final decompress ([BII[BI)I - -
 method public,final decompress ([B[B)I - -
 method public,final decompress ([BIII)[B - -
 method public,final decompress ([BI)[B - -
 method public,final decompress (Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;)V - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/lz4/LZ4SafeUtils 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/lz4/LZ4SafeUtils;>;
 inner net/jpountz/lz4/LZ4SafeUtils$Match net/jpountz/lz4/LZ4SafeUtils Match static
 method public,static values ()[Lnet/jpountz/lz4/LZ4SafeUtils; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/lz4/LZ4SafeUtils; - -
in 60
class net/jpountz/lz4/LZ4SafeUtils$Match 51 super java/lang/Object - -
 inner net/jpountz/lz4/LZ4SafeUtils$Match net/jpountz/lz4/LZ4SafeUtils Match static
in 60
class net/jpountz/lz4/LZ4UnknownSizeDecompressor 51 public,interface,abstract,deprecated java/lang/Object - -
 method public,abstract decompress ([BII[BII)I - -
 method public,abstract decompress ([BII[BI)I - -
in 60
class net/jpountz/lz4/LZ4UnsafeUtils 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/lz4/LZ4UnsafeUtils;>;
 method public,static values ()[Lnet/jpountz/lz4/LZ4UnsafeUtils; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/lz4/LZ4UnsafeUtils; - -
in 60
class net/jpountz/lz4/LZ4Utils 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/lz4/LZ4Utils;>;
 inner net/jpountz/lz4/LZ4Utils$Match net/jpountz/lz4/LZ4Utils Match static
 method public,static values ()[Lnet/jpountz/lz4/LZ4Utils; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/lz4/LZ4Utils; - -
in 60
class net/jpountz/lz4/LZ4Utils$Match 51 super java/lang/Object - -
 inner net/jpountz/lz4/LZ4Utils$Match net/jpountz/lz4/LZ4Utils Match static
in 60
class net/jpountz/util/ByteBufferUtils 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/util/ByteBufferUtils;>;
 method public,static values ()[Lnet/jpountz/util/ByteBufferUtils; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/util/ByteBufferUtils; - -
 method public,static checkRange (Ljava/nio/ByteBuffer;II)V - -
 method public,static checkRange (Ljava/nio/ByteBuffer;I)V - -
 method public,static inLittleEndianOrder (Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer; - -
 method public,static inNativeByteOrder (Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer; - -
 method public,static readByte (Ljava/nio/ByteBuffer;I)B - -
 method public,static writeInt (Ljava/nio/ByteBuffer;II)V - -
 method public,static readInt (Ljava/nio/ByteBuffer;I)I - -
 method public,static readIntLE (Ljava/nio/ByteBuffer;I)I - -
 method public,static writeLong (Ljava/nio/ByteBuffer;IJ)V - -
 method public,static readLong (Ljava/nio/ByteBuffer;I)J - -
 method public,static readLongLE (Ljava/nio/ByteBuffer;I)J - -
 method public,static writeByte (Ljava/nio/ByteBuffer;II)V - -
 method public,static writeShortLE (Ljava/nio/ByteBuffer;II)V - -
 method public,static checkNotReadOnly (Ljava/nio/ByteBuffer;)V - -
 method public,static readShortLE (Ljava/nio/ByteBuffer;I)I - -
in 60
class net/jpountz/util/Native 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/util/Native;>;
 inner net/jpountz/util/Native$OS net/jpountz/util/Native OS private,static,final,enum
 method public,static values ()[Lnet/jpountz/util/Native; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/util/Native; - -
 method public,static,synchronized isLoaded ()Z - -
 method public,static,synchronized load ()V - -
in 60
class net/jpountz/util/Native$OS 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/util/Native$OS;>;
 inner net/jpountz/util/Native$OS net/jpountz/util/Native OS private,static,final,enum
 field public,static,final,enum WINDOWS Lnet/jpountz/util/Native$OS; -
 field public,static,final,enum LINUX Lnet/jpountz/util/Native$OS; -
 field public,static,final,enum MAC Lnet/jpountz/util/Native$OS; -
 field public,static,final,enum SOLARIS Lnet/jpountz/util/Native$OS; -
 field public,final name Ljava/lang/String; -
 field public,final libExtension Ljava/lang/String; -
 method public,static values ()[Lnet/jpountz/util/Native$OS; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/util/Native$OS; - -
in 60
class net/jpountz/util/SafeUtils 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/util/SafeUtils;>;
 method public,static values ()[Lnet/jpountz/util/SafeUtils; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/util/SafeUtils; - -
 method public,static checkRange ([BI)V - -
 method public,static checkRange ([BII)V - -
 method public,static checkLength (I)V - -
 method public,static readByte ([BI)B - -
 method public,static readIntBE ([BI)I - -
 method public,static readIntLE ([BI)I - -
 method public,static readInt ([BI)I - -
 method public,static readLongLE ([BI)J - -
 method public,static writeShortLE ([BII)V - -
 method public,static writeInt ([III)V - -
 method public,static readInt ([II)I - -
 method public,static writeByte ([BII)V - -
 method public,static writeShort ([SII)V - -
 method public,static readShortLE ([BI)I - -
 method public,static readShort ([SI)I - -
in 60
class net/jpountz/util/UnsafeUtils 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/util/UnsafeUtils;>;
 method public,static values ()[Lnet/jpountz/util/UnsafeUtils; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/util/UnsafeUtils; - -
 method public,static checkRange ([BI)V - -
 method public,static checkRange ([BII)V - -
 method public,static checkLength (I)V - -
 method public,static readByte ([BI)B - -
 method public,static writeByte ([BIB)V - -
 method public,static writeByte ([BII)V - -
 method public,static readLong ([BI)J - -
 method public,static readLongLE ([BI)J - -
 method public,static writeLong ([BIJ)V - -
 method public,static readInt ([BI)I - -
 method public,static readIntLE ([BI)I - -
 method public,static writeInt ([BII)V - -
 method public,static readShort ([BI)S - -
 method public,static readShortLE ([BI)I - -
 method public,static writeShort ([BIS)V - -
 method public,static writeShortLE ([BII)V - -
 method public,static readInt ([II)I - -
 method public,static writeInt ([III)V - -
 method public,static readShort ([SI)I - -
 method public,static writeShort ([SII)V - -
in 60
class net/jpountz/util/Utils 51 public,final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/util/Utils;>;
 field public,static,final NATIVE_BYTE_ORDER Ljava/nio/ByteOrder; -
 method public,static values ()[Lnet/jpountz/util/Utils; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/util/Utils; - -
 method public,static isUnalignedAccessAllowed ()Z - -
in 60
class net/jpountz/xxhash/AbstractStreamingXXHash32Java 51 super,abstract net/jpountz/xxhash/StreamingXXHash32 - -
 method public reset ()V - -
in 60
class net/jpountz/xxhash/AbstractStreamingXXHash64Java 51 super,abstract net/jpountz/xxhash/StreamingXXHash64 - -
 method public reset ()V - -
in 60
class net/jpountz/xxhash/StreamingXXHash32 51 public,super,abstract java/lang/Object java/io/Closeable -
 inner net/jpountz/xxhash/StreamingXXHash32$Factory net/jpountz/xxhash/StreamingXXHash32 Factory static,interface,abstract
 method public,abstract getValue ()I - -
 method public,abstract update ([BII)V - -
 method public,abstract reset ()V - -
 method public close ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final asChecksum ()Ljava/util/zip/Checksum; - -
in 60
class net/jpountz/xxhash/StreamingXXHash32$Factory 51 interface,abstract java/lang/Object - -
 inner net/jpountz/xxhash/StreamingXXHash32$Factory net/jpountz/xxhash/StreamingXXHash32 Factory static,interface,abstract
 method public,abstract newStreamingHash (I)Lnet/jpountz/xxhash/StreamingXXHash32; - -
in 60
class net/jpountz/xxhash/StreamingXXHash32JNI 51 final,super net/jpountz/xxhash/StreamingXXHash32 - -
 inner net/jpountz/xxhash/StreamingXXHash32JNI$Factory net/jpountz/xxhash/StreamingXXHash32JNI Factory static
 method public,synchronized reset ()V - -
 method public,synchronized getValue ()I - -
 method public,synchronized update ([BII)V - -
 method public,synchronized close ()V - -
 method protected,synchronized finalize ()V - java/lang/Throwable
in 60
class net/jpountz/xxhash/StreamingXXHash32JNI$Factory 51 super java/lang/Object net/jpountz/xxhash/StreamingXXHash32$Factory -
 inner net/jpountz/xxhash/StreamingXXHash32$Factory net/jpountz/xxhash/StreamingXXHash32 Factory static,interface,abstract
 inner net/jpountz/xxhash/StreamingXXHash32JNI$Factory net/jpountz/xxhash/StreamingXXHash32JNI Factory static
 field public,static,final INSTANCE Lnet/jpountz/xxhash/StreamingXXHash32$Factory; -
 method public newStreamingHash (I)Lnet/jpountz/xxhash/StreamingXXHash32; - -
in 60
class net/jpountz/xxhash/StreamingXXHash32JavaSafe 51 final,super net/jpountz/xxhash/AbstractStreamingXXHash32Java - -
 inner net/jpountz/xxhash/StreamingXXHash32JavaSafe$Factory net/jpountz/xxhash/StreamingXXHash32JavaSafe Factory static
 method public getValue ()I - -
 method public update ([BII)V - -
in 60
class net/jpountz/xxhash/StreamingXXHash32JavaSafe$Factory 51 super java/lang/Object net/jpountz/xxhash/StreamingXXHash32$Factory -
 inner net/jpountz/xxhash/StreamingXXHash32$Factory net/jpountz/xxhash/StreamingXXHash32 Factory static,interface,abstract
 inner net/jpountz/xxhash/StreamingXXHash32JavaSafe$Factory net/jpountz/xxhash/StreamingXXHash32JavaSafe Factory static
 field public,static,final INSTANCE Lnet/jpountz/xxhash/StreamingXXHash32$Factory; -
 method public newStreamingHash (I)Lnet/jpountz/xxhash/StreamingXXHash32; - -
in 60
class net/jpountz/xxhash/StreamingXXHash32JavaUnsafe 51 final,super net/jpountz/xxhash/AbstractStreamingXXHash32Java - -
 inner net/jpountz/xxhash/StreamingXXHash32JavaUnsafe$Factory net/jpountz/xxhash/StreamingXXHash32JavaUnsafe Factory static
 method public getValue ()I - -
 method public update ([BII)V - -
in 60
class net/jpountz/xxhash/StreamingXXHash32JavaUnsafe$Factory 51 super java/lang/Object net/jpountz/xxhash/StreamingXXHash32$Factory -
 inner net/jpountz/xxhash/StreamingXXHash32$Factory net/jpountz/xxhash/StreamingXXHash32 Factory static,interface,abstract
 inner net/jpountz/xxhash/StreamingXXHash32JavaUnsafe$Factory net/jpountz/xxhash/StreamingXXHash32JavaUnsafe Factory static
 field public,static,final INSTANCE Lnet/jpountz/xxhash/StreamingXXHash32$Factory; -
 method public newStreamingHash (I)Lnet/jpountz/xxhash/StreamingXXHash32; - -
in 60
class net/jpountz/xxhash/StreamingXXHash64 51 public,super,abstract java/lang/Object java/io/Closeable -
 inner net/jpountz/xxhash/StreamingXXHash64$Factory net/jpountz/xxhash/StreamingXXHash64 Factory static,interface,abstract
 method public,abstract getValue ()J - -
 method public,abstract update ([BII)V - -
 method public,abstract reset ()V - -
 method public close ()V - -
 method public toString ()Ljava/lang/String; - -
 method public,final asChecksum ()Ljava/util/zip/Checksum; - -
in 60
class net/jpountz/xxhash/StreamingXXHash64$Factory 51 interface,abstract java/lang/Object - -
 inner net/jpountz/xxhash/StreamingXXHash64$Factory net/jpountz/xxhash/StreamingXXHash64 Factory static,interface,abstract
 method public,abstract newStreamingHash (J)Lnet/jpountz/xxhash/StreamingXXHash64; - -
in 60
class net/jpountz/xxhash/StreamingXXHash64JNI 51 final,super net/jpountz/xxhash/StreamingXXHash64 - -
 inner net/jpountz/xxhash/StreamingXXHash64JNI$Factory net/jpountz/xxhash/StreamingXXHash64JNI Factory static
 method public,synchronized reset ()V - -
 method public,synchronized getValue ()J - -
 method public,synchronized update ([BII)V - -
 method public,synchronized close ()V - -
 method protected,synchronized finalize ()V - java/lang/Throwable
in 60
class net/jpountz/xxhash/StreamingXXHash64JNI$Factory 51 super java/lang/Object net/jpountz/xxhash/StreamingXXHash64$Factory -
 inner net/jpountz/xxhash/StreamingXXHash64$Factory net/jpountz/xxhash/StreamingXXHash64 Factory static,interface,abstract
 inner net/jpountz/xxhash/StreamingXXHash64JNI$Factory net/jpountz/xxhash/StreamingXXHash64JNI Factory static
 field public,static,final INSTANCE Lnet/jpountz/xxhash/StreamingXXHash64$Factory; -
 method public newStreamingHash (J)Lnet/jpountz/xxhash/StreamingXXHash64; - -
in 60
class net/jpountz/xxhash/StreamingXXHash64JavaSafe 51 final,super net/jpountz/xxhash/AbstractStreamingXXHash64Java - -
 inner net/jpountz/xxhash/StreamingXXHash64JavaSafe$Factory net/jpountz/xxhash/StreamingXXHash64JavaSafe Factory static
 method public getValue ()J - -
 method public update ([BII)V - -
in 60
class net/jpountz/xxhash/StreamingXXHash64JavaSafe$Factory 51 super java/lang/Object net/jpountz/xxhash/StreamingXXHash64$Factory -
 inner net/jpountz/xxhash/StreamingXXHash64$Factory net/jpountz/xxhash/StreamingXXHash64 Factory static,interface,abstract
 inner net/jpountz/xxhash/StreamingXXHash64JavaSafe$Factory net/jpountz/xxhash/StreamingXXHash64JavaSafe Factory static
 field public,static,final INSTANCE Lnet/jpountz/xxhash/StreamingXXHash64$Factory; -
 method public newStreamingHash (J)Lnet/jpountz/xxhash/StreamingXXHash64; - -
in 60
class net/jpountz/xxhash/StreamingXXHash64JavaUnsafe 51 final,super net/jpountz/xxhash/AbstractStreamingXXHash64Java - -
 inner net/jpountz/xxhash/StreamingXXHash64JavaUnsafe$Factory net/jpountz/xxhash/StreamingXXHash64JavaUnsafe Factory static
 method public getValue ()J - -
 method public update ([BII)V - -
in 60
class net/jpountz/xxhash/StreamingXXHash64JavaUnsafe$Factory 51 super java/lang/Object net/jpountz/xxhash/StreamingXXHash64$Factory -
 inner net/jpountz/xxhash/StreamingXXHash64$Factory net/jpountz/xxhash/StreamingXXHash64 Factory static,interface,abstract
 inner net/jpountz/xxhash/StreamingXXHash64JavaUnsafe$Factory net/jpountz/xxhash/StreamingXXHash64JavaUnsafe Factory static
 field public,static,final INSTANCE Lnet/jpountz/xxhash/StreamingXXHash64$Factory; -
 method public newStreamingHash (J)Lnet/jpountz/xxhash/StreamingXXHash64; - -
in 60
class net/jpountz/xxhash/XXHash32 51 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract hash ([BIII)I - -
 method public,abstract hash (Ljava/nio/ByteBuffer;III)I - -
 method public,final hash (Ljava/nio/ByteBuffer;I)I - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/xxhash/XXHash32JNI 51 final,super net/jpountz/xxhash/XXHash32 - -
 field public,static,final INSTANCE Lnet/jpountz/xxhash/XXHash32; -
 method public hash ([BIII)I - -
 method public hash (Ljava/nio/ByteBuffer;III)I - -
in 60
class net/jpountz/xxhash/XXHash32JavaSafe 51 final,super net/jpountz/xxhash/XXHash32 - -
 field public,static,final INSTANCE Lnet/jpountz/xxhash/XXHash32; -
 method public hash ([BIII)I - -
 method public hash (Ljava/nio/ByteBuffer;III)I - -
in 60
class net/jpountz/xxhash/XXHash32JavaUnsafe 51 final,super net/jpountz/xxhash/XXHash32 - -
 field public,static,final INSTANCE Lnet/jpountz/xxhash/XXHash32; -
 method public hash ([BIII)I - -
 method public hash (Ljava/nio/ByteBuffer;III)I - -
in 60
class net/jpountz/xxhash/XXHash64 51 public,super,abstract java/lang/Object - -
 method public <init> ()V - -
 method public,abstract hash ([BIIJ)J - -
 method public,abstract hash (Ljava/nio/ByteBuffer;IIJ)J - -
 method public,final hash (Ljava/nio/ByteBuffer;J)J - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/xxhash/XXHash64JNI 51 final,super net/jpountz/xxhash/XXHash64 - -
 field public,static,final INSTANCE Lnet/jpountz/xxhash/XXHash64; -
 method public hash ([BIIJ)J - -
 method public hash (Ljava/nio/ByteBuffer;IIJ)J - -
in 60
class net/jpountz/xxhash/XXHash64JavaSafe 51 final,super net/jpountz/xxhash/XXHash64 - -
 field public,static,final INSTANCE Lnet/jpountz/xxhash/XXHash64; -
 method public hash ([BIIJ)J - -
 method public hash (Ljava/nio/ByteBuffer;IIJ)J - -
in 60
class net/jpountz/xxhash/XXHash64JavaUnsafe 51 final,super net/jpountz/xxhash/XXHash64 - -
 field public,static,final INSTANCE Lnet/jpountz/xxhash/XXHash64; -
 method public hash ([BIIJ)J - -
 method public hash (Ljava/nio/ByteBuffer;IIJ)J - -
in 60
class net/jpountz/xxhash/XXHashConstants 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/xxhash/XXHashConstants;>;
 method public,static values ()[Lnet/jpountz/xxhash/XXHashConstants; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/xxhash/XXHashConstants; - -
in 60
class net/jpountz/xxhash/XXHashFactory 51 public,final,super java/lang/Object - -
 inner net/jpountz/xxhash/StreamingXXHash32$Factory net/jpountz/xxhash/StreamingXXHash32 Factory static,interface,abstract
 inner net/jpountz/xxhash/StreamingXXHash64$Factory net/jpountz/xxhash/StreamingXXHash64 Factory static,interface,abstract
 method public,static,synchronized nativeInstance ()Lnet/jpountz/xxhash/XXHashFactory; - -
 method public,static,synchronized safeInstance ()Lnet/jpountz/xxhash/XXHashFactory; - -
 method public,static,synchronized unsafeInstance ()Lnet/jpountz/xxhash/XXHashFactory; - -
 method public,static fastestJavaInstance ()Lnet/jpountz/xxhash/XXHashFactory; - -
 method public,static fastestInstance ()Lnet/jpountz/xxhash/XXHashFactory; - -
 method public hash32 ()Lnet/jpountz/xxhash/XXHash32; - -
 method public hash64 ()Lnet/jpountz/xxhash/XXHash64; - -
 method public newStreamingHash32 (I)Lnet/jpountz/xxhash/StreamingXXHash32; - -
 method public newStreamingHash64 (J)Lnet/jpountz/xxhash/StreamingXXHash64; - -
 method public,static main ([Ljava/lang/String;)V - -
 method public toString ()Ljava/lang/String; - -
in 60
class net/jpountz/xxhash/XXHashJNI 51 final,super,enum java/lang/Enum - Ljava/lang/Enum<Lnet/jpountz/xxhash/XXHashJNI;>;
 method public,static values ()[Lnet/jpountz/xxhash/XXHashJNI; - -
 method public,static valueOf (Ljava/lang/String;)Lnet/jpountz/xxhash/XXHashJNI; - -
