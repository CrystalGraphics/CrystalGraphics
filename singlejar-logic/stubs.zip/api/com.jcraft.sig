cg-stub-db 1
in 59
class com/jcraft/jogg/Buffer 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public writeinit ()V - -
 method public write ([B)V - -
 method public read ([BI)V - -
 method public writeclear ()V - -
 method public readinit ([BI)V - -
 method public readinit ([BII)V - -
 method public write (II)V - -
 method public look (I)I - -
 method public look1 ()I - -
 method public adv (I)V - -
 method public adv1 ()V - -
 method public read (I)I - -
 method public readB (I)I - -
 method public read1 ()I - -
 method public bytes ()I - -
 method public bits ()I - -
 method public buffer ()[B - -
 method public,static ilog (I)I - -
 method public,static report (Ljava/lang/String;)V - -
in 60
class com/jcraft/jogg/Buffer 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public writeinit ()V - -
 method public write ([B)V - -
 method public read ([BI)V - -
 method public writeclear ()V - -
 method public readinit ([BI)V - -
 method public readinit ([BII)V - -
 method public write (II)V - -
 method public look (I)I - -
 method public look1 ()I - -
 method public adv (I)V - -
 method public adv1 ()V - -
 method public read (I)I - -
 method public readB (I)I - -
 method public read1 ()I - -
 method public bytes ()I - -
 method public bits ()I - -
 method public buffer ()[B - -
 method public,static ilog (I)I - -
 method public,static report (Ljava/lang/String;)V - -
in 59
class com/jcraft/jogg/Packet 49 public,super java/lang/Object - -
 field public packet_base [B -
 field public packet I -
 field public bytes I -
 field public b_o_s I -
 field public e_o_s I -
 field public granulepos J -
 field public packetno J -
 method public <init> ()V - -
in 60
class com/jcraft/jogg/Packet 50 public,super java/lang/Object - -
 field public packet_base [B -
 field public packet I -
 field public bytes I -
 field public b_o_s I -
 field public e_o_s I -
 field public granulepos J -
 field public packetno J -
 method public <init> ()V - -
in 59
class com/jcraft/jogg/Page 49 public,super java/lang/Object - -
 field public header_base [B -
 field public header I -
 field public header_len I -
 field public body_base [B -
 field public body I -
 field public body_len I -
 method public <init> ()V - -
 method public bos ()I - -
 method public eos ()I - -
 method public granulepos ()J - -
 method public serialno ()I - -
 method public copy ()Lcom/jcraft/jogg/Page; - -
 method public copy (Lcom/jcraft/jogg/Page;)Lcom/jcraft/jogg/Page; - -
in 60
class com/jcraft/jogg/Page 50 public,super java/lang/Object - -
 field public header_base [B -
 field public header I -
 field public header_len I -
 field public body_base [B -
 field public body I -
 field public body_len I -
 method public <init> ()V - -
 method public bos ()I - -
 method public eos ()I - -
 method public granulepos ()J - -
 method public serialno ()I - -
 method public copy ()Lcom/jcraft/jogg/Page; - -
 method public copy (Lcom/jcraft/jogg/Page;)Lcom/jcraft/jogg/Page; - -
in 59
class com/jcraft/jogg/StreamState 49 public,super java/lang/Object - -
 field public e_o_s I -
 method public <init> ()V - -
 method public init (I)V - -
 method public clear ()V - -
 method public packetin (Lcom/jcraft/jogg/Packet;)I - -
 method public packetout (Lcom/jcraft/jogg/Packet;)I - -
 method public pagein (Lcom/jcraft/jogg/Page;)I - -
 method public flush (Lcom/jcraft/jogg/Page;)I - -
 method public pageout (Lcom/jcraft/jogg/Page;)I - -
 method public eof ()I - -
 method public reset ()I - -
in 60
class com/jcraft/jogg/StreamState 50 public,super java/lang/Object - -
 field public e_o_s I -
 method public <init> ()V - -
 method public init (I)V - -
 method public clear ()V - -
 method public packetin (Lcom/jcraft/jogg/Packet;)I - -
 method public packetout (Lcom/jcraft/jogg/Packet;)I - -
 method public pagein (Lcom/jcraft/jogg/Page;)I - -
 method public flush (Lcom/jcraft/jogg/Page;)I - -
 method public pageout (Lcom/jcraft/jogg/Page;)I - -
 method public eof ()I - -
 method public reset ()I - -
in 59
class com/jcraft/jogg/SyncState 49 public,super java/lang/Object - -
 field public data [B -
 method public <init> ()V - -
 method public clear ()I - -
 method public buffer (I)I - -
 method public wrote (I)I - -
 method public pageseek (Lcom/jcraft/jogg/Page;)I - -
 method public pageout (Lcom/jcraft/jogg/Page;)I - -
 method public reset ()I - -
 method public init ()V - -
 method public getDataOffset ()I - -
 method public getBufferOffset ()I - -
in 60
class com/jcraft/jogg/SyncState 50 public,super java/lang/Object - -
 field public data [B -
 method public <init> ()V - -
 method public clear ()I - -
 method public buffer (I)I - -
 method public wrote (I)I - -
 method public pageseek (Lcom/jcraft/jogg/Page;)I - -
 method public pageout (Lcom/jcraft/jogg/Page;)I - -
 method public reset ()I - -
 method public init ()V - -
 method public getDataOffset ()I - -
 method public getBufferOffset ()I - -
in 59
class com/jcraft/jorbis/Block 49 public,super java/lang/Object - -
 method public <init> (Lcom/jcraft/jorbis/DspState;)V - -
 method public init (Lcom/jcraft/jorbis/DspState;)V - -
 method public clear ()I - -
 method public synthesis (Lcom/jcraft/jogg/Packet;)I - -
in 60
class com/jcraft/jorbis/Block 50 public,super java/lang/Object - -
 method public <init> (Lcom/jcraft/jorbis/DspState;)V - -
 method public init (Lcom/jcraft/jorbis/DspState;)V - -
 method public clear ()I - -
 method public synthesis (Lcom/jcraft/jogg/Packet;)I - -
in 59
class com/jcraft/jorbis/ChainingExample 49 super java/lang/Object - -
 method public,static main ([Ljava/lang/String;)V - -
in 59
class com/jcraft/jorbis/CodeBook 49 super java/lang/Object - -
 inner com/jcraft/jorbis/CodeBook$DecodeAux com/jcraft/jorbis/CodeBook DecodeAux -
in 60
class com/jcraft/jorbis/CodeBook 50 super java/lang/Object - -
 inner com/jcraft/jorbis/CodeBook$DecodeAux com/jcraft/jorbis/CodeBook DecodeAux -
in 59
class com/jcraft/jorbis/CodeBook$DecodeAux 49 super java/lang/Object - -
 inner com/jcraft/jorbis/CodeBook$DecodeAux com/jcraft/jorbis/CodeBook DecodeAux -
in 60
class com/jcraft/jorbis/CodeBook$DecodeAux 50 super java/lang/Object - -
 inner com/jcraft/jorbis/CodeBook$DecodeAux com/jcraft/jorbis/CodeBook DecodeAux -
in 59
class com/jcraft/jorbis/Comment 49 public,super java/lang/Object - -
 field public user_comments [[B -
 field public comment_lengths [I -
 field public comments I -
 field public vendor [B -
 method public <init> ()V - -
 method public init ()V - -
 method public add (Ljava/lang/String;)V - -
 method public add_tag (Ljava/lang/String;Ljava/lang/String;)V - -
 method public query (Ljava/lang/String;)Ljava/lang/String; - -
 method public query (Ljava/lang/String;I)Ljava/lang/String; - -
 method public header_out (Lcom/jcraft/jogg/Packet;)I - -
 method public getVendor ()Ljava/lang/String; - -
 method public getComment (I)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 60
class com/jcraft/jorbis/Comment 50 public,super java/lang/Object - -
 field public user_comments [[B -
 field public comment_lengths [I -
 field public comments I -
 field public vendor [B -
 method public <init> ()V - -
 method public init ()V - -
 method public add (Ljava/lang/String;)V - -
 method public add_tag (Ljava/lang/String;Ljava/lang/String;)V - -
 method public query (Ljava/lang/String;)Ljava/lang/String; - -
 method public query (Ljava/lang/String;I)Ljava/lang/String; - -
 method public header_out (Lcom/jcraft/jogg/Packet;)I - -
 method public getVendor ()Ljava/lang/String; - -
 method public getComment (I)Ljava/lang/String; - -
 method public toString ()Ljava/lang/String; - -
in 59
class com/jcraft/jorbis/DecodeExample 49 super java/lang/Object - -
 method public,static main ([Ljava/lang/String;)V - -
in 59
class com/jcraft/jorbis/Drft 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/Drft 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/DspState 49 public,super java/lang/Object - -
 method public <init> ()V - -
 method public synthesis_init (Lcom/jcraft/jorbis/Info;)I - -
 method public synthesis_blockin (Lcom/jcraft/jorbis/Block;)I - -
 method public synthesis_pcmout ([[[F[I)I - -
 method public synthesis_read (I)I - -
 method public clear ()V - -
in 60
class com/jcraft/jorbis/DspState 50 public,super java/lang/Object - -
 method public <init> ()V - -
 method public synthesis_init (Lcom/jcraft/jorbis/Info;)I - -
 method public synthesis_blockin (Lcom/jcraft/jorbis/Block;)I - -
 method public synthesis_pcmout ([[[F[I)I - -
 method public synthesis_read (I)I - -
 method public clear ()V - -
in 59
class com/jcraft/jorbis/Floor0 49 super com/jcraft/jorbis/FuncFloor - -
 inner com/jcraft/jorbis/Floor0$EchstateFloor0 com/jcraft/jorbis/Floor0 EchstateFloor0 -
 inner com/jcraft/jorbis/Floor0$LookFloor0 com/jcraft/jorbis/Floor0 LookFloor0 -
 inner com/jcraft/jorbis/Floor0$InfoFloor0 com/jcraft/jorbis/Floor0 InfoFloor0 -
in 60
class com/jcraft/jorbis/Floor0 50 super com/jcraft/jorbis/FuncFloor - -
 inner com/jcraft/jorbis/Floor0$EchstateFloor0 com/jcraft/jorbis/Floor0 EchstateFloor0 -
 inner com/jcraft/jorbis/Floor0$LookFloor0 com/jcraft/jorbis/Floor0 LookFloor0 -
 inner com/jcraft/jorbis/Floor0$InfoFloor0 com/jcraft/jorbis/Floor0 InfoFloor0 -
in 59
class com/jcraft/jorbis/Floor0$EchstateFloor0 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor0$EchstateFloor0 com/jcraft/jorbis/Floor0 EchstateFloor0 -
in 60
class com/jcraft/jorbis/Floor0$EchstateFloor0 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor0$EchstateFloor0 com/jcraft/jorbis/Floor0 EchstateFloor0 -
in 59
class com/jcraft/jorbis/Floor0$InfoFloor0 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor0$InfoFloor0 com/jcraft/jorbis/Floor0 InfoFloor0 -
in 60
class com/jcraft/jorbis/Floor0$InfoFloor0 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor0$InfoFloor0 com/jcraft/jorbis/Floor0 InfoFloor0 -
in 59
class com/jcraft/jorbis/Floor0$LookFloor0 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor0$InfoFloor0 com/jcraft/jorbis/Floor0 InfoFloor0 -
 inner com/jcraft/jorbis/Floor0$LookFloor0 com/jcraft/jorbis/Floor0 LookFloor0 -
in 60
class com/jcraft/jorbis/Floor0$LookFloor0 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor0$InfoFloor0 com/jcraft/jorbis/Floor0 InfoFloor0 -
 inner com/jcraft/jorbis/Floor0$LookFloor0 com/jcraft/jorbis/Floor0 LookFloor0 -
in 59
class com/jcraft/jorbis/Floor1 49 super com/jcraft/jorbis/FuncFloor - -
 inner com/jcraft/jorbis/Floor1$EchstateFloor1 com/jcraft/jorbis/Floor1 EchstateFloor1 -
 inner com/jcraft/jorbis/Floor1$Lsfit_acc com/jcraft/jorbis/Floor1 Lsfit_acc -
 inner com/jcraft/jorbis/Floor1$LookFloor1 com/jcraft/jorbis/Floor1 LookFloor1 -
 inner com/jcraft/jorbis/Floor1$InfoFloor1 com/jcraft/jorbis/Floor1 InfoFloor1 -
in 60
class com/jcraft/jorbis/Floor1 50 super com/jcraft/jorbis/FuncFloor - -
 inner com/jcraft/jorbis/Floor1$EchstateFloor1 com/jcraft/jorbis/Floor1 EchstateFloor1 -
 inner com/jcraft/jorbis/Floor1$Lsfit_acc com/jcraft/jorbis/Floor1 Lsfit_acc -
 inner com/jcraft/jorbis/Floor1$LookFloor1 com/jcraft/jorbis/Floor1 LookFloor1 -
 inner com/jcraft/jorbis/Floor1$InfoFloor1 com/jcraft/jorbis/Floor1 InfoFloor1 -
in 59
class com/jcraft/jorbis/Floor1$EchstateFloor1 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor1$EchstateFloor1 com/jcraft/jorbis/Floor1 EchstateFloor1 -
in 60
class com/jcraft/jorbis/Floor1$EchstateFloor1 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor1$EchstateFloor1 com/jcraft/jorbis/Floor1 EchstateFloor1 -
in 59
class com/jcraft/jorbis/Floor1$InfoFloor1 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor1$InfoFloor1 com/jcraft/jorbis/Floor1 InfoFloor1 -
in 60
class com/jcraft/jorbis/Floor1$InfoFloor1 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor1$InfoFloor1 com/jcraft/jorbis/Floor1 InfoFloor1 -
in 59
class com/jcraft/jorbis/Floor1$LookFloor1 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor1$InfoFloor1 com/jcraft/jorbis/Floor1 InfoFloor1 -
 inner com/jcraft/jorbis/Floor1$LookFloor1 com/jcraft/jorbis/Floor1 LookFloor1 -
in 60
class com/jcraft/jorbis/Floor1$LookFloor1 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor1$InfoFloor1 com/jcraft/jorbis/Floor1 InfoFloor1 -
 inner com/jcraft/jorbis/Floor1$LookFloor1 com/jcraft/jorbis/Floor1 LookFloor1 -
in 59
class com/jcraft/jorbis/Floor1$Lsfit_acc 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor1$Lsfit_acc com/jcraft/jorbis/Floor1 Lsfit_acc -
in 60
class com/jcraft/jorbis/Floor1$Lsfit_acc 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Floor1$Lsfit_acc com/jcraft/jorbis/Floor1 Lsfit_acc -
in 59
class com/jcraft/jorbis/FuncFloor 49 super,abstract java/lang/Object - -
 field public,static floor_P [Lcom/jcraft/jorbis/FuncFloor; -
in 60
class com/jcraft/jorbis/FuncFloor 50 super,abstract java/lang/Object - -
 field public,static floor_P [Lcom/jcraft/jorbis/FuncFloor; -
in 59
class com/jcraft/jorbis/FuncMapping 49 super,abstract java/lang/Object - -
 field public,static mapping_P [Lcom/jcraft/jorbis/FuncMapping; -
in 60
class com/jcraft/jorbis/FuncMapping 50 super,abstract java/lang/Object - -
 field public,static mapping_P [Lcom/jcraft/jorbis/FuncMapping; -
in 59
class com/jcraft/jorbis/FuncResidue 49 super,abstract java/lang/Object - -
 field public,static residue_P [Lcom/jcraft/jorbis/FuncResidue; -
in 60
class com/jcraft/jorbis/FuncResidue 50 super,abstract java/lang/Object - -
 field public,static residue_P [Lcom/jcraft/jorbis/FuncResidue; -
in 59
class com/jcraft/jorbis/FuncTime 49 super,abstract java/lang/Object - -
 field public,static time_P [Lcom/jcraft/jorbis/FuncTime; -
in 60
class com/jcraft/jorbis/FuncTime 50 super,abstract java/lang/Object - -
 field public,static time_P [Lcom/jcraft/jorbis/FuncTime; -
in 59
class com/jcraft/jorbis/Info 49 public,super java/lang/Object - -
 field public version I -
 field public channels I -
 field public rate I -
 method public <init> ()V - -
 method public init ()V - -
 method public clear ()V - -
 method public synthesis_headerin (Lcom/jcraft/jorbis/Comment;Lcom/jcraft/jogg/Packet;)I - -
 method public blocksize (Lcom/jcraft/jogg/Packet;)I - -
 method public toString ()Ljava/lang/String; - -
in 60
class com/jcraft/jorbis/Info 50 public,super java/lang/Object - -
 field public version I -
 field public channels I -
 field public rate I -
 method public <init> ()V - -
 method public init ()V - -
 method public clear ()V - -
 method public synthesis_headerin (Lcom/jcraft/jorbis/Comment;Lcom/jcraft/jogg/Packet;)I - -
 method public blocksize (Lcom/jcraft/jogg/Packet;)I - -
 method public toString ()Ljava/lang/String; - -
in 59
class com/jcraft/jorbis/InfoMode 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/InfoMode 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/JOrbisException 49 public,super java/lang/Exception - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
in 60
class com/jcraft/jorbis/JOrbisException 50 public,super java/lang/Exception - -
 method public <init> ()V - -
 method public <init> (Ljava/lang/String;)V - -
in 59
class com/jcraft/jorbis/Lookup 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/Lookup 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/Lpc 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/Lpc 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/Lsp 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/Lsp 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/Mapping0 49 super com/jcraft/jorbis/FuncMapping - -
 inner com/jcraft/jorbis/Mapping0$LookMapping0 com/jcraft/jorbis/Mapping0 LookMapping0 -
 inner com/jcraft/jorbis/Mapping0$InfoMapping0 com/jcraft/jorbis/Mapping0 InfoMapping0 -
in 60
class com/jcraft/jorbis/Mapping0 50 super com/jcraft/jorbis/FuncMapping - -
 inner com/jcraft/jorbis/Mapping0$LookMapping0 com/jcraft/jorbis/Mapping0 LookMapping0 -
 inner com/jcraft/jorbis/Mapping0$InfoMapping0 com/jcraft/jorbis/Mapping0 InfoMapping0 -
in 59
class com/jcraft/jorbis/Mapping0$InfoMapping0 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Mapping0$InfoMapping0 com/jcraft/jorbis/Mapping0 InfoMapping0 -
in 60
class com/jcraft/jorbis/Mapping0$InfoMapping0 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Mapping0$InfoMapping0 com/jcraft/jorbis/Mapping0 InfoMapping0 -
in 59
class com/jcraft/jorbis/Mapping0$LookMapping0 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Mapping0$InfoMapping0 com/jcraft/jorbis/Mapping0 InfoMapping0 -
 inner com/jcraft/jorbis/Mapping0$LookMapping0 com/jcraft/jorbis/Mapping0 LookMapping0 -
in 60
class com/jcraft/jorbis/Mapping0$LookMapping0 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Mapping0$InfoMapping0 com/jcraft/jorbis/Mapping0 InfoMapping0 -
 inner com/jcraft/jorbis/Mapping0$LookMapping0 com/jcraft/jorbis/Mapping0 LookMapping0 -
in 59
class com/jcraft/jorbis/Mdct 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/Mdct 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/PsyInfo 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/PsyInfo 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/PsyLook 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/PsyLook 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/Residue0 49 super com/jcraft/jorbis/FuncResidue - -
 inner com/jcraft/jorbis/Residue0$InfoResidue0 com/jcraft/jorbis/Residue0 InfoResidue0 -
 inner com/jcraft/jorbis/Residue0$LookResidue0 com/jcraft/jorbis/Residue0 LookResidue0 -
in 60
class com/jcraft/jorbis/Residue0 50 super com/jcraft/jorbis/FuncResidue - -
 inner com/jcraft/jorbis/Residue0$InfoResidue0 com/jcraft/jorbis/Residue0 InfoResidue0 -
 inner com/jcraft/jorbis/Residue0$LookResidue0 com/jcraft/jorbis/Residue0 LookResidue0 -
in 59
class com/jcraft/jorbis/Residue0$InfoResidue0 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Residue0$InfoResidue0 com/jcraft/jorbis/Residue0 InfoResidue0 -
in 60
class com/jcraft/jorbis/Residue0$InfoResidue0 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Residue0$InfoResidue0 com/jcraft/jorbis/Residue0 InfoResidue0 -
in 59
class com/jcraft/jorbis/Residue0$LookResidue0 49 super java/lang/Object - -
 inner com/jcraft/jorbis/Residue0$InfoResidue0 com/jcraft/jorbis/Residue0 InfoResidue0 -
 inner com/jcraft/jorbis/Residue0$LookResidue0 com/jcraft/jorbis/Residue0 LookResidue0 -
in 60
class com/jcraft/jorbis/Residue0$LookResidue0 50 super java/lang/Object - -
 inner com/jcraft/jorbis/Residue0$InfoResidue0 com/jcraft/jorbis/Residue0 InfoResidue0 -
 inner com/jcraft/jorbis/Residue0$LookResidue0 com/jcraft/jorbis/Residue0 LookResidue0 -
in 59
class com/jcraft/jorbis/Residue1 49 super com/jcraft/jorbis/Residue0 - -
in 60
class com/jcraft/jorbis/Residue1 50 super com/jcraft/jorbis/Residue0 - -
in 59
class com/jcraft/jorbis/Residue2 49 super com/jcraft/jorbis/Residue0 - -
in 60
class com/jcraft/jorbis/Residue2 50 super com/jcraft/jorbis/Residue0 - -
in 59
class com/jcraft/jorbis/StaticCodeBook 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/StaticCodeBook 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/Time0 49 super com/jcraft/jorbis/FuncTime - -
in 60
class com/jcraft/jorbis/Time0 50 super com/jcraft/jorbis/FuncTime - -
in 59
class com/jcraft/jorbis/Util 49 super java/lang/Object - -
in 60
class com/jcraft/jorbis/Util 50 super java/lang/Object - -
in 59
class com/jcraft/jorbis/VorbisFile 49 public,super java/lang/Object - -
 inner com/jcraft/jorbis/VorbisFile$SeekableInputStream com/jcraft/jorbis/VorbisFile SeekableInputStream -
 method public <init> (Ljava/lang/String;)V - com/jcraft/jorbis/JOrbisException
 method public <init> (Ljava/io/InputStream;[BI)V - com/jcraft/jorbis/JOrbisException
 method public streams ()I - -
 method public seekable ()Z - -
 method public bitrate (I)I - -
 method public bitrate_instant ()I - -
 method public serialnumber (I)I - -
 method public raw_total (I)J - -
 method public pcm_total (I)J - -
 method public time_total (I)F - -
 method public raw_seek (I)I - -
 method public pcm_seek (J)I - -
 method public raw_tell ()J - -
 method public pcm_tell ()J - -
 method public time_tell ()F - -
 method public getInfo (I)Lcom/jcraft/jorbis/Info; - -
 method public getComment (I)Lcom/jcraft/jorbis/Comment; - -
 method public getInfo ()[Lcom/jcraft/jorbis/Info; - -
 method public getComment ()[Lcom/jcraft/jorbis/Comment; - -
 method public close ()V - java/io/IOException
in 60
class com/jcraft/jorbis/VorbisFile 50 public,super java/lang/Object - -
 inner com/jcraft/jorbis/VorbisFile$SeekableInputStream com/jcraft/jorbis/VorbisFile SeekableInputStream -
 method public <init> (Ljava/lang/String;)V - com/jcraft/jorbis/JOrbisException
 method public <init> (Ljava/io/InputStream;[BI)V - com/jcraft/jorbis/JOrbisException
 method public streams ()I - -
 method public seekable ()Z - -
 method public bitrate (I)I - -
 method public bitrate_instant ()I - -
 method public serialnumber (I)I - -
 method public raw_total (I)J - -
 method public pcm_total (I)J - -
 method public time_total (I)F - -
 method public raw_seek (I)I - -
 method public pcm_seek (J)I - -
 method public raw_tell ()J - -
 method public pcm_tell ()J - -
 method public time_tell ()F - -
 method public getInfo (I)Lcom/jcraft/jorbis/Info; - -
 method public getComment (I)Lcom/jcraft/jorbis/Comment; - -
 method public getInfo ()[Lcom/jcraft/jorbis/Info; - -
 method public getComment ()[Lcom/jcraft/jorbis/Comment; - -
 method public close ()V - java/io/IOException
in 59
class com/jcraft/jorbis/VorbisFile$SeekableInputStream 49 super java/io/InputStream - -
 inner com/jcraft/jorbis/VorbisFile$SeekableInputStream com/jcraft/jorbis/VorbisFile SeekableInputStream -
 method public read ()I - java/io/IOException
 method public read ([B)I - java/io/IOException
 method public read ([BII)I - java/io/IOException
 method public skip (J)J - java/io/IOException
 method public getLength ()J - java/io/IOException
 method public tell ()J - java/io/IOException
 method public available ()I - java/io/IOException
 method public close ()V - java/io/IOException
 method public,synchronized mark (I)V - -
 method public,synchronized reset ()V - java/io/IOException
 method public markSupported ()Z - -
 method public seek (J)V - java/io/IOException
in 60
class com/jcraft/jorbis/VorbisFile$SeekableInputStream 50 super java/io/InputStream - -
 inner com/jcraft/jorbis/VorbisFile$SeekableInputStream com/jcraft/jorbis/VorbisFile SeekableInputStream -
 method public read ()I - java/io/IOException
 method public read ([B)I - java/io/IOException
 method public read ([BII)I - java/io/IOException
 method public skip (J)J - java/io/IOException
 method public getLength ()J - java/io/IOException
 method public tell ()J - java/io/IOException
 method public available ()I - java/io/IOException
 method public close ()V - java/io/IOException
 method public,synchronized mark (I)V - -
 method public,synchronized reset ()V - java/io/IOException
 method public markSupported ()Z - -
 method public seek (J)V - java/io/IOException
