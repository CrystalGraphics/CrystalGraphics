cg-stub-db 1
in 90
class net/minecraft/profiler/IPlayerUsage 50 public,interface,abstract java/lang/Object - -
 method public,abstract addServerStatsToSnooper (Lnet/minecraft/profiler/PlayerUsageSnooper;)V - -
 method public,abstract addServerTypeToSnooper (Lnet/minecraft/profiler/PlayerUsageSnooper;)V - -
 method public,abstract isSnooperEnabled ()Z - -
in 91
class net/minecraft/profiler/ISnooperInfo 50 public,interface,abstract java/lang/Object - -
 method public,abstract addServerStatsToSnooper (Lnet/minecraft/profiler/Snooper;)V - -
 method public,abstract addServerTypeToSnooper (Lnet/minecraft/profiler/Snooper;)V - -
 method public,abstract isSnooperEnabled ()Z - -
in 326
class net/minecraft/profiler/ISnooperInfo 52 public,interface,abstract java/lang/Object - -
 method public,abstract addServerStatsToSnooper (Lnet/minecraft/profiler/Snooper;)V - -
 method public,abstract addServerTypeToSnooper (Lnet/minecraft/profiler/Snooper;)V - -
 method public,abstract isSnooperEnabled ()Z - -
in 90
class net/minecraft/profiler/PlayerUsageSnooper 50 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public getCurrentStats ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getUniqueID ()Ljava/lang/String; - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/profiler/IPlayerUsage;J)V - -
 method public startSnooper ()V - -
 method public addMemoryStatsToSnooper ()V - -
 method public addClientStat (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public addStatToSnooper (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public isSnooperRunning ()Z - -
 method public stopSnooper ()V - -
 method public getMinecraftStartTimeMillis ()J - -
in 24
class net/minecraft/profiler/Profiler 50 public,super java/lang/Object - -
 inner net/minecraft/profiler/Profiler$Result net/minecraft/profiler/Profiler Result public,static,final
 field public profilingEnabled Z -
 method public <init> ()V - -
 method public clearProfiling ()V - -
 method public startSection (Ljava/lang/String;)V - -
 method public endSection ()V - -
 method public getProfilingData (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lnet/minecraft/profiler/Profiler$Result;>; -
 method public endStartSection (Ljava/lang/String;)V - -
 method public getNameOfLastSection ()Ljava/lang/String; - -
in 326
class net/minecraft/profiler/Profiler 52 public,super java/lang/Object - -
 inner net/minecraft/profiler/Profiler$Result net/minecraft/profiler/Profiler Result public,static,final
 field public profilingEnabled Z -
 method public <init> ()V - -
 method public clearProfiling ()V - -
 method public startSection (Ljava/lang/String;)V - -
 method public func_194340_a (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public endSection ()V - -
 method public getProfilingData (Ljava/lang/String;)Ljava/util/List; (Ljava/lang/String;)Ljava/util/List<Lnet/minecraft/profiler/Profiler$Result;>; -
 method public endStartSection (Ljava/lang/String;)V - -
 method public getNameOfLastSection ()Ljava/lang/String; - -
 method public func_194339_b (Ljava/util/function/Supplier;)V (Ljava/util/function/Supplier<Ljava/lang/String;>;)V -
 method public,deprecated startSection (Ljava/lang/Class;)V (Ljava/lang/Class<*>;)V -
in 90
class net/minecraft/profiler/Profiler$Result 50 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/profiler/Profiler$Result;>;
 inner net/minecraft/profiler/Profiler$Result net/minecraft/profiler/Profiler Result public,static,final
 field public field_76332_a D -
 field public field_76330_b D -
 field public field_76331_c Ljava/lang/String; -
 method public getColor ()I - -
 method public <init> (Ljava/lang/String;DD)V - -
 method public compareTo (Lnet/minecraft/profiler/Profiler$Result;)I - -
in 91
class net/minecraft/profiler/Profiler$Result 50 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/profiler/Profiler$Result;>;
 inner net/minecraft/profiler/Profiler$Result net/minecraft/profiler/Profiler Result public,static,final
 field public usePercentage D -
 field public totalUsePercentage D -
 field public profilerName Ljava/lang/String; -
 method public getColor ()I - -
 method public <init> (Ljava/lang/String;DD)V - -
 method public compareTo (Lnet/minecraft/profiler/Profiler$Result;)I - -
in 326
class net/minecraft/profiler/Profiler$Result 52 public,final,super java/lang/Object java/lang/Comparable Ljava/lang/Object;Ljava/lang/Comparable<Lnet/minecraft/profiler/Profiler$Result;>;
 inner net/minecraft/profiler/Profiler$Result net/minecraft/profiler/Profiler Result public,static,final
 field public usePercentage D -
 field public totalUsePercentage D -
 field public profilerName Ljava/lang/String; -
 method public <init> (Ljava/lang/String;DD)V - -
 method public compareTo (Lnet/minecraft/profiler/Profiler$Result;)I - -
 method public getColor ()I - -
in 91
class net/minecraft/profiler/Snooper 50 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public getCurrentStats ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public getUniqueID ()Ljava/lang/String; - -
 method public <init> (Ljava/lang/String;Lnet/minecraft/profiler/ISnooperInfo;J)V - -
 method public startSnooper ()V - -
 method public addMemoryStatsToSnooper ()V - -
 method public addClientStat (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public addStatToSnooper (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public isSnooperRunning ()Z - -
 method public stopSnooper ()V - -
 method public getMinecraftStartTimeMillis ()J - -
in 326
class net/minecraft/profiler/Snooper 52 public,super java/lang/Object - -
 inner java/util/Map$Entry java/util/Map Entry public,static,interface,abstract
 method public <init> (Ljava/lang/String;Lnet/minecraft/profiler/ISnooperInfo;J)V - -
 method public startSnooper ()V - -
 method public addMemoryStatsToSnooper ()V - -
 method public addClientStat (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public addStatToSnooper (Ljava/lang/String;Ljava/lang/Object;)V - -
 method public getCurrentStats ()Ljava/util/Map; ()Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>; -
 method public isSnooperRunning ()Z - -
 method public stopSnooper ()V - -
 method public getUniqueID ()Ljava/lang/String; - -
 method public getMinecraftStartTimeMillis ()J - -
